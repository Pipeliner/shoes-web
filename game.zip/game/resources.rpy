## resources.rpy — thin Ren'Py wiring around game/logic/resources.
##
## All math lives in game/logic/resources.py. This file exposes small helper
## labels and functions for scene authors.

init python:
    def rr_delta(resource_key, delta):
        """Apply a delta to a resource on the current snapshot. resource_key
        is a string (Resource enum value) or the Resource enum itself."""
        from logic.resources import Resource
        if isinstance(resource_key, str):
            resource = Resource(resource_key)
        else:
            resource = resource_key
        global resource_snapshot
        renpy.store.resource_snapshot = resource_snapshot.with_delta(
            resource, int(delta)
        )

    def rr_npc_delta(npc, delta, safe=True):
        """Apply a delta to a per-NPC Connection, consuming social_battery
        contextually by safe/unsafe."""
        global resource_snapshot
        renpy.store.resource_snapshot = resource_snapshot.with_npc_connection_delta(
            npc, int(delta), bool(safe)
        )

    def rr_get(resource_key):
        from logic.resources import Resource
        if isinstance(resource_key, str):
            resource = Resource(resource_key)
        else:
            resource = resource_key
        return resource_snapshot.get(resource)

    def rr_npc(npc):
        return resource_snapshot.connection_with(npc)

    def rr_band(resource_key):
        from logic.resources import Resource
        if isinstance(resource_key, str):
            resource = Resource(resource_key)
        else:
            resource = resource_key
        return resource_snapshot.band(resource).value

    def rr_state(state_name):
        """Return the bool value of a named ComputedState."""
        from logic import states
        fn = {
            "anxious_episode": states.anxious_episode,
            "depressive_episode": states.depressive_episode,
            "dissociative_spell": states.dissociative_spell,
            "flooded": states.flooded,
            "grounded": states.grounded,
        }[state_name]
        return fn(resource_snapshot)

    def rr_fawn(npc):
        from logic import states
        return states.fawn_active_for(resource_snapshot, npc)
