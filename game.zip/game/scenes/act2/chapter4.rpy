## scenes/act2/chapter4.rpy — the Flame / journal.
##
## Between-scene reflection with the Flame. See characters.rpy for the
## character definition (lowercase, italic). The Flame is framed as a
## journal — a tool the protagonist uses — not a simulated companion
## and not a therapist. Copy must never advise, diagnose, or promise
## outcomes. The Flame notices back.
##
## The distinction matters because the Flame's ancestor in real life is
## LOKI-GPT — an LLM. In the fiction, the Flame is a journal; in the
## design, it is a companion voice that exists to make noticing legible.
## Both framings are compatible. Neither is therapy.
##
## State effects match interior_work_flame_journaling (new beat):
##   +PERMISSION (small), +SELF_TRUST, +PRESENCE, +INTEROCEPTION.
##   Credits REFLECTION_COMPLETED on the prompt chosen.

label a2c4_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c4", False):
        centered "Chapter Seven — Act II (continued)\n\nThis chapter is a between-scene reflection. No sensitive content."
        $ chapter_notice_shown["a2c4"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c4_skipped

    scene black
    with dissolve

    e "It is Friday. You are at the kitchen table. The light at this hour makes the wood look warm in the way wood does not usually look warm."

    e "You open the journal. The cursor blinks the way cursors blink."

    flame "a few questions, if you want them. pick one, or skip."

    menu:
        "what did the part of you that closed the laptop need today?":
            flame "let it answer."
            e "You write for a while. Long enough that you do not remember, after, what you wrote first."

            $ rr_delta("permission", +4)
            $ rr_delta("self_trust", +3)
            $ rr_delta("presence", +3)
            $ rr_delta("interoception", +3)
            $ reco_credit("reflection_completed", "a2c4_caretaker_needs")

            flame "that was not a small thing you just did."
            jump a2c4_second_prompt

        "what did a smaller voice inside you say, that you did not write down?":
            flame "you can leave this one unwritten."
            e "You do. You notice the not-writing."

            $ rr_delta("presence", +5)
            $ rr_delta("interoception", +5)
            $ reco_credit("part_register_identified", "a2c4_exile_unwritten")

            flame "noticing without writing is a kind of writing. a different one."
            jump a2c4_second_prompt

        "what did the critic say this week — word for word, not the gist?":
            flame "verbatim is useful. the gist smooths things."
            e "You write the verbatim. The words land on the page differently than they land in the head."

            $ rr_delta("critic_volume", -6)
            $ rr_delta("self_trust", +4)
            $ rr_delta("permission", +3)
            $ reco_credit("reflection_completed", "a2c4_critic_verbatim")

            flame "on the page, that one is smaller than it is in your head."
            jump a2c4_second_prompt

        "just sit with it; no question today":
            flame "ok."
            e "The cursor blinks. The light stays warm on the wood."
            pause 1.0
            $ rr_delta("presence", +4)
            $ rr_delta("regulation", +4)
            jump a2c4_close

        "what about the small one who waited for the dog who did not come back?":
            ## Branch-neutral childhood-attachment-loss prompt. Per
            ## docs/continuity.md "Childhood pet (Mishka, given away)":
            ## the protagonist had a small dog as a child; one Saturday
            ## the figure who took her was the figure who took her, and
            ## the dog did not come back. Age 7 — a year that does not
            ## anchor to any of the three branch childhood signatures
            ## (CEN 13, MI 8, NIM 11), so the beat is branch-neutral.
            ## No literal Mother-attribution: "someone" / "the someone"
            ## is the figure-and-the-going, not who-did-it. Per parts-
            ## language.md exile_voice register: present-tense, child-
            ## register, small specific sensory detail.
            flame "the small one who watched the door for a long time. let her answer."

            exile_voice "Mishka has a leash. The leash hangs on a hook by the door."

            exile_voice "I am seven. I am in the chair near the door because the chair near the door is where you wait."

            exile_voice "My shoes are still on. You don't take your shoes off when you're waiting."

            exile_voice "On Saturday someone takes Mishka somewhere. Someone comes back. Mishka does not come back."

            exile_voice "The hook is empty. The hook stays empty. I look at it for a long time."

            e "You are at the kitchen table. The light is still warm on the wood. You write, slowly, what the small one in the chair would not have known how to write."

            $ rr_delta("permission", +4)
            $ rr_delta("interoception", +4)
            $ rr_delta("self_trust", +3)
            $ reco_credit("part_register_identified", "a2c4_dog_given_away")

            flame "you sat in the chair with her for a minute. that is what the page was for."
            jump a2c4_second_prompt


label a2c4_second_prompt:
    ## Optional second prompt. Recognition source; cheaper than the
    ## first — avoiding grinding.
    flame "one more, if you want it."

    menu:
        "say what you would have said to lena this week, and didn't":
            e "You write what you would have said. It is not elegant. It is not the point."
            $ rr_delta("permission", +3)
            $ rr_delta("self_trust", +3)
            $ reco_credit("reflection_completed", "a2c4_unsaid_to_lena")
            flame "it does not need to be elegant. it needs to exist."
            jump a2c4_close

        "say what you would have said to a younger you":
            e "You write a short sentence. Five words. You cross them out. You write them again."
            $ rr_delta("permission", +4)
            $ rr_delta("self_trust", +4)
            $ rr_delta("critic_volume", -3)
            # This is a gentle exile-adjacent prompt. Credits as a
            # part-register-identified rather than sat_with_exile
            # (which is reserved for the actual exile-approach scene).
            # The age implied by "a younger you" matches the branch's
            # childhood-flashback anchor: CEN 13 (yellow-wallpaper
            # kitchen), MI 8 (hallway), NIM 11 (dining room).
            $ reco_credit("part_register_identified", "a2c4_younger_self_letter")
            flame "you will not always have the words. you wrote them this time."
            jump a2c4_close

        "close the journal":
            flame "ok. another friday."
            jump a2c4_close


label a2c4_close:
    scene black
    with fade

    $ chapter_completed["a2c4"] = True

    flame "the friday pages are for noticing, not fixing."
    flame "you noticed. that is the whole assignment."

    e "You close the laptop. The afternoon is the afternoon. Your feet are not cold today."

    menu:
        "continue to Chapter Eight":
            jump a2c5_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c4_skipped:
    scene black
    centered "Chapter Seven was skipped."
    pause 1.5
    e "Friday was Friday. You did not write."
    e "There is no penalty for not writing. The journal is still there, next week."

    menu:
        "continue to Chapter Eight":
            jump a2c5_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
