# GEN-CHECKSUM: 496bd1df88e5a737
## Flashback snippets — technique: non_flashback
## The protagonist reaches for a memory and gets nothing.
##
## Generated from non_flashback.yaml. Hand-edit below the
## GEN-CHECKSUM line preserved by --force only.
##
## This file is a reference catalog, not live scene code.
## Scene authors grep for snippet IDs, then hand-adapt
## the prose into the target scene's voice. Do not
## import this file or reference its contents at runtime.

## --- snippet: what_she_said_after ---
## reach:
##   'You try to remember what she said after you put the phone down.'
## build:
##   - 'You know she said something. You know you answered. You know the answer was a sentence with three words in it, maybe four.'
## no_landing:
##   'The three words are not available to you.'

## --- snippet: the_walk_home ---
## reach:
##   'You try to remember the walk home from the dentist, the day you were ten and your sister was with you.'
## build:
##   - "You remember the dentist's office. You remember your sister in the chair before you."
##   - 'You remember the sidewalk at the corner where the two trees are.'
## no_landing:
##   'Between the office and the corner is a gap. You do not fill it.'

## --- snippet: the_photograph ---
## reach:
##   'You look at the photograph. You remember the kitchen in the photograph.'
## build:
##   - 'You remember the cupboard door being open. You remember the light.'
## no_landing:
##   'You do not remember why you are the one holding the camera.'

## --- snippet: the_sentence_you_almost_said ---
## reach:
##   'There is a sentence you almost say.'
## build:
##   - 'You can feel the shape of it in the lower part of your throat. You know its first word and its last word.'
## no_landing:
##   'You do not say it.'
## authoring_note:
##   'Use sparingly. Paired well with a scene where the player then has a *menu* choice — the not-saying becomes clickable.'

