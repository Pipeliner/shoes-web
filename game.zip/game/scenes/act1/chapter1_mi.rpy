## scenes/act1/chapter1_mi.rpy — Act I Chapter 1, MI-branch variant.
##
## Per PRD §4.3 Mentally-ill-parent (MI) branch:
##   - Dominant 4F pull: freeze.
##   - Parts skew toward hypervigilant managers and a dissociative
##     firefighter.
##   - Branch bias (game/logic/resources.py:BRANCH_BIAS[Branch.MI]):
##       PRESENCE ×1.3 worse, ×0.8 better
##       INTEROCEPTION ×1.2 worse, ×0.8 better
##       FLASHBACK_PRESSURE ×1.2 worse
##
## This chapter is the MI-branch opening (parallel to a1c1_start for
## CEN). It is selected from the start menu when the player picks the
## MI backstory.
##
## Craft discipline (per A7 + the MI-branch 4F pull):
##   - The dominant *first* response is freeze, not fawn. The part
##     that speaks is the *hypervigilant* manager — scanning the
##     household, not managing compliance.
##   - Mother is off-screen. The house contains her even when she
##     isn't visible. That is the whole shape of an MI childhood
##     held on the page.
##   - Dissociative firefighter replaces the CEN "numb-out" variant.
##     Its intervention is not "scroll"; it is "dissociate."

label a1c1_mi_start:
    scene black
    show screen tooltip_overlay

    ## Set the branch at scene entry. Future MI-branch scenes assume
    ## resource_snapshot.branch == Branch.MI.
    $ resource_snapshot = resource_snapshot.__class__(
        values=resource_snapshot.values,
        connection_per_npc=resource_snapshot.connection_per_npc,
        branch=_res.Branch.MI,
    )

    if not chapter_notice_shown.get("a1c1_mi", False):
        centered "Chapter One — MI branch\n\nMentally-ill-parent backstory variant. The house-listening opening. No on-screen parent contact in this chapter."
        $ chapter_notice_shown["a1c1_mi"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a1c1_mi_skipped

    scene black
    with dissolve

    e "You are awake because the house is making a shape you are listening for."

    e "You are always listening. You have always been listening. It is not a thing you choose; it is a thing your ear does on its own."

    e "The refrigerator is at the refrigerator pitch. The floor upstairs has not creaked in the past fourteen minutes. The back door is closed."

    $ rr_delta("threat_scan", +8)
    $ rr_delta("presence", -4)
    $ rr_delta("energy", -4)

    e "A part of you is running the inventory. It has been running the inventory since before you were old enough to name what an inventory was."

    caretaker_voice "Wait. Listen. The creak on the third step from the top of the stairs is the one that means she's up. We haven't heard that creak yet."

    e "You wait. You listen. You do not get out of bed."

    menu:
        "get up anyway; the inventory can keep running from the kitchen":
            jump a1c1_mi_kitchen
        "stay in bed; let the inventory run":
            jump a1c1_mi_stay
        "cover your ears; break the script for ten seconds":
            jump a1c1_mi_cover_ears


label a1c1_mi_kitchen:
    scene black
    e "You go to the kitchen. The kitchen is cold because the window has been open since three AM and you do not know who opened it."

    e "You close the window. You do not turn on the light."

    e "You put on the kettle. The kettle is not a sound that would wake her. You have done this calculation for years."

    ## Slight presence/interoception gain from going downstairs;
    ## self_trust small gain for acting; threat_scan stays high.
    $ rr_delta("presence", +3)
    $ rr_delta("interoception", +4)
    $ rr_delta("self_trust", +2)
    $ rr_delta("energy", -2)

    e "You are in the kitchen. The inventory part of you is still running. That is ok. That is how it is."

    $ act1c1_mi_outcome = "kitchen"
    jump a1c1_mi_close


label a1c1_mi_stay:
    scene black
    e "You stay. The ceiling is the specific grey of 6:40 AM. The inventory keeps running. You keep not being asleep."

    $ rr_delta("threat_scan", +4)
    $ rr_delta("energy", -6)
    $ rr_delta("regulation", -3)

    caretaker_voice "That was the third step. No. Wait. It was the radiator. It was the radiator."

    e "The inventory reclassifies. The inventory is good at its job. You are not sure whether to be grateful to the inventory."

    $ rr_delta("self_trust", -2)

    $ act1c1_mi_outcome = "stayed"
    jump a1c1_mi_close


label a1c1_mi_cover_ears:
    scene black
    e "You pull the pillow over your ears. The pillow is not a reliable seal. You know this; you do it anyway."

    e "For maybe six seconds the inventory is quieter. Your feet, under the blanket, are less cold than they were a minute ago."

    $ rr_delta("presence", +2)
    $ rr_delta("interoception", +5)
    $ rr_delta("regulation", +3)

    firefighter_voice "There. Good. Here is where I take you out for a little while. Don't worry about the rest of it."

    e "The Firefighter does its thing. You go somewhere mostly-not-here for maybe a minute."

    ## Dissociative firefighter activation is the MI-branch signature.
    $ rr_delta("presence", -6)
    $ rr_delta("flashback_pressure", +4)

    ## Credit: the player recognized the firefighter's move as a move.
    $ reco_credit("part_register_identified", "a1c1_mi_dissociative_firefighter_noticed")

    $ act1c1_mi_outcome = "covered_ears"
    jump a1c1_mi_close


label a1c1_mi_close:
    scene black
    with fade

    e "The morning continues. The inventory continues. You do what the morning asks."

    flame "the house-listening part of you has been at this since you were very small. today is not the day it rests."

    ## Reflection.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a1c1_mi_feeling")

    menu:
        "continue to Chapter Two (MI)":
            jump a1c2_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a1c1_mi_skipped:
    scene black
    centered "Chapter One (MI variant) was skipped."
    pause 1.5
    e "The morning happened. The house-listening happened. You did what you did."
    $ rr_delta("threat_scan", +4)
    $ rr_delta("energy", -2)

    menu:
        "continue to Chapter Two (MI)":
            jump a1c2_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
