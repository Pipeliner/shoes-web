## scenes/act2/chapter1_nim.rpy — Act II Ch 1 NIM-branch variant.
##
## CEN Act II Ch 1 uses the numb-out firefighter that seizes and
## closes the laptop: "Close the laptop. You close the laptop."
## MI Act II Ch 1 uses the same numb-out part but rendered as
## dissociation: "I am taking you out for a little while."
## NIM Act II Ch 1 uses the same part but rendered as the
## angry-protector fight/flight signature established in a1c1_nim /
## a1c2_nim / a1c3_nim: "Get up. Get out. Now." The protagonist
## *leaves the apartment*. They do not numb and they do not
## dissociate; they physically remove themselves.
##
## All three variants pre-seed the firefighter to intensity 70,
## bump to 85 on email-open, and pass through pp_firefighter_seizing
## — same mechanic; different prose texture.
##
## Branch-bias arithmetic (per amendments A8.1 and A10):
##   - NIM BRANCH_BIAS: CRITIC_VOLUME ×1.3 worse, THREAT_SCAN ×1.3
##     worse, REGULATION ×1.2 worse. The archive and delete paths
##     therefore land a harder effective critic spike on NIM than on
##     CEN/MI.
##   - State contract parity (A10): the *baseline* delta values
##     (critic +12, self_trust -8 on archive; presence -4 baseline
##     on firefighter turn before interoception recovery) match the
##     MI/CEN variants. The branch bias applies downstream.
##
## Craft discipline (NIM-specific):
##   - Firefighter voice uses fight/flight register, not numb-out
##     register. Imperatives. Short. Impulse-to-leave.
##   - Critic voice uses Mother-derived cadences (per the a1c*_nim
##     discipline). When the Critic arrives after the firefighter
##     turn, it speaks in sentences Mother actually said.
##   - Flashback is a public-humiliation moment, not a private
##     kitchen/hallway. The dining-room-in-a-pale-blue-dress
##     memory (see flashbacks/verb_tense_torque.yaml::
##     public_humiliation_eleven_pale_blue). The aunt whose
##     name is in the inbox was at the table. The aunt is the
##     intrusive_partial.what_mother_did_not_say placement.
##
## The scene structurally mirrors a2c1 and a2c1_mi (opening the
## aunt's email, firefighter turn, negotiation) so the Act III
## dispatcher + endings continue to work on any branch.

label a2c1_nim_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c1_nim", False):
        centered "Chapter Four — Act II begins (NIM branch)\n\nThis chapter contains a brief childhood flashback written as verb-tense torque (past intrudes mid-paragraph). The NIM-branch firefighter activates as angry-protector impulse-to-leave — a part of the protagonist takes her up out of the chair and out of the apartment — rather than numbing (CEN) or dissociation (MI). You can skip the chapter."
        $ chapter_notice_shown["a2c1_nim"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c1_nim_skipped

    scene black
    with dissolve

    e "The email has been unopened for a day and a part of a day."

    e "Your aunt's name in your inbox is a particular kind of silence."

    e "Your aunt has been sending these for as long as you have had an inbox to receive them. Before that, on paper. She is the person in the family who, when nobody is going to say the obvious thing, sends a sentence that at least notes it."

    ## Pre-raise firefighter intensity so the seize fires when the
    ## email opens. Mirrors CEN / MI preseed — same 70 → 85
    ## threshold arc, different part texture at the turn.
    python:
        from logic.parts import Part, PartKind
        _numb = parts_state.get("numb-out")
        parts_state = parts_state.with_part(Part(
            name=_numb.name, kind=_numb.kind, introduced=True,
            trust_in_self=_numb.trust_in_self,
            consented_for_exile=_numb.consented_for_exile,
            intensity=70,  # approaching seize threshold (75)
        ))

    menu:
        "open the email":
            jump a2c1_nim_open
        "mark it read and archive it without opening":
            jump a2c1_nim_archive
        "delete it":
            jump a2c1_nim_delete


label a2c1_nim_open:
    scene black
    e "You click. The subject line is 'Your mother.'"
    e "The body is short."
    e "She writes that your mother said something about you at a dinner last week. She writes that Tamara was there. She writes that she thought you should know."

    e "She closes the way she always closes — {i}she thought you should know{/i} — and the way she always closes is also the way she always declines to advise."

    $ rr_delta("flashback_pressure", +18)
    $ rr_delta("threat_scan", +12)
    $ rr_delta("regulation", -10)
    $ rr_delta("energy", -6)

    ## NIM-branch flashback: public-humiliation memory, written as
    ## verb-tense torque (past intrudes into present). The aunt
    ## whose name is in the inbox was at the table in the memory;
    ## she is the non-saying subject of the intrusive partial.
    ## Flashback uses verb_tense_torque.public_humiliation_eleven_pale_blue
    ## Flashback uses intrusive_partial.what_mother_did_not_say
    e "There is a dining room with six adults in it. You are eleven. You are in a pale blue dress that she has dressed you in for the evening."

    e "She is telling the room something about you. The room is laughing, not unkindly, in the way adults laugh when the subject is safely not them."

    e "Your aunt is at the table. You remember her looking at you and then not saying anything."

    e "You are thirty-four. You are in your own apartment. The dining room is not a dining room; the dining room is not there."

    ## Bump firefighter to seize threshold — same as CEN and MI.
    python:
        _numb = parts_state.get("numb-out")
        parts_state = parts_state.with_part(Part(
            name=_numb.name, kind=_numb.kind, introduced=True,
            trust_in_self=_numb.trust_in_self,
            consented_for_exile=_numb.consented_for_exile,
            intensity=85,
        ))

    if pp_firefighter_seizing():
        ## NIM-flavour firefighter turn: fight/flight. The
        ## protagonist *leaves the apartment*. Not numb, not
        ## dissociated — activated and moving.
        firefighter_voice "Get up. Get out. Now."
        e "You are up. You are moving. You are out of the chair before you decided to be out of the chair. Your knees are straight before the thought is."
        e "You find yourself in the stairwell. You do not remember the stairs. You are on the street."
        e "The laptop is open in your apartment. The email is still up. Your hand, when you look at it, is in a fist."

        ## Angry-protector signature: smaller presence drop than
        ## MI's dissociation (−4 vs −14), larger energy drop, larger
        ## threat_scan spike. The protagonist is still *here* — they
        ## just aren't in the apartment.
        $ rr_delta("presence", -4)
        $ rr_delta("energy", -8)
        $ rr_delta("regulation", -6)
        $ rr_delta("threat_scan", +8)
        $ rr_delta("flashback_pressure", -5)

        jump a2c1_nim_after_firefighter
    else:
        jump a2c1_nim_after_open


label a2c1_nim_after_firefighter:
    scene black
    e "It is later. You have been walking. You did not pick a direction; the walking picked one. At some point the walking became a walk and then you were the one walking."

    e "You come back to the apartment. The laptop is where you left it. The email is where you left it."

    e "You stand in the kitchen for a minute with your hands on the countertop. The countertop is a countertop."

    ## Recovery: the physical walking returns the body somewhat.
    ## Same +3 presence / +4 interoception as CEN and MI variants.
    $ rr_delta("presence", +3)
    $ rr_delta("interoception", +4)

    firefighter_voice "She was about to be in the room. I do not let her be in the room."

    ## Negotiation with the angry-protector variant of numb-out.
    $ intervention = renpy.call_screen(
        "negotiate",
        part_name="numb-out",
        opening_line="She was about to be in the room. I do not let her be in the room.",
    )
    if intervention is None:
        $ intervention = ("defer", "numb-out")
    $ response_key = pp_intervene(intervention[0], intervention[1])

    if response_key == "numb-out_asked_intent":
        firefighter_voice "I get you out of rooms she is in. Rooms she could be in. Rooms she has been in. I have been doing this since before you had words for it."
        e "The Firefighter does not apologise. It does not need to. It is protecting against the specific person it learned to protect against."
    elif response_key == "numb-out_listened_to":
        firefighter_voice "Okay. I hear you."
        e "The Firefighter does not retreat. It stays in a doorway it has stood in for a long time."
    elif response_key == "numb-out_deferred_to":
        firefighter_voice "Then we are not in the room."
        e "The laptop stays closed. You sit on the couch. The not-reading is the not-reading; the not-being-in-the-room is the not-being-in-the-room."
    elif response_key == "numb-out_overridden":
        firefighter_voice "…"
        e "You re-open the laptop. You read the email twice. The Firefighter has its back turned. You feel the turn."

    ## NIM-specific Critic follow-up after the firefighter turn. The
    ## Critic uses a specific Mother-derived sentence — a line she
    ## said to you in a kitchen at some point — rearranged for this
    ## situation. Identified-with-aggressor.
    critic_voice "You ran. You are a person who runs. Your aunt will hear. Everyone will hear."

    e "The Critic is saying the 'everyone will hear' line. Mother said 'everyone will hear' at least four times in your childhood. The Critic learned it from her."

    $ rr_delta("critic_volume", +8)
    $ reco_credit("part_register_identified", "a2c1_nim_critic_uses_mothers_rhythm")

    jump a2c1_nim_reflection


label a2c1_nim_after_open:
    scene black
    e "You stay with the email. You read it twice. You do not reply yet."
    e "Your body has been getting ready to leave the apartment and you notice it. The notice is its own thing."

    $ rr_delta("presence", +3)
    $ rr_delta("interoception", +4)

    jump a2c1_nim_reflection


label a2c1_nim_archive:
    scene black
    e "You archive the email without opening it."
    $ rr_delta("critic_volume", +12)
    $ rr_delta("self_trust", -8)
    critic_voice "You archive. You always archive. You will archive your mother, you understand. You understand what you are."
    critic_voice "Any move is the wrong move. The only one you cannot fail at is no move."
    e "The Critic is using a specific structure Mother used: the short declarative, the 'you understand,' the turn of the knife."
    e "Your hand is still on the trackpad. The trackpad is plastic and it is warm where your hand was."
    $ reco_credit("part_register_identified", "a2c1_nim_critic_uses_mothers_rhythm")
    jump a2c1_nim_reflection


label a2c1_nim_delete:
    scene black
    e "You delete the email."
    e "Deleted emails are not really deleted. You know this. A part of you knows this too."

    $ rr_delta("critic_volume", +8)
    $ rr_delta("flashback_pressure", +10)

    e "It is, for a few hours, as if the email was never sent."
    e "Your aunt knows it was. Your mother, who will hear about it from Tamara, knows it was."
    e "A part of you knows it was."

    jump a2c1_nim_reflection


label a2c1_nim_reflection:
    scene black
    with fade

    flame "the firefighter on this path has never been a numbing thing. it has been a moving thing. today it moved. noticing the moving — the exact shape of how you leave rooms, which rooms, and whose voice is in the rooms — is the work of the chapters between this one and the gate."

    ## Feeling wheel for Act II entry.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c1_nim_feeling")
    e "The next scene — the one with the child — is held closed for now. It will only open if, in the scenes between, both the part of you that takes care of others first and the part of you that takes you out of rooms have, separately, said yes."

    menu:
        "continue to Chapter Five (NIM)":
            jump a2c2_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c1_nim_skipped:
    scene black
    centered "Chapter Four (NIM variant) was skipped."
    pause 1.5
    e "The email was there. Time passed. You read it later, or you did not."

    menu:
        "continue to Chapter Five (NIM)":
            jump a2c2_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
