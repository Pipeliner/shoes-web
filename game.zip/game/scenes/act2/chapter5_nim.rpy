## scenes/act2/chapter5_nim.rpy — the dinner with Sam (NIM variant).
##
## Mirrors the structural arc of CEN `chapter5.rpy` and MI
## `chapter5_mi.rpy` — same five-outcome gated dinner scene with
## Sam. This is Sam's first direct scene on the NIM branch; Act
## III's `tell_r_no` is a second Sam scene that references the
## history this one establishes.
##
## Reuses the gated-choice screen `a2c5_dinner_menu` (branch-
## agnostic) authored at sam_dinner_choices.yaml.
##
## NIM-specific prose differences:
##   - Aunt-email content: per docs/continuity.md:695-701, the
##     NIM aunt-email is *"your mother said something about you
##     at a dinner last week. Tamara was there. she thought you
##     should know"*. The naming-of-Tamara is the aunt's signal
##     that the saying-something was not private. The
##     confront branch references *what was said and who heard*.
##   - Firefighter on fight_the_ache: NIM angry-protector (per
##     a2c1_nim:131 "Get up. Get out. Now."). In a restaurant
##     context the angry-protector wants to *leave* — its
##     register is "I can get us out of here" rather than
##     CEN's body-stop or MI's somewhere-mostly-not-here. The
##     protagonist's fight-the-ache decision is to *override*
##     the firefighter and stay; the firefighter holds that
##     veto.
##   - Caretaker on confront_refused: NIM threat-scanner
##     register reads the restaurant as a public-discussability
##     context — the table next to you might hear, the waiter,
##     the manager. Same shape as CEN/MI ("Not over dinner")
##     with NIM flavour.
##   - Critic on confront-landed: NIM Critic borrows Mother's
##     specific cadences per docs/continuity.md:556-559. Reuses
##     the "this is what I always mean" broken-off pattern.
##
## Sam himself is constant across branches per
## docs/continuity.md (Sam is branch-parity-clean).
##
## Writing discipline + state effects: identical to CEN/MI
## scenes; the simulator applies BRANCH_BIAS[NIM]
## (CRITIC_VOLUME ×1.3 worse, THREAT_SCAN ×1.3 worse,
## SOCIAL_BATTERY ×1.2 worse). Do not pre-bias here.

label a2c5_nim_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c5_nim", False):
        centered "Chapter Eight — Act II (continued, NIM branch)\n\nA quiet dinner scene with Sam, the partner. No sensitive content beyond adult dialogue about intimacy, routine, and one archived email about something Mother said publicly."
        $ chapter_notice_shown["a2c5_nim"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c5_nim_skipped

    scene black
    with dissolve

    e "It is Thursday. Sam is the person you have been with for years and have not lived with for any of them — that arrangement is one of the deliberate things between you, and you are not, mostly, planning to talk about it tonight."

    e "The arrangement is the one you both call {i}how we do this{/i}. Not a stage. Sam likes their own apartment; you like the one space in your life that is not asking anything of you. The other thing the arrangement gives you that you have never named to Sam: the threat-scanner does not have to inventory whose apartment Sam's dinner-with-friends could leak you into."

    e "Sam picked the restaurant. Sam always picks the restaurant, a fact you both find mildly amusing and mildly revealing. What Sam does NOT know that you know: the threat-scanner has, over years, registered that Sam picks restaurants with side-door tables and clear sight-lines. The scanner does not know that Sam doesn't know it has been doing this. Sam picks the restaurants because Sam picks the restaurants."

    e "The restaurant is small. The table is small. The menu is on a clipboard. You have ordered the thing you always order here; so has Sam."

    sam "You look a little far away tonight."

    e "Sam is not wrong. Sam is rarely wrong about this. Sam has, over years, learned the difference between *far away because today was a long day* and *far away because something Mother said reached you again*. Sam does not, mostly, ask which it is. Sam has, however, learned to clock when you have read an aunt-email by the way you don't reach for the bread basket."

    ## NIM-flavoured aunt-email frame: per docs/continuity.md
    ## :695-701, the NIM aunt-email is the public-discussability
    ## one — *"your mother said something about you at a dinner
    ## last week. Tamara was there."* The Tamara-was-there is
    ## what makes it not-private; that's what the aunt's email
    ## signals.
    e "The archived email from your aunt is still archived. The Tamara one. You have not mentioned it. You are not sure whether Sam knows and is waiting, or does not know and should."

    call screen a2c5_dinner_menu

    if _return == "i_missed_you":
        jump a2c5_nim_i_missed_you
    elif _return == "stay_quiet":
        jump a2c5_nim_stay_quiet
    elif _return == "ask_about_day":
        jump a2c5_nim_ask_about_day
    elif _return == "confront":
        jump a2c5_nim_confront
    elif _return == "confront_refused":
        ## NIM Caretaker register: threat-scanner. Reads the
        ## restaurant as a public-discussability context. The
        ## table next to you, the waiter, the manager — anyone
        ## here could become someone who heard part of a
        ## conversation. Same shape as CEN/MI ("Not over
        ## dinner") with NIM flavour.
        caretaker_voice "Not in the restaurant. The couple at the next table can hear us if we keep this volume. The waiter is two metres away."
        e "You do not confront. You reach for the bread basket, which does not need reaching for."
        jump a2c5_nim_stay_quiet
    elif _return == "fight_the_ache":
        jump a2c5_nim_fight_the_ache
    elif _return == "fight_the_ache_refused":
        ## NIM angry-protector firefighter: "Get up. Get out."
        ## (a2c1_nim:131). In a restaurant the firefighter wants
        ## to *leave* — to physically remove the body from the
        ## context. The protagonist override here is the choice
        ## to stay. The firefighter holds the veto.
        firefighter_voice "I can get us out of here in thirty seconds. Just stand. Just walk. We do not need to be in this room."
        e "You do not stand. You agree with the part of you that wants to stay. There is nothing to be afraid of in this room."
        jump a2c5_nim_stay_quiet
    else:
        jump a2c5_nim_stay_quiet


label a2c5_nim_i_missed_you:
    scene black
    with fade
    e "You say it without preface. \"I missed you.\""

    sam "I'm here."

    e "Sam is here. The sentence does not fix what you were missing — the thing you were missing is not Sam, exactly, it is the version of yourself that does not run a threat-scan on every room she walks into — but it lands."

    $ rr_npc_delta("sam", +7, safe=True)
    $ rr_delta("self_trust", +3)
    $ rr_delta("presence", +3)

    sam "You want to tell me what's been off?"

    menu:
        "say: not tonight. thank you for asking.":
            e "You say what you said."
            $ rr_delta("self_trust", +4)
            $ rr_npc_delta("sam", +3, safe=True)
            sam "Okay. I'm around."

        "say: I don't know what's been off.":
            e "You say it and you notice, as you say it, that you do know. You say it anyway."
            $ rr_delta("critic_volume", +3)
            $ rr_delta("presence", +2)

        "say: there is a thing. I'm not ready.":
            e "You say it. It is a specific sentence. It is the first time you have been ahead of the sentence on a Thursday at this restaurant."
            $ rr_delta("self_trust", +6)
            $ rr_delta("permission", +3)
            $ reco_credit("part_register_identified", "a2c5_nim_naming_the_thing_before_telling_it")
            sam "Okay."

    $ act2c5_outcome = "i_missed_you"
    jump a2c5_nim_close


label a2c5_nim_stay_quiet:
    scene black
    with fade
    e "You stay quiet. You finish the plate. The plate is fine."

    e "Sam lets the quiet hold. Sam is good at this, has been for years, a specific kind of good-at-this that means Sam will not press. Sam learned the no-press version after one early-relationship dinner where Sam mentioned, casually, that Tamara had been at a thing with one of Sam's coworkers; you went very quiet for the rest of the meal and Sam, at the time, did not understand why. Sam understands now. Sam does not, at restaurants, say Tamara's name."

    $ rr_npc_delta("sam", +1, safe=True)
    $ rr_delta("social_battery", -4)
    $ rr_delta("critic_volume", +3)

    critic_voice "You should have said something. The space is right there."

    e "The Critic is saying something that is half-right. The space is right there. You have not used it."

    $ act2c5_outcome = "stay_quiet"
    jump a2c5_nim_close


label a2c5_nim_ask_about_day:
    scene black
    e "\"How was the meeting this morning?\""

    sam "Fine. The new PM is still mostly nodding. Wait til week three."

    e "Sam tells you about the week. You follow most of it. You miss a beat halfway through and Sam notices and goes back."

    $ rr_npc_delta("sam", +3, safe=True)
    $ rr_delta("social_battery", -2)
    $ rr_delta("presence", -2)

    sam "Where did you go just then?"

    menu:
        "say: sorry — here now":
            e "You say sorry. You say here now. Sam does not push."
            $ rr_delta("self_trust", -2)
            $ rr_delta("critic_volume", +4)
        "say: I was thinking about the email from my aunt":
            ## NIM flavour: the email is "the Tamara one"
            ## (per docs/continuity.md:695-701).
            e "Sam puts the fork down. The restaurant gets slightly louder around the specific quiet at your table."
            $ rr_delta("self_trust", +6)
            $ rr_delta("permission", +3)
            $ rr_npc_delta("sam", +5, safe=True)
            $ reco_credit("reflection_completed", "a2c5_nim_mentioned_the_email")

    $ act2c5_outcome = "ask_about_day"
    jump a2c5_nim_close


label a2c5_nim_confront:
    scene black
    with fade
    e "You push the plate an inch forward. You do not look up from the plate."

    ## NIM confront line: the Tamara-witness fact is the
    ## email's content. The fact that *what was said is not
    ## private* is what's load-bearing on this branch.
    e "\"There was an email from my aunt. About my mother. She said something about me at a dinner last week. Tamara was there. I archived it on Tuesday.\""

    e "Your aunt knew Mother as a younger woman than you have ever known her. The aunt's emails come from someone who has been watching the same person for longer than you have been alive. Tamara has been in the room for some of those years too. The naming-of-Tamara was the aunt's signal that the saying-of-something was not private."

    pause 1.0

    sam "Oh."

    pause 1.0

    e "Sam is not a person who reflexively says the right thing in restaurants. Sam is, however, a person who waits for the second sentence. Sam knows the names. Sam knows that Tamara-at-a-dinner is not a private statement. Sam has, for years, been on the periphery of the slow-motion not-yet-said part of you that has been waiting to find out how far the dinner-talk has travelled."

    menu:
        "say: I don't know what to do with it.":
            e "You say it. It is the truest sentence you have said out loud this week."
            sam "We can look at it at home, if you want. Or not. Whatever you need."
            $ rr_delta("self_trust", +8)
            $ rr_delta("permission", +4)
            $ rr_npc_delta("sam", +8, safe=True)

        "say: I don't know if I want to do anything with it.":
            sam "Okay."
            $ rr_delta("self_trust", +5)
            $ rr_npc_delta("sam", +5, safe=True)

    ## ACoA per A7: the critic arrives even when the confront
    ## lands. NIM Critic borrows Mother's cadence per
    ## docs/continuity.md:556-559: the broken-off slur from
    ## a1c2_nim:177 is the borrowed shape. Same critic-on-
    ## schedule arrival; the cadence the critic is wearing is
    ## not the critic's.
    critic_voice "You shouldn't have made this Sam's problem. The Tamara one. This is what I always mean when I say you—"

    $ rr_delta("critic_volume", +6)

    e "The Critic is saying a thing that is not wholly true and not wholly false. You notice it arriving on schedule. The cadence the Critic is wearing is not the Critic's."

    $ reco_credit("part_register_identified", "a2c5_nim_confront_critic_timing")
    $ reco_credit("reflection_completed", "a2c5_nim_named_email_to_r")

    $ act2c5_outcome = "confronted"
    jump a2c5_nim_close


label a2c5_nim_fight_the_ache:
    scene black

    ## "The ache" — first NIM-branch use of the family idiom.
    ## CEN glossed it at chapter5.rpy:272; MI mirrored at
    ## chapter5_mi.rpy. NIM mirrors the gloss here so an NIM-
    ## only player gets the in-character anchor per
    ## .claude/rules/clarity.md rule 1.
    e "There is an ache in the centre of you. Not pain, exactly. More like a missing — the kind that has been there long enough you stopped naming it."

    e "You push through. \"No, I'm fine. Tell me about the thing with the PM.\""

    e "Sam picks it up. You listen. You keep listening. You keep hearing words, but somewhere after the second sentence you are not really in the restaurant anymore."

    ## NIM-coded version of the ache-fight: the angry-protector
    ## firefighter is *registering the room* and pressing for
    ## an exit. The protagonist's fight-through means
    ## overriding the leave-impulse and staying — knees still,
    ## body in the chair, hand cutting the food. Same effect-
    ## shape as CEN/MI; the *conflict* is the firefighter's
    ## leave-pressure rather than CEN's body-stop or MI's
    ## somewhere-mostly-not-here.
    e "Your hand is cutting into the food on the plate. The cutting is a thing your hand is doing. The angry-protector part of you is making a low, urgent argument for getting up and walking out of the restaurant. You override it. You stay."

    $ rr_delta("presence", -6)
    $ rr_delta("flashback_pressure", +8)
    $ rr_delta("interoception", -5)
    $ rr_delta("social_battery", -6)

    firefighter_voice "Up. Out. Now. We do not need to be in this room. We are not safe in this room."

    e "You keep going. The angry-protector keeps making its argument. Sam finishes the PM story. Sam eats. You nod at the right places. The angry-protector keeps the floor."

    $ act2c5_outcome = "fought_the_ache"
    jump a2c5_nim_close


label a2c5_nim_close:
    scene black
    with fade

    $ chapter_completed["a2c5_nim"] = True

    e "After the restaurant, there is the walk home. Sam does not say much. You do not either. Sam's quiet, you have learned, is not the same as the threat-scanner's quiet — Sam's quiet is the specific quiet of a person who has decided to walk silently with you instead of asking. The threat-scanner accepts Sam's quiet as a different category of quiet."

    e "Sam reaches for your hand on the corner where you always cross. You take it."

    $ rr_npc_delta("sam", +2, safe=True)

    ## Chapter-end reflection.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c5_nim_feeling")

    menu:
        "continue to Chapter Nine (NIM)":
            jump a2c6_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c5_nim_skipped:
    scene black
    centered "Chapter Eight (NIM variant) was skipped."
    pause 1.5
    e "A Thursday passed. There was a restaurant. There was a walk home. Sam held your hand."
    $ rr_npc_delta("sam", +1, safe=True)

    menu:
        "continue to Chapter Nine (NIM)":
            jump a2c6_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
