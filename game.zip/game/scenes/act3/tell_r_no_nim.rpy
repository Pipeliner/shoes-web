## scenes/act3/tell_r_no_nim.rpy — Act III structural-change scene
## (NIM variant).
##
## Per S1+S2 (0.1.18-46): Act III per-branch variants. Same
## gated-menu shape as CEN/MI; same Recognition gate (14).
##
## Branch differences vs. CEN/MI:
##   - The kettle-flashback opens onto Mother on the phone
##     telling someone something about you. The breath you
##     hear is hers planning the next thing to say. The
##     kettle is the punctuation. You at eleven, in the
##     kitchen, listening to her tell Tamara something
##     specific about you that you have not yet heard.
##   - The fawn-yes pattern's NIM-shape: said yes on Tuesday
##     because the threat-scanner did not want to be the
##     kind of girlfriend Sam could later quote saying-no-
##     to-his-friends. The yes was for the discoursability.
##   - Sam's tactful response: Sam knows the Tamara-context
##     (per Sam-knows-the-branch-register, R2 a2c5).
##   - Critic on landed-success: borrows Mother's cadence —
##     the kind-of-girl who can't say no like a normal
##     person, broken-off mid-sentence per a1c2_nim:177.

label a3_tell_r_no_nim:
    scene black
    show screen tooltip_overlay

    e "It is Thursday evening. You are at Sam's. Sam is on the couch with the book that has been on the couch for a week."

    e "Sunday brunch was your yes. You said it on Tuesday, without thinking. Sam's friends are Sam's friends; they are fine. You do not know them."

    e "You do not want to go."

    ## NIM-specific: the fawn-yes traces to the threat-scanner.
    e "A part of you knew on Tuesday that you did not want to go. You said yes anyway. The threat-scanner did not want to be the kind of girlfriend Sam could later quote saying-no-to-his-friends. The yes was for the discoursability of the yes — for the version of you that gets retold at someone else's dinner table."

    e "That is the whole shape of this for you. The yes was for who-might-hear-about-it. The Sunday is for you."

    pause 1.0

    e "Sam has not looked up from the book. The kettle in Sam's kitchen is cooling on the counter."

    ## NIM-specific kettle-flashback: Mother on the phone
    ## telling-someone-something. Per PRD §7.1: verb-tense
    ## torque, intrusive partial.
    e "The kettle clicks off."

    e "The kettle in your mother's kitchen clicked off the same way. She was at the counter. She was on the phone with Tamara. She was telling Tamara something."

    e "You are eleven. You are standing in the doorway because you came in to ask if there was anything to eat, and she did not turn around because she was finishing a sentence."

    e "The sentence had your name in it. You did not catch the rest. The rest was the kettle clicking off. The kettle was the punctuation. The kettle was the part that meant the sentence was finished."

    e "You are in Sam's kitchen. The book is the book. The kettle is cooling. Sam is right there."

    call screen a3_tell_r_no_menu

    if _return == "say_it":
        jump a3_tell_r_no_nim_said
    elif _return == "say_it_refused":
        e "There is a sentence you almost say."
        e "You can feel the shape of it in the lower part of your throat. You know its first word and its last word."
        e "You do not say it."
        ## NIM-specific firefighter line: the angry-protector,
        ## but reframed for Sam as a non-threat.
        firefighter_voice "No. Not now. Sam will tell his friends you cancelled. The cancelling will become the thing."
        e "You stay on the chair. The kettle is the kettle. The book is the book. The angry-protector is wrong about Sam — Sam does not weaponise things — but the angry-protector is not, this Thursday, ready to know that."
        jump a3_tell_r_no_nim_not_said
    elif _return == "wait":
        jump a3_tell_r_no_nim_waited
    else:
        jump a3_tell_r_no_nim_not_said


label a3_tell_r_no_nim_said:
    scene black
    with fade
    e "You say it. The sentence comes out shorter than you planned."

    e "\"I was thinking about Sunday. Can I take back the yes?\""

    pause 1.0

    e "Sam looks up. Sam's thumb stays on the page. This is not hostile. This is Sam finishing the sentence Sam was reading."

    ## NIM-specific Sam: knows the Tamara-context.
    sam "Yeah. Want me to still go? Or — was the email this week?"

    e "Sam has not named the email. The *or* is what Sam has, over years, learned to put after a question like this. Sam knows what *the email* means without naming it; Sam does not, at Sam's apartment, say Tamara's name aloud."

    menu:
        "say: yes, go":
            e "You say: yes. Go."
            $ rr_npc_delta("sam", +4, safe=True)
        "say: i'd rather we stayed in":
            e "You say: i'd rather we stayed in."
            $ rr_npc_delta("sam", +6, safe=True)
            sam "Okay. I'll text them. They will be fine."
        "say: i don't know yet":
            e "You say: i don't know yet."
            sam "Okay. Let me know by Friday and I'll handle it either way."
            $ rr_npc_delta("sam", +3, safe=True)

    ## Base effects of the successful boundary.
    $ rr_delta("self_trust", +8)
    $ rr_delta("permission", +4)

    ## NIM-specific Critic: borrows Mother's cadence per
    ## docs/continuity.md:556-559 + a1c2_nim:177 broken-off
    ## slur pattern.
    critic_voice "You always do this. The kind of girl who can't say no to a brunch like a normal person. The kind of girl who is, at thirty-four, still—"

    $ rr_delta("critic_volume", +7)

    e "The Critic's line is about Tuesday, not about now. You notice the distinction. You notice, also, that the cadence the Critic is wearing is not the Critic's. It is hers. The Critic is doing what the Critic does, which is read aloud from the script she gave you."

    $ reco_credit("reflection_completed", "a3_tell_r_no_nim_succeeded")
    $ reco_credit("part_register_identified", "a3_tell_r_no_nim_critic_timing")

    flame "you took back a yes. that is a specific thing. the critic's timing on it — and the cadence on it — was information about where you have lived for a long time."

    $ act3_outcomes["tell_r_no"] = "said"
    $ renpy.fix_rollback()
    jump a3_tell_r_no_nim_close


label a3_tell_r_no_nim_waited:
    scene black
    e "You wait for the right moment. The right moment does not come."

    e "Sam closes the book at ten, makes tea, goes to bed."

    e "You stay on the chair. Sunday is still happening. The threat-scanner has, by ten-twenty, started running its forecast for Sunday — what one of Sam's friends might mention about you afterward, what version of the brunch will travel back to anyone, whether being-at-the-brunch is more or less discussable than not-being-there."

    $ rr_delta("self_trust", -3)
    $ rr_delta("critic_volume", +5)
    $ rr_delta("presence", +3)

    critic_voice "The right moment was always right now. You know that."

    $ reco_credit("part_register_identified", "a3_tell_r_no_nim_waited_pattern")

    $ act3_outcomes["tell_r_no"] = "waited"
    $ renpy.fix_rollback()
    jump a3_tell_r_no_nim_not_said


label a3_tell_r_no_nim_not_said:
    scene black
    with fade
    e "Sunday happens. The brunch is fine. The brunch is an hour and forty minutes."

    e "You say the things people say at brunch. You laugh at the things people laugh at. The threat-scanner is at brunch with you, scanning the table for cousins-of-Mother's-friends, finding none, scanning anyway."

    $ rr_delta("social_battery", -12)
    $ rr_delta("presence", -6)

    e "Monday you are tired in the way that means a specific tired."

    flame "you did not take back the yes this time. that is also information. the threat-scanner is allowed to want a not-discussable sunday. you are also allowed to stay home."

    if act3_outcomes.get("tell_r_no") != "waited":
        $ act3_outcomes["tell_r_no"] = "not_said"
        $ renpy.fix_rollback()
    jump a3_tell_r_no_nim_close


label a3_tell_r_no_nim_close:
    scene black
    with fade
    e "The Thursday closes. The week continues."
    return
