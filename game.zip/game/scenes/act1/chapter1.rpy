## scenes/act1/chapter1.rpy — the demo scene. CEN branch.
##
## Per PRD §11 demo scope: Act I Chapter 1 only. 30–45 minutes.
## Includes one visibly-unavailable sequence, one part intervention,
## one reflection prompt. No exile content. No ending spoilers.
##
## Writing discipline notes (see .claude/rules/parts-language.md, PRD §7.1):
##   - "a part of you" not "your parts"
##   - No screen shake, desaturation, or piano sting for flashback hints.
##     Flashback arrives as verb-tense torque and sensory pivot.
##   - Inner Critic register: second person, absolutism, tense-collapse.
##   - Narrator does not name behaviours as "fawn" or "freeze."
##   - No "healing," "recovery," or therapy-outcome language.

label a1c1_start:
    scene black
    show screen tooltip_overlay

    ## Chapter notice + skip menu, parity with MI/NIM Ch 1 (added
    ## 0.1.18-17 per docs/parity-and-onboarding-audit-0.1.18-15.md
    ## O-2 / docs/accessibility-trauma-ux-audit-0.1.18-15.md C1 —
    ## CEN Ch 1 had less safety scaffolding than the experimental
    ## branches even though it is the recommended first-time path).
    ##
    ## The notice also teaches the visibly-unavailable convention
    ## the player will encounter at line ~57 below: choices that
    ## would not land for the protagonist render as visible options
    ## with their reason attached.
    if not chapter_notice_shown.get("a1c1", False):
        centered "Chapter One — the morning\n\nThe protagonist wakes early in an apartment shared with her sister Lena. This chapter introduces the visibly-unavailable choice mechanic — choices that would not land for the protagonist appear with the reason they would not, rather than vanishing. No flashback content; no mention of childhood. Skippable at the chapter level."
        $ chapter_notice_shown["a1c1"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a1c1_skipped

    scene black
    with dissolve

    e "There is a sound the phone makes at the hour you should have slept. It is not loud."

    ## "Pitch of obedience" — first-encounter family idiom. The
    ## protagonist learned this register from Mother long before
    ## she had words for it; the phrase recurs across scenes
    ## (Ch 2 "you say it at the pitch of obedience"). Per
    ## .claude/rules/clarity.md: glossing in-character on first
    ## use, in the protagonist's own observing voice.
    e "There is a tone of voice you learned before you learned the words to use it. The pitch of saying yes when you have not been asked. The pitch of obedience."

    e "That is the phrase you have for it. The pitch of obedience."

    e "You reach for it before you choose to."

    $ rr_delta("energy", -6)
    $ rr_delta("social_battery", -2)

    e "You are not thinking yet. You are reading a group chat from two time zones away."

    e "Your feet are cold."

    e "Somewhere inside, something that has held a schedule together for years clears its throat."

    ## The Caretaker speaks. This is the player's first explicit meeting
    ## with a part. The UI voice label reads "a part of you" — the
    ## standing rule.
    e "Lena is your sister. She has been living with you in this apartment since the move that happened after the year that you both, separately and together, do not really talk about. She is already up; you can hear the kettle."
    caretaker_voice "Lena is already up. The kettle is on. You should put the phone down and go stand in the kitchen with her."
    caretaker_voice "Not because you want to. Because if you don't, the day starts on her alone, and that is the kind of thing you do not want to have done."
    caretaker_voice "The kitchen is new. The watching is not new."

    ## First visibly-unavailable choice. The sensible option is "go to
    ## the kitchen, yes" — blocked by NOT_ENOUGH_REST. The player can
    ## see why.
    call screen a1c1_first_choice

    ## Dispatch on the returned choice id.
    if _return == "kitchen":
        jump a1c1_kitchen
    elif _return == "phone":
        jump a1c1_phone
    elif _return == "cold_feet":
        jump a1c1_cold_feet
    elif _return == "fight_the_urge":
        ## VISIBLE_AND_REFUSED — the player clicked. The part speaks.
        caretaker_voice "You can't force this. The point is not to win. The point is to not be the one who makes the morning harder for her."
        jump a1c1_kitchen
    else:
        jump a1c1_cold_feet


screen a1c1_first_choice():
    tag menu
    ## Evaluate each choice up front. The screen just renders.
    $ c_kitchen = cc_eval(
        "kitchen",
        "get up, go to the kitchen, stand with Lena",
        guard_keys=("not_enough_rest",),
        refuse_on_block=False,
    )
    $ c_phone = cc_eval(
        "phone",
        "stay in bed with the phone",
        guard_keys=(),
    )
    $ c_cold_feet = cc_eval(
        "cold_feet",
        "notice your cold feet; stay with that for a moment",
        guard_keys=(),
    )
    $ c_fight = cc_eval(
        "fight_the_urge",
        "just override the caretaker; it's a kettle",
        guard_keys=("not_enough_rest",),
        refuse_on_block=True,
    )

    use tooltip_footer

    frame:
        xalign 0.5
        yalign 0.5
        xpadding 28
        ypadding 28
        xmaximum 720

        vbox:
            spacing 10
            text "What do you do?" size 22

            use gated_choice_row(c_kitchen, Return("kitchen"))
            use gated_choice_row(c_phone, Return("phone"))
            use gated_choice_row(c_cold_feet, Return("cold_feet"))
            use gated_choice_row(c_fight, Return("fight_the_urge"))

            use tooltip_footer


label a1c1_kitchen:
    scene black
    with fade
    e "You make it to the kitchen. The floor is cold. The light is the kind of light that is not really light yet."
    lena "You're up."
    lena "There's coffee."
    e "You take the mug. Your hand has picked up the mug."
    ## Micro-compliance: written as behaviour, not labelled. PRD §7.1.
    e "You ask whether she slept. You ask it the way you ask it every morning. You ask it before she has finished turning to face you."

    $ rr_npc_delta("lena", +3, safe=True)
    $ rr_delta("self_trust", -2)

    e "The Caretaker quiets down. A different part of you notices it."
    e "The noticing is brief. Something the size of a coin."

    jump a1c1_negotiation


label a1c1_phone:
    scene black
    e "You stay with the phone. The phone is warm. The group chat is forty-eight hours deep."
    e "Your thumb reaches the bottom and starts again."
    $ rr_delta("energy", -4)
    $ rr_delta("critic_volume", +8)
    e "The voice arrives."
    critic_voice "You always do this. You always start your day like this. You have had fifteen years to not start your day like this."
    e "You close the app. The voice is not fooled. The voice has been waiting."
    critic_voice "You know what Lena is doing right now. You know what you are doing. You know what you should be doing."
    e "Your feet are very cold."
    jump a1c1_negotiation


label a1c1_cold_feet:
    scene black
    e "You stay with your feet for a little longer than usual."
    e "The cold is specific. The cold is on the tops of the toes, in the arches, at the heels where your weight would be if you were standing up."
    e "Nothing fixes. Nothing resolves."
    ## A small Recognition moment — PRESENCE rises gently.
    $ rr_delta("presence", +5)
    $ rr_delta("interoception", +6)
    e "You don't get up yet. You do not yet get up."
    jump a1c1_negotiation


## Negotiation-loop: the Caretaker is loud this morning. The player has the
## five intervention options. (OVERRIDE is visibly unavailable early — the
## protagonist does not have the permission / self-trust for it yet.)
label a1c1_negotiation:
    caretaker_voice "We need to plan the day. We need to know what is coming. If we do not plan the day, Lena will, and she will be tired again, and this will be a thing we did."

    $ intervention = renpy.call_screen(
        "negotiate",
        part_name="caretaker",
        opening_line=(
            "We need to plan the day. We need to know what is coming."
        ),
    )

    if intervention is None:
        # Player closed the negotiate screen without choosing; default to defer.
        $ intervention = ("defer", "caretaker")

    $ response_key = pp_intervene(intervention[0], intervention[1])

    if response_key == "caretaker_listened_to":
        caretaker_voice "…okay. Okay."
        e "The Caretaker quiets, a little. It is not gone. It never will be. But it steps back from the microphone."
    elif response_key == "caretaker_asked_intent":
        caretaker_voice "I am trying to keep her safe. I am trying to keep you from being the reason she is tired."
        e "That was the thing. That had always been the thing."
        e "The Caretaker trusts you a little more today than yesterday."
    elif response_key == "caretaker_disagreed_with":
        caretaker_voice "Fine. Fine. You know what you're doing."
        e "It doesn't believe you. But it retreats."
    elif response_key == "caretaker_deferred_to":
        caretaker_voice "Good."
        e "You follow the plan. The morning narrows into a list of small tasks."
    elif response_key == "caretaker_overridden":
        caretaker_voice "…"
        e "The silence after is worse than the voice was. The voice meant something was working."
        critic_voice "You never learn."

    jump a1c1_reflection


## Chapter-end reflection. Unscored. Two prompts (feeling wheel + part
## picker). Skippable. Each completed prompt credits Recognition.
label a1c1_reflection:
    scene black
    with fade

    ## First-encounter framing for the journal mechanic. The
    ## reflection screens that follow are styled as the
    ## protagonist's journal (italic, first-person prompts:
    ## "from your journal" / "I was…" / "today the loudest part
    ## of me was…"). One short Flame line sets up that the
    ## prompts are optional and that picking accumulates toward
    ## later scenes. Skipping is fine; the journal page just
    ## stays empty for that day.
    flame "you open your journal. you pick what to write."
    flame "skipping is allowed. but the writing accumulates — some later moments only open once enough has been written."

    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a1c1_feeling")
    if feeling is not None:
        flame "[feeling]. noted."

    $ part_choice = renpy.call_screen("reflection_part_picker", event_id="a1c1_part")
    if part_choice == "critic":
        flame "the voice that says 'you always' and 'you never.' It is sparse but loud."
        flame "it is not you. it is a part of you trying, in its own sharp way, to keep you safe."
    elif part_choice == "caretaker":
        flame "the one that takes care of others first. it has kept you safe for a long time. it is tired."
    elif part_choice == "numb-out":
        flame "the one that goes numb. it gets you out of rooms you cannot stay in. it also keeps you out of rooms you would like to be in."
    elif part_choice == "small-one":
        flame "you heard something smaller. you do not have to go closer to it right now."

    ## A chapter-end content notice for next chapter.
    e "What follows includes a phone call from Mother, written to be skippable at the scene level."
    e "You can close the game with G at any time."


    menu:
        "continue to Chapter Two":
            jump a1c2_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a1c1_skipped:
    scene black
    centered "Chapter One was skipped."
    pause 1.5
    e "The morning happened. The phone happened. You did what you did."
    $ rr_delta("energy", -2)

    menu:
        "continue to Chapter Two":
            jump a1c2_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
