## scenes/act3/mention_the_childhood_thing_nim.rpy — Act III
## structural-change scene (NIM variant).
##
## Per S1+S3 (0.1.18-46): Act III per-branch variants. CEN
## equivalent: scenes/act3/mention_the_childhood_thing.rpy.
## Same gated-menu shape and Recognition gate (20 — highest
## tier).
##
## Branch differences vs. CEN/MI:
##   - 2am as the threat-scanner's *low-yield hour* — at 2am
##     no one is going to retell what you say. The
##     discoursability of any sentence sent at 2am is briefly
##     close to zero. The threat-scanner has, in this hour,
##     no inventory.
##   - Ben as the one-person-in-your-life-who-was-not-on-
##     Mother's-discoursability-map. Ben does not know Tamara.
##     Ben does not know the cousin H. Ben is permanently
##     low-yield in the threat-scanner's working model.
##   - Exile-voice surfaced fragment is the dining-room-at-
##     eleven signature.
##   - Critic on send: borrows Mother's cadence about
##     kind-of-girl-who-tells-Ben-things.

label a3_mention_the_childhood_thing_nim:
    scene black
    show screen tooltip_overlay

    e "Two in the morning. You are on the couch. You cannot sleep."

    e "The laptop is closed. The phone is in your hand."

    e "Ben is awake. He is always awake at this hour; he has been a night person since you were twelve. You know this from twenty years of being his friend."

    ## NIM-specific: 2am as the low-yield hour + Ben as
    ## off-the-discoursability-map.
    e "Two in the morning is the only hour the threat-scanner has nothing to scan. Whatever you say to anyone right now is not going to be retold by anyone else, because everyone else is asleep. The discoursability of a 2am sentence is close to zero — the threat-scanner has, briefly, no inventory."

    e "Ben does not know Tamara. Ben does not know the cousin H. Ben does not, in the threat-scanner's working model, have a path back to your mother's dinner table. Ben is, permanently, low-yield."

    e "You have not told him. You have meant to tell him. You have drafted telling him in your head on and off for fifteen years — usually after one of her dinners, when the threat-scanner had been running its inventory all evening and most wanted someone outside the inventory to know."

    e "He has been in your life longer than you have known there was a thing to tell, which is why he is the one you are typing at."

    pause 1.0

    e "Tonight is not different in most ways. In one way it is. The threat-scanner has nothing to scan and Ben is a person nothing scans for."

    e "You are composing a text. You have not typed anything yet."

    pause 1.0

    call screen a3_mention_menu

    if _return == "send_short":
        jump a3_mention_nim_send
    elif _return == "send_short_refused":
        ## NIM Caretaker register on the refusal.
        caretaker_voice "Not at two in the morning. He will think something is wrong. He will mention this to Marina. Marina sometimes talks to your aunt. The aunt is, technically, in the inventory."
        e "You put the phone down. The keyboard fades. You sit on the couch for a while. The threat-scanner, satisfied with its second-order inventory, has a moment of feeling useful."
        jump a3_mention_nim_not_sent
    elif _return == "send_long":
        jump a3_mention_nim_long_sent
    else:
        jump a3_mention_nim_not_sent


label a3_mention_nim_send:
    scene black
    with fade

    ## Intrusive-partial per PRD §7.1: NIM dining-room fragment.
    e "You type one sentence."

    e "You type: "

    exile_voice "i was eleven and i was in a pale blue dress and the room was laughing."

    pause 2.0

    e "You delete the beginning of the sentence. 'there is something i want to tell you' is not what you type. The sentence is the sentence."

    e "You press send."

    pause 1.0

    e "The message sends at 02:14 local."

    e "Ben's typing indicator appears at 02:14 and a half."

    pause 1.0

    e "You close your eyes."

    ## State effects mirror CEN.
    $ rr_delta("self_trust", +12)
    $ rr_delta("permission", +6)
    $ rr_npc_delta("ben", +10, safe=True)
    $ rr_delta("flashback_pressure", +10)
    $ rr_delta("presence", -4)

    ## NIM-specific Critic line: borrowed Mother-cadence about
    ## the kind-of-girl-who-tells-Ben-things.
    critic_voice "You did not have to do that. The kind of girl who tells her childhood friend a thing like this in a 2am text is the kind of girl who—"

    $ rr_delta("critic_volume", +5)

    e "The Critic's line cuts off mid-sentence. The cadence the Critic was wearing was Mother's. The Critic does not finish the sentence in the cadence the Critic borrowed; the Critic does not, tonight, have the next word."

    $ act3_outcomes["mention_the_childhood_thing"] = "sent"
    $ renpy.fix_rollback()

    ## Highest-tier Recognition credits — distinct event_ids.
    $ reco_credit("sat_with_exile", "a3_mention_nim_short_version_sent")
    $ reco_credit("named_flashback", "a3_mention_nim_dining_room_line")

    flame "you sent the short version. that sentence did not exist in a message from you before tonight. now it does. ben is not in the inventory the threat-scanner runs. that is partly why this works."

    jump a3_mention_nim_close


label a3_mention_nim_long_sent:
    scene black
    with fade
    e "You type a wall of text. You re-read the wall of text. The wall of text is fifteen years."

    e "You send it anyway."

    pause 1.0

    e "Ben does not respond for forty minutes."

    e "When Ben responds, he says: that is a lot. can we talk on saturday."

    pause 1.0

    e "You say yes. You put the phone face-down. You do not sleep."

    $ rr_delta("self_trust", +6)
    $ rr_delta("flashback_pressure", +18)
    $ rr_delta("presence", -10)
    $ rr_npc_delta("ben", +6, safe=True)

    e "The long version cost more than the short would have. You notice the cost. You notice also that Ben said 'saturday.'"

    $ act3_outcomes["mention_the_childhood_thing"] = "long_sent"
    $ renpy.fix_rollback()
    $ reco_credit("named_flashback", "a3_mention_nim_long_version_sent")

    flame "sending the long version is a thing that happens. sending the short version would have been a different thing. both are real."

    jump a3_mention_nim_close


label a3_mention_nim_not_sent:
    scene black
    with fade

    e "Tomorrow comes. You did not send."

    e "You do not send on tuesday either. Or wednesday. By thursday the threat-scanner is fully back online and the inventory is full again."

    $ rr_delta("self_trust", -3)
    $ rr_delta("critic_volume", +4)
    $ rr_delta("presence", +3)

    critic_voice "You always think about it. You never do it. You always need the threat-scanner empty, and the threat-scanner is, as a feature, almost never empty."

    e "The drafting-and-not-sending is old. Noticing how old it is, and what it is bound to, is not."

    $ reco_credit("part_register_identified", "a3_mention_nim_draft_delete_pattern")

    $ act3_outcomes["mention_the_childhood_thing"] = "not_sent"
    $ renpy.fix_rollback()
    jump a3_mention_nim_close


label a3_mention_nim_close:
    scene black
    with fade
    e "The phone is face-down on the couch beside you. The night closes."
    return
