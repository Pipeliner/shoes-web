## script.rpy — entrypoint. Keep thin.
##
## Per CLAUDE.md: all correctness-critical logic lives in game/logic/ as
## plain Python. This file is Ren'Py plumbing only.

init python:
    # Make game/logic/ importable from .rpy files. This is the one place
    # init python is acceptable: it's a side-effecting import setup, not
    # runtime-mutating state.
    #
    # NOTE: `__file__` is NOT defined in Ren'Py's init-python namespace
    # (unlike a normal Python module). Use `renpy.config.gamedir` — it
    # points at the game/ directory where logic/ lives.
    import sys
    _here = renpy.config.gamedir
    if _here not in sys.path:
        sys.path.insert(0, _here)
    # Re-export the pure-Python layer under short names. In Ren'Py 8,
    # `from X import Y as Z` inside init-python binds Z as a local to
    # the init block; it is NOT automatically visible to `default`
    # expressions elsewhere in the file. Bind explicitly on the store.
    import logic.resources
    import logic.states
    import logic.gates
    import logic.parts
    import logic.recognition
    renpy.store.res = logic.resources
    renpy.store.states = logic.states
    renpy.store.gates = logic.gates
    renpy.store.parts_mod = logic.parts
    renpy.store.reco = logic.recognition
    # Back-compat aliases so scene-label `python:` blocks that already
    # reference `_res.Branch.MI` / `_res.Branch.NIM` still resolve.
    renpy.store._res = logic.resources
    renpy.store._states = logic.states
    renpy.store._gates = logic.gates
    renpy.store._parts = logic.parts
    renpy.store._reco = logic.recognition

## The narrator. Per playtest 2026-04-26: "Echo" as a label was a
## placeholder that read as a character name and confused players.
## Shoes uses second-person narration ("You sit down. The phone is
## warm.") — the narrator is the protagonist's own observing voice,
## not a separate character. Setting `name=None` removes the label
## box; `what_color` preserves the existing cyan dialogue tint.
##
## The variable name `e` is kept to avoid touching the ~510 `e "..."`
## dialogue sites. If we ever want to attribute this voice (e.g.
## "the part that watches"), do it via Character(name) here — the
## scene files don't need to change.
define e = Character(None, what_color=gui.accent_color)

## Custom transitions referenced from scene files. `dissolve` is
## built-in; `slowdissolve` is our 2-second variant used at scene
## breaks in the exile-approach scenes (a2c2 and a2c2_mi).
define slowdissolve = Dissolve(2.0)

## Persistent state — accessibility prefs, content-notice ack. Pickle-safe
## primitives only.
default persistent.content_notice_acknowledged = False
default persistent.accessibility_reduce_motion = False
default persistent.accessibility_reduce_audio = False
default persistent.accessibility_extra_large_text = False

## Mutable game state. default (not define) — saved, rolled back correctly.
default resource_snapshot = res.ResourceSnapshot(branch=res.Branch.CEN)
default parts_state = parts_mod.starter_parts_cen()
default recognition_ledger = reco.RecognitionLedger()
default current_tooltip = ""

## Per-chapter content notice flags. Key = chapter id. Set when the
## centered chapter notice is rendered (i.e. the player saw the
## heads-up). NOT a completion flag — a player who saw the notice
## and then chose "skip this chapter" still has this set.
default chapter_notice_shown = {}

## Per-chapter completion flags. Key = chapter id. Set ONLY at the
## end of the chapter's `_close` (or `_out`) label after the player
## has actually played through the scene. Use this — not
## `chapter_notice_shown` — when narrator copy elsewhere needs to
## key off whether the chapter actually happened. Introduced
## 0.1.18-15 to fix the Witnessed-ending therapist-flag bug
## (chapter_notice_shown was being read as a completion flag in
## endings.rpy:174 and lying to skip-the-chapter players).
default chapter_completed = {}

## Act III structural-change outcomes. Key = scene_id (matching
## ACT_III_STRUCTURAL_GATES). Value is one of "sent" / "not_sent" /
## "drafted" / "said" / "waited" / "not_said" / "long_sent" per
## scene. The ending_dispatch reads these to pick the right
## ending variant (e.g., "sent" on mention_the_childhood_thing
## plants the witnessed-ending trajectory).
default act3_outcomes = {}

label start:
    if not persistent.content_notice_acknowledged:
        call content_notice
    jump branch_select

label content_notice:
    scene black
    ## The notice copy + the menu are displayed via a screen with a
    ## viewport (similar to screen grounding) so the text fits at any
    ## browser-window size without pushing the menu off-screen. The
    ## previous `centered "..."` + `menu:` shape clipped on web at
    ## ~700 chars of notice text + 8 bullets — the player saw the
    ## opening lines, clicked through the centered, and landed on a
    ## dark screen because the menu had been pushed below the
    ## viewport. Surfaced 0.1.18-21 by user playtest.
    call screen content_notice_screen
    if _return == "ready":
        $ persistent.content_notice_acknowledged = True
        return
    elif _return == "not_yet":
        ## Per playtest 2026-04-26: "Not right now" routes to the main
        ## menu (not silently into branch_select).
        $ MainMenu(confirm=False, save=False)()
    return


screen content_notice_screen():
    modal True
    add Solid("#000")

    ## 1280×720 design space (gui.init in game/gui.rpy). Frame is
    ## centered, capped at 1080×680, with 40px padding — interior is
    ## 1000×600. No viewport: the body content (~590px tall) fits
    ## comfortably in the interior. Stock Ren'Py confirm() pattern,
    ## see renpy-sdk/gui/game/screens.rpy:1149.
    frame:
        xalign 0.5
        yalign 0.5
        xpadding 40
        ypadding 40
        xmaximum 1080
        ymaximum 680
        background gui.modal_frame_background

        vbox:
            spacing gui.scale(10)

            text _("Before you begin.") size gui.scale(28) color gui.accent_color

            text _("This game contains:") size gui.scale(18) color "#bbb"

            text _("- childhood emotional neglect") size gui.scale(16)
            text _("- adult discussion of trauma (not graphic)") size gui.scale(16)
            text _("- emotional flashbacks written in the first person and as verb-tense torque") size gui.scale(16)
            text _("- dissociation rendered as a narrative mode") size gui.scale(16)
            text _("- a depicted therapy session (one chapter, skippable)") size gui.scale(16)
            text _("- a depicted phone call from a parent (skippable)") size gui.scale(16)
            text _("- on the MI branch, a parent with a recurring depressive pattern") size gui.scale(16)
            text _("- on the NIM branch, a parent who is overtly contemptuous (one quoted line)") size gui.scale(16)

            text _("You can skip any chapter's heaviest content without losing continuity. Press G at any time to open a grounding screen with breathing count, crisis-resource numbers, and a close-the-game button.") size gui.scale(15) color "#bbb"

            text _("Shoes is a work of fiction that uses contemporary trauma vocabulary as a metaphorical language. It is not therapy, not a substitute for therapy, and does not represent a validated clinical approach. Players who recognize themselves are encouraged to seek qualified support.") size gui.scale(14) italic True color gui.idle_small_color

            null height gui.scale(8)

            textbutton _("I'm ready to begin."):
                action Return("ready")
                text_size gui.scale(20)

            textbutton _("Not right now. Take me back to the title screen."):
                action Return("not_yet")
                text_size gui.scale(18)

## Branch selection. Shoes has three parallel Act I paths based on the
## parent-pattern the adult protagonist grew up with: CEN (childhood
## emotional neglect — the primary path), MI (mentally-ill parent),
## and NIM (narcissistic/immature parent). All three routes use the
## same logic layer; the prose, memory textures, and parts register
## differ. The MI and NIM routes join the CEN Act III unchanged.
label branch_select:
    scene black
    with dissolve

    ## Audit O-1 closure (0.1.18-46): added the soft default
    ## recommendation. CEN is the main / most-developed path
    ## per Track A documentation; surfacing this for players
    ## who don't have a strong reason to pick MI or NIM removes
    ## the "decide between three options whose differences I
    ## don't understand" cognitive load. The recommendation
    ## stays soft (not pre-judging) — the explainer is still
    ## one click away.
    centered "Pick a starting branch.\n\nAll three branches share the same Act III and endings.\nYou can come back to this menu from a new game any time.\n\nIf you're not sure: {b}CEN{/b} is the main path. Pick that."
    pause 0.5

    menu:
        "{b}CEN{/b} — childhood emotional neglect. The main path; the complete game.":
            jump a1c1_start
        "{b}MI{/b} — a parent with a recurring mental-illness pattern. Act I complete; Act II playable through the exile approach.":
            jump a1c1_mi_start
        "{b}NIM{/b} — a narcissistic or immature parent. Act I complete; Act II Ch 1 playable.":
            jump a1c1_nim_start
        "What are these branches?":
            call branch_explainer
            jump branch_select

label branch_explainer:
    ## Branch explainer — out-of-fiction help text the player explicitly
    ## asks for ("What are these branches?"). Rendered as `centered`
    ## (third-person, design-aware) rather than `e "..."` narrator
    ## (second-person, in-fiction) per .claude/rules/voice.md rule 3
    ## (chapter notices and player-aimed help are out-of-fiction).
    ##
    ## Audit O-1 closure (0.1.18-46): rewritten to lead with
    ## experiential language (what the protagonist learned to
    ## do as a child) rather than IFS terminology (manager,
    ## firefighter, critic). The IFS vocabulary stays — useful
    ## for players who already know the framework — but is
    ## tucked at the end of each per-branch description as a
    ## parenthetical, not the lead.
    scene black
    with dissolve

    centered "The protagonist's adult patterns were shaped by the parent who raised her.\n\nThere is no one childhood. There are many childhoods, and they produce different adults who are organised around different tensions.\n\nShoes offers three Act I routes — three textures of the same adult."
    pause 1.0

    centered "{b}CEN{/b} — childhood emotional neglect.\n\nA parent physically present and emotionally absent. As a child, the protagonist learned to disappear to be safe.\n\n{i}(In IFS terms: numbing firefighter, soft ambient critic.){/i}"
    pause 1.0

    centered "{b}MI{/b} — a mentally-ill parent.\n\nOften depressive, with a recurring pattern. As a child, the protagonist became hypervigilant — listening for whether the day was a bad-stretch day or not.\n\n{i}(In IFS terms: dissociative firefighter, house-listening manager.){/i}"
    pause 1.0

    centered "{b}NIM{/b} — a narcissistic or immature parent.\n\nContempt, grandiosity, or public-humiliation patterns. As a child, the protagonist learned to scan for the cutting thing — and learned the parent's cadences well enough that her own self-criticism now wears them.\n\n{i}(In IFS terms: angry-protector firefighter, identified-with-aggressor critic.){/i}"
    pause 1.0

    centered "Pick one. The three branches share the same shape: approach rather than catharsis, no redemption arc, parts of you that have to consent before access."
    pause 1.0
    return

label act1_ch1_morning:
    # Legacy label, preserved so any existing save pointing here still
    # resolves. Routes through the branch-select menu.
    jump branch_select
