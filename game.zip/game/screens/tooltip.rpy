## screens/tooltip.rpy — global tooltip overlay for reason-token hovers.
##
## We set `current_tooltip` from hover handlers (see screens/choice.rpy).
## This overlay renders the current tooltip at the bottom of the screen.

screen tooltip_overlay():
    zorder 100
    if current_tooltip:
        frame:
            xalign 0.5
            yalign 0.92
            xpadding 20
            ypadding 12
            xmaximum 800
            text current_tooltip size 16 italic True color "#ccc"
