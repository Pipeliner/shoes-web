## scenes/act3/mention_the_childhood_thing.rpy — Act III structural-
## change scene. Scene id "mention_the_childhood_thing" — Recognition
## threshold 20 (highest tier).
##
## The 2am text-to-Ben decision. The witnessed ending refers to this
## scene: "you had already said the short version of it to him in a
## text at two in the morning, and he had written back, and the
## Saturday followed from the text." This is the decision to send.
##
## Craft discipline:
##   - Not rehearsal of trauma; just the decision.
##   - "the short version" is the specific phrase in the scene. No
##     trauma monologue. A single sentence or a line at most.
##   - Per PRD §7.1 intrusive-partial craft: we do not show what gets
##     typed. Or we show only a fragment.
##   - Success plants the witnessed-ending trajectory in the flags.
##   - Failure: deleted unsent. Not a catastrophic fail — also valid.

label a3_mention_the_childhood_thing:
    scene black
    show screen tooltip_overlay

    e "Two in the morning. You are on the couch. You cannot sleep."

    e "The laptop is closed. The phone is in your hand."

    e "Ben is awake. He is always awake at this hour; he has been a night person since you were twelve. You know this from twenty years of being his friend."

    e "You have not told him."

    e "You have meant to tell him. You have drafted telling him in your head on and off for fifteen years."

    e "He has been in your life longer than you have known there was a thing to tell, which is why he is the one you are typing at."

    pause 1.0

    e "Tonight is not different in most ways. In one way it is."

    e "You are composing a text. You have not typed anything yet."

    pause 1.0

    call screen a3_mention_menu

    if _return == "send_short":
        jump a3_mention_send
    elif _return == "send_short_refused":
        caretaker_voice "Not at two in the morning. He will think something is wrong. He is at work tomorrow."
        e "You put the phone down. The keyboard fades. You sit on the couch for a while."
        jump a3_mention_not_sent
    elif _return == "send_long":
        ## Long-version is not what the witnessed ending references.
        jump a3_mention_long_sent
    else:
        jump a3_mention_not_sent


screen a3_mention_menu():
    tag menu
    $ c_short = cc_eval(
        "send_short",
        "type the short version: one sentence about the childhood thing you have not said out loud. send.",
        guard_keys=("not_fawn_active", "not_flooded"),
        npc="ben",
        refuse_on_block=True,
    )
    $ c_long = cc_eval(
        "send_long",
        "type the long version: everything, in a wall of text. send.",
        guard_keys=(),
    )
    $ c_delete = cc_eval(
        "delete",
        "type the short version. read it twice. delete it. try again tomorrow.",
        guard_keys=(),
    )
    $ c_put_down = cc_eval(
        "put_down",
        "put the phone down. do not type tonight.",
        guard_keys=(),
    )

    frame:
        xalign 0.5
        yalign 0.5
        xpadding 28
        ypadding 28
        xmaximum 800

        vbox:
            spacing 10
            text "What do you do?" size 22
            use gated_choice_row(c_short, Return("send_short"))
            use gated_choice_row(c_long, Return("send_long"))
            use gated_choice_row(c_delete, Return("delete"))
            use gated_choice_row(c_put_down, Return("put_down"))
            use tooltip_footer


label a3_mention_send:
    scene black
    with fade

    ## The intrusive-partial craft per PRD §7.1: only a fragment of
    ## the text surfaces. Branch-aware so the surfaced fragment
    ## matches the branch's childhood signature (CEN: yellow-
    ## wallpaper kitchen at 13; MI: hallway at 8; NIM: dining
    ## room at 11). Note (S3 0.1.18-46): in practice MI/NIM
    ## players reach mention_the_childhood_thing_mi.rpy and _nim
    ## via dispatcher routing, not this file. The branch-
    ## conditional below is technically dead-code-on-MI-NIM, kept
    ## intact so the branch-parity test (`test_no_foreign_branch
    ## _signature_in_player_facing_speech`) recognises the
    ## CEN-signature line as legitimately gated.
    ## Flashback uses intrusive_partial.wallpaper_line
    e "You type one sentence."

    e "You type: "

    if resource_snapshot.branch == res.Branch.MI:
        exile_voice "i was eight and i was outside her bedroom door and i could hear her not moving."
    elif resource_snapshot.branch == res.Branch.NIM:
        exile_voice "i was eleven and i was in a pale blue dress and the room was laughing."
    else:
        exile_voice "the kitchen had yellow wallpaper and i was on the floor."

    pause 2.0

    e "You delete the beginning of the sentence. 'there is something i want to tell you' is not what you type. The sentence is the sentence."

    e "You press send."

    pause 1.0

    e "The message sends at 02:14 local."

    e "Ben's typing indicator appears at 02:14 and a half."

    pause 1.0

    e "You close your eyes."

    ## Big state shift. Self_trust up significantly. Permission up.
    ## Connection with Ben up. Flashback pressure up (the sentence
    ## was expensive to type).
    $ rr_delta("self_trust", +12)
    $ rr_delta("permission", +6)
    $ rr_npc_delta("ben", +10, safe=True)
    $ rr_delta("flashback_pressure", +10)
    $ rr_delta("presence", -4)

    critic_voice "You did not have to do that. You could have let it go another fifteen years."

    $ rr_delta("critic_volume", +5)

    e "The Critic's line is the Critic's line."

    ## This is the scene the witnessed ending references. Flag it.
    $ act3_outcomes["mention_the_childhood_thing"] = "sent"
    $ renpy.fix_rollback()

    ## Highest-tier Recognition credits.
    $ reco_credit("sat_with_exile", "a3_mention_short_version_sent")
    $ reco_credit("named_flashback", "a3_mention_wallpaper_line")

    flame "you sent the short version. that sentence did not exist in a message from you before tonight. now it does."

    
    jump a3_mention_close


label a3_mention_long_sent:
    scene black
    with fade
    e "You type a wall of text. You re-read the wall of text. The wall of text is fifteen years."

    e "You send it anyway."

    pause 1.0

    e "Ben does not respond for forty minutes."

    e "When Ben responds, he says: that is a lot. can we talk on saturday."

    pause 1.0

    e "You say yes. You put the phone face-down. You do not sleep."

    $ rr_delta("self_trust", +6)
    $ rr_delta("flashback_pressure", +18)
    $ rr_delta("presence", -10)
    $ rr_npc_delta("ben", +6, safe=True)

    e "The long version cost more than the short would have. You notice the cost. You notice also that Ben said 'saturday.'"

    $ act3_outcomes["mention_the_childhood_thing"] = "long_sent"
    $ renpy.fix_rollback()
    $ reco_credit("named_flashback", "a3_mention_long_version_sent")

    flame "sending the long version is a thing that happens. sending the short version would have been a different thing. both are real."

    
    jump a3_mention_close


label a3_mention_not_sent:
    scene black
    with fade

    e "Tomorrow comes. You did not send."

    e "You do not send on tuesday either. Or wednesday."

    $ rr_delta("self_trust", -3)
    $ rr_delta("critic_volume", +4)
    $ rr_delta("presence", +3)

    critic_voice "You always think about it. You never do it."

    e "The drafting-and-not-sending is old. Noticing how old it is is not."

    $ reco_credit("part_register_identified", "a3_mention_draft_delete_pattern")

    $ act3_outcomes["mention_the_childhood_thing"] = "not_sent"
    $ renpy.fix_rollback()
    jump a3_mention_close


label a3_mention_close:
    scene black
    with fade
    e "The phone is face-down on the couch beside you. The night closes."
    return
