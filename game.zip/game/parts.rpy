## parts.rpy — Ren'Py screen + label scaffolding for parts work.
##
## Negotiation loop UI and helpers. Actual part state lives in
## game/logic/parts.py. See .claude/rules/parts-language.md for the
## language discipline: always "a part of you," never "your parts."

init python:
    def pp_intervene(intervention_key, part_name):
        """Apply a negotiation intervention to a part. intervention_key is
        one of 'listen', 'ask', 'disagree', 'defer', 'override'."""
        from logic.parts import Intervention, apply_intervention
        global resource_snapshot, parts_state
        result = apply_intervention(
            Intervention(intervention_key),
            part_name,
            resource_snapshot,
            parts_state,
        )
        renpy.store.resource_snapshot = result.snapshot
        renpy.store.parts_state = result.parts
        return result.part_response_key

    def pp_override_available():
        from logic.parts import override_available
        return override_available(resource_snapshot)

    def pp_firefighter_seizing():
        from logic.parts import firefighter_seizing
        return firefighter_seizing(parts_state)

    def pp_exile_gate():
        from logic.parts import exile_gate
        return exile_gate(resource_snapshot, parts_state)


## The negotiation-loop screen. Invoked from scene labels via `call screen
## negotiate(...)`. The caller passes a part name and the part's opening
## line; this screen lays out the five intervention verbs plus
## "override" (only when available).
screen negotiate(part_name, opening_line):
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        xpadding 40
        ypadding 40
        xmaximum 900

        vbox:
            spacing 20

            text opening_line size 24 italic True

            text _("How do you respond?") size 18

            vbox:
                spacing 6

                textbutton _("listen"):
                    action Return(("listen", part_name))
                    tooltip _("stay with what the part is saying")

                textbutton _("ask what it is trying to do for you"):
                    action Return(("ask", part_name))
                    tooltip _("the question that actually moves things")

                textbutton _("disagree gently"):
                    action Return(("disagree", part_name))
                    tooltip _("a small, respectful no")

                textbutton _("defer — agree to wait"):
                    action Return(("defer", part_name))
                    tooltip _("not this time")

                showif pp_override_available():
                    textbutton _("override"):
                        action Return(("override", part_name))
                        tooltip _("push through; the part's trust in you will drop")

                ## If override is not available, we still show it —
                ## visibly unavailable with its reason. This is the
                ## central mechanic.
                ##
                ## Reason string sourced from the ReasonToken enum
                ## per CLAUDE.md non-negotiable rule 3 (no hand-
                ## authored reasons in scene/screen files). Earlier
                ## drafts hand-authored "requires high permission
                ## and self-trust" here; closed by 0.1.18-21 (F4
                ## from docs/prd-compliance-audit-0.1.18-17).
                showif not pp_override_available():
                    textbutton _("override"):
                        action NullAction()
                        sensitive True
                        hovered SetVariable(
                            "current_tooltip",
                            gates.reason_long(gates.ReasonToken.OVERRIDE_NOT_READY)
                        )
                        unhovered SetVariable("current_tooltip", "")

            ## Tooltip rendering: the global tooltip_overlay (screens/
            ## tooltip.rpy) handles the display at an absolute screen
            ## position. Inline rendering inside this vbox would reflow
            ## the menu on hover and produce blinking — see the
            ## tooltip_footer comment in screens/choice.rpy.
