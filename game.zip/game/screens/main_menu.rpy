## screens/main_menu.rpy — custom main menu.
##
## Per docs/renpy-flow-best-practices.md item 1: Ren'Py's default
## `screen main_menu()` has Start / Load / Preferences / Help /
## Quit, with NO Continue button. So when a chapter-end `return`
## (the "stop here for now" path) drops a player at the main menu,
## the most prominent option is "Start" — and clicking that
## re-runs `start:` → `branch_select`, producing the "looping back"
## symptom the playtest report 2026-04-26 surfaced.
##
## The fix: define a custom main_menu that adds Continue when a
## save exists. Continue resumes the most recent slot (Ren'Py's
## newest_slot), so the player who picks "stop here for now"
## actually CAN come back where they left off.
##
## All other navigation (Load to pick a specific slot, Preferences,
## Quit) remains.
##
## Defensive helper for the Continue button — per .claude/rules/
## clarity.md rule 7. Ren'Py's newest_slot() / can_load() can both
## raise on weird save state, and on a clean install newest_slot()
## may return None (which `renpy.can_load(None)` doesn't accept).
## Wrapped in try/except so the menu screen never crashes.

init python:
    def _has_continueable_save():
        """True if there is a save we can show Continue for.
        False on any error — Continue is hidden, never broken."""
        try:
            slot = renpy.newest_slot()
            if not slot:
                return False
            return bool(renpy.can_load(slot))
        except Exception:
            return False


screen main_menu():
    tag menu

    ## Black background; we don't ship a custom title-screen image
    ## yet. The text-only menu matches the rest of the game's
    ## minimal-chrome aesthetic.
    add Solid("#000")

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 18

        text _("Shoes"):
            xalign 0.5
            size 64
            color gui.accent_color

        text _("v[config.version]"):
            xalign 0.5
            size 14
            color "#666"

        null height 24

        ## Start: fresh new game.
        textbutton _("Start"):
            xalign 0.5
            text_size 28
            action Start()

        ## Continue: resume the newest save (autosave or manual).
        ## Only shown when a save actually exists. Helper above
        ## wraps the underlying calls in try/except per clarity
        ## rule 7 — the menu screen must not crash on bad save state.
        if _has_continueable_save():
            textbutton _("Continue"):
                xalign 0.5
                text_size 28
                action Continue()

        textbutton _("Load"):
            xalign 0.5
            text_size 24
            action ShowMenu("load")

        textbutton _("Preferences"):
            xalign 0.5
            text_size 24
            action ShowMenu("preferences")

        textbutton _("Quit"):
            xalign 0.5
            text_size 24
            action Quit(confirm=False)
