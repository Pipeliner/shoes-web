# GEN-CHECKSUM: 4b7496d10131d057
## Flashback snippets — technique: parallel_action_cut
## Two scenes (present, past) alternate at paragraph breaks; no transitions.
##
## Generated from parallel_action_cut.yaml. Hand-edit below the
## GEN-CHECKSUM line preserved by --force only.
##
## This file is a reference catalog, not live scene code.
## Scene authors grep for snippet IDs, then hand-adapt
## the prose into the target scene's voice. Do not
## import this file or reference its contents at runtime.

## --- snippet: email_and_hallway ---
## present_thread:
##   'the protagonist sitting on the floor of the present apartment, holding the open email'
## past_thread:
##   'the protagonist, age eight, sitting in a hallway near a telephone table'
## cuts:
##   present: 'You sit down where you are.'
##   past: 'There is a hallway with a telephone table in it. You are eight.'
##   present: 'The chair holds.'
##   past: 'The hallway has wallpaper.'
##   weave: 'The room has a laptop.'
##   bridge: 'You are eight and you are thirty-four.'
##   return_to_present_only: 'You are holding the email open with your thumb.'

## --- snippet: kitchen_morning_weave ---
## present_thread:
##   "making coffee in the protagonist's adult apartment"
## past_thread:
##   'watching someone make coffee in the childhood apartment'
## cuts:
##   present: 'You put the filter in. You measure the grounds.'
##   past: 'Your mother measured the grounds by tilting the bag and watching the line in the filter paper.'
##   present: 'You tilt the bag the same way.'
##   past: 'She did not measure by scale. You did not either.'
##   return: 'The coffee maker hums. The hum is the hum.'

