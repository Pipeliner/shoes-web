## scenes/act2/chapter4_mi.rpy — MI-bias variant of the Flame / journal.
##
## CEN equivalent: scenes/act2/chapter4.rpy. This file mirrors the
## five-beat structural arc of the CEN file (notice + opening; first-
## prompt menu with four options; second-prompt menu with three
## options; close; skipped). Flame's voice is identical across
## branches: lowercase, journal-companion, addresses the protagonist
## as "you" and may use "I" for its own asides.
##
## The only mechanical change vs. CEN is Option 1 of the first-prompt
## menu. CEN's Option 1 names the dissociative firefighter as "the
## part of you that closed the laptop"; the MI dissociative firefighter
## is the one that "takes you out of the room" — a mental departure,
## not a physical one. The phrasing is anchored in
## chapter1_mi.rpy:96-103 ("you are somewhere mostly-not-here for
## maybe a minute. you come back. you are not sure how long it's
## been.") and reused in chapter2_mi.rpy:51 ("I have not agreed to
## stop taking you out of the room").
##
## Options 2-4 are branch-agnostic in copy. The MI player's mental
## model of "a younger you" (second-prompt Option B) is the eight-
## year-old in the hallway by the bible's branch coding; the prompt
## itself stays age-agnostic per the 0.1.18-14 fix at chapter4.rpy:111-113.
##
## State effects mirror chapter4.rpy: small +permission, +self_trust,
## +presence, +interoception; -critic_volume on the Critic-verbatim
## prompt.

label a2c4_mi_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c4_mi", False):
        centered "Chapter Seven — Act II (continued, MI branch)\n\nThis chapter is a between-scene reflection. No sensitive content."
        $ chapter_notice_shown["a2c4_mi"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c4_mi_skipped

    scene black
    with dissolve

    e "It is Friday. You are at the kitchen table. The light at this hour makes the wood look warm in the way wood does not usually look warm."

    e "You open the journal. The cursor blinks the way cursors blink."

    flame "a few questions, if you want them. pick one, or skip."

    menu:
        "what did the part of you that took you out of the room need today?":
            ## The MI dissociative firefighter — the one that, when a
            ## room becomes unstayable, sends the protagonist somewhere
            ## mostly-not-here for a minute. Not a physical leaving;
            ## the body stays at the table. See a2c1_mi.rpy:96-103.
            flame "the one that goes somewhere mostly-not-here when a room gets too full. let it answer."
            e "You write for a while. You do not stand up. The kitchen does not change. The writing is the only part of you that goes anywhere."

            $ rr_delta("permission", +4)
            $ rr_delta("self_trust", +3)
            $ rr_delta("presence", +3)
            $ rr_delta("interoception", +3)
            $ reco_credit("reflection_completed", "a2c4_mi_caretaker_needs")

            flame "that was not a small thing you just did."
            jump a2c4_mi_second_prompt

        "what did a smaller voice inside you say, that you did not write down?":
            flame "you can leave this one unwritten."
            e "You do. You notice the not-writing."

            $ rr_delta("presence", +5)
            $ rr_delta("interoception", +5)
            $ reco_credit("part_register_identified", "a2c4_mi_exile_unwritten")

            flame "noticing without writing is a kind of writing. a different one."
            jump a2c4_mi_second_prompt

        "what did the critic say this week — word for word, not the gist?":
            ## The MI Critic register established at a2c1_mi.rpy:157
            ## ("you always archive") informs the verbatim here.
            flame "verbatim is useful. the gist smooths things."
            e "You write the verbatim. The words land on the page differently than they land in the head."

            $ rr_delta("critic_volume", -6)
            $ rr_delta("self_trust", +4)
            $ rr_delta("permission", +3)
            $ reco_credit("reflection_completed", "a2c4_mi_critic_verbatim")

            flame "on the page, that one is smaller than it is in your head."
            jump a2c4_mi_second_prompt

        "just sit with it; no question today":
            flame "ok."
            e "The cursor blinks. The light stays warm on the wood."
            pause 1.0
            $ rr_delta("presence", +4)
            $ rr_delta("regulation", +4)
            jump a2c4_mi_close

        "what about the small one who waited for the dog who did not come back?":
            ## Branch-neutral childhood-attachment-loss prompt — mirror
            ## of the CEN a2c4 dog-given-away path. Per docs/continuity.md
            ## "Childhood pet (Mishka, given away)": age 7, branch-neutral
            ## abandonment-template anchor that does not collide with the
            ## three branch childhood signatures (CEN yellow-wallpaper
            ## kitchen at 13, MI hallway-with-telephone-table at 8, NIM
            ## dining-room-with-six-adults at 11). The figure who took
            ## the dog is unnamed; the abandonment-template is the
            ## figure-and-the-going, not who-did-it. Exile-voice register
            ## per parts-language.md.
            flame "the small one who watched the door for a long time. let her answer."

            exile_voice "Mishka has a leash. The leash hangs on a hook by the door."

            exile_voice "I am seven. I am in the chair near the door because the chair near the door is where you wait."

            exile_voice "My shoes are still on. You don't take your shoes off when you're waiting."

            exile_voice "On Saturday someone takes Mishka somewhere. Someone comes back. Mishka does not come back."

            exile_voice "The hook is empty. The hook stays empty. I look at it for a long time."

            e "You are at the kitchen table. The light is still warm on the wood. You write, slowly, what the small one in the chair would not have known how to write."

            $ rr_delta("permission", +4)
            $ rr_delta("interoception", +4)
            $ rr_delta("self_trust", +3)
            $ reco_credit("part_register_identified", "a2c4_mi_dog_given_away")

            flame "you sat in the chair with her for a minute. that is what the page was for."
            jump a2c4_mi_second_prompt


label a2c4_mi_second_prompt:
    ## Optional second prompt. Recognition source; cheaper than the
    ## first — avoiding grinding.
    flame "one more, if you want it."

    menu:
        "say what you would have said to lena this week, and didn't":
            e "You write what you would have said. It is not elegant. It is not the point."
            $ rr_delta("permission", +3)
            $ rr_delta("self_trust", +3)
            $ reco_credit("reflection_completed", "a2c4_mi_unsaid_to_lena")
            flame "it does not need to be elegant. it needs to exist."
            jump a2c4_mi_close

        "say what you would have said to a younger you":
            ## Age-agnostic on purpose, per the 0.1.18-14 fix at
            ## chapter4.rpy:111-113. The MI player's mental model is
            ## the eight-year-old in the hallway; the prompt does not
            ## name the age.
            e "You write a short sentence. Five words. You cross them out. You write them again."
            $ rr_delta("permission", +4)
            $ rr_delta("self_trust", +4)
            $ rr_delta("critic_volume", -3)
            $ reco_credit("part_register_identified", "a2c4_mi_younger_self_letter")
            flame "you will not always have the words. you wrote them this time."
            jump a2c4_mi_close

        "close the journal":
            flame "ok. another friday."
            jump a2c4_mi_close


label a2c4_mi_close:
    scene black
    with fade

    ## Owner of `chapter_completed["a2c4_mi"]` per docs/state-ownership.md:
    ## set FIRST after `scene black`, before any prose. The skipped
    ## label does NOT set this flag — that is the point.
    $ chapter_completed["a2c4_mi"] = True

    flame "the friday pages are for noticing, not fixing."
    flame "you noticed. that is the whole assignment."

    e "You close the laptop. The afternoon is the afternoon. Your feet are not cold today."

    menu:
        "continue to Chapter Eight (MI)":
            jump a2c5_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c4_mi_skipped:
    scene black
    centered "Chapter Seven (MI variant) was skipped."
    pause 1.5
    e "Friday was Friday. You did not write."
    e "There is no penalty for not writing. The journal is still there, next week."

    menu:
        "continue to Chapter Eight (MI)":
            jump a2c5_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
