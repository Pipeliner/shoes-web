## scenes/act1/chapter2_mi.rpy — Act I Ch 2 MI-branch variant.
##
## CEN Ch 2 Mother is distant / guilt-trippy. MI Ch 2 Mother is
## *depleted*. Subtype: severe recurring depressive episodes. The
## house of the protagonist's childhood was organized around whether
## Mother was in a bad stretch or not. As an adult, the protagonist
## scans the first ten seconds of every call for warning signs.
##
## Per PRD §4.3 MI branch:
##   - Dominant 4F pull: freeze.
##   - Parts skew toward hypervigilant managers + dissociative firefighter.
##   - BRANCH_BIAS[MI]: PRESENCE ×1.3 worse/0.8 better, INTEROCEPTION
##     ×1.2 worse/0.8 better, FLASHBACK_PRESSURE ×1.2 worse.
##
## Flashback uses verb_tense_torque.hallway_telephone_table_eight
## adapted for MI-context: the childhood phone is not the kitchen
## guilt-trip phone but the hallway phone outside Mother's bedroom,
## where the protagonist stood while deciding whether to go in.
##
## Craft discipline (MI-specific):
##   - Silence from Mother is not absence; it is weather.
##   - The protagonist's voice shrinks on the call. Verbs get
##     passive. Sentences get shorter. This is freeze-on-the-page.
##   - The hypervigilant manager is not managing compliance; it is
##     running symptom checklists.

label a1c2_mi_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a1c2_mi", False):
        centered "Chapter Two — MI branch\n\nA phone call from Mother. Mother on this path has a history of recurring severe depressive episodes; the chapter acknowledges that some past stretches have ended with hospitalisation. The protagonist scans every call for warning signs. Scene is skippable at the scene level and chapter level. Contains a brief childhood flashback via verb-tense-torque; no visual effect."
        $ chapter_notice_shown["a1c2_mi"] = True
        pause 2.0

    menu:
        "begin chapter two (MI)":
            pass
        "skip this chapter":
            jump a1c2_mi_skipped

    scene black
    with dissolve

    e "The phone rings. It is her ringtone — the one you have had for twelve years because changing it would mean saying something to her you have not yet been able to say."

    caretaker_voice "Wait. Listen to the ring. How many rings before she picks up when you call her? Four. How many rings is she at on this one? Two. Two is not four. Two is fine."

    e "The hypervigilant part of you is doing inventory before you pick up. This is the part that has kept you alive."

    menu:
        "answer":
            jump a1c2_mi_answer
        "let it go to voicemail":
            jump a1c2_mi_voicemail
        "skip the whole scene":
            jump a1c2_mi_skipped


label a1c2_mi_answer:
    scene black
    mother "Hi."

    ## This single word is the signal. The protagonist is already
    ## scanning for vocal cues.
    ##
    ## First use of the family idiom "bad stretch" — define it
    ## in-character before the protagonist starts scanning Mother's
    ## pitch against it. Per .claude/rules/clarity.md (in-character
    ## idioms get an implicit definition on first encounter).
    e "Mother has stretches. The bad ones are weeks of not getting out of bed; the good ones look almost like other people's lives. You have been listening to her voice for which stretch we are in since you were a child."

    e "Some stretches ended in a hospital. Others ended with soup at the kitchen table again. You learned to tell them apart before you knew the words."

    e "You listen to the word. The word is the signal. 'Hi' at this pitch, on a Tuesday, not in a bad stretch. 'Hi' at half this pitch on a Tuesday would be a different Tuesday."

    $ rr_delta("threat_scan", +10)
    $ rr_delta("presence", -6)
    $ rr_delta("energy", -3)

    e "You say hi back. You hold the pitch of your own hi the way she holds the pitch of hers — it is a habit from long ago."

    mother "I made the soup. The one with the barley. I remembered I hadn't in a while."

    ## This is a good sign. The hypervigilant part notes it.
    caretaker_voice "Soup is good. Barley is even better. Barley requires pre-soaking. Pre-soaking requires an afternoon of intention. We are not in a bad stretch this week."

    $ rr_delta("threat_scan", -4)
    $ rr_delta("regulation", +3)

    menu:
        "say: that sounds nice":
            jump a1c2_mi_soup_nice
        "ask: how are you sleeping":
            jump a1c2_mi_sleep_check
        "say nothing for a moment":
            jump a1c2_mi_silent_check


label a1c2_mi_soup_nice:
    scene black
    e "You say: \"That sounds nice.\" You hold the pitch light. You do not ask whether she ate any of it yet."

    mother "Mm."

    pause 1.0

    mother "Anyway. I called to see how you are."

    e "She called to see how you are. She called to see how you are. She has not asked how you are for — you track this — nine weeks."

    $ rr_delta("presence", +3)
    $ rr_delta("self_trust", +2)

    e "You do not know what to do with the asking. You say the thing you say, which is 'fine.'"

    $ rr_delta("critic_volume", +4)
    $ rr_delta("self_trust", -2)

    critic_voice "You said fine. You always say fine. She asked you a question for the first time in nine weeks and you said fine."

    $ act1c2_mi_outcome = "soup_nice_said_fine"
    jump a1c2_mi_after_call


label a1c2_mi_sleep_check:
    scene black
    e "\"How are you sleeping?\""

    pause 1.5

    mother "Oh. You know."

    e "You do know. You have known for as long as you have known what a sleep is."

    mother "I was up until four last night. Not the bad kind. Just — awake."

    e "\"Just awake\" is a specific phrase. \"Just awake\" is the phrase she uses when she is awake but not dangerously awake. The hypervigilant part of you files the phrase under its correct heading."

    $ rr_delta("threat_scan", +4)
    $ rr_delta("self_trust", +4)
    $ rr_delta("permission", +2)

    ## A small Recognition — the player noticed the calibration
    ## the hypervigilant part is doing.
    $ reco_credit("part_register_identified", "a1c2_mi_phrase_calibration_noticed")

    mother "How are you?"

    menu:
        "say: tired":
            e "You say tired. It is a true word. It is not most of the truth."
            $ rr_delta("self_trust", +3)
            $ rr_delta("social_battery", -4)
        "say: a little dissociating today":
            e "You say it and then immediately wish you had not. She does not know what the word means in this context. She has her own things."
            mother "Oh?"
            e "You pivot. You change the subject."
            $ rr_delta("critic_volume", +4)
            $ rr_delta("self_trust", +2)
        "say: fine":
            $ rr_delta("critic_volume", +4)

    $ act1c2_mi_outcome = "sleep_check"
    jump a1c2_mi_after_call


label a1c2_mi_silent_check:
    scene black
    e "You say nothing for a moment. You let the line hold."

    e "The silence is a test. She will either say something that fills the silence with a specific kind of content, or she will let it be."

    pause 2.0

    mother "...you there?"

    e "'You there' at this tempo means she is not in the bad stretch. The hypervigilant part of you exhales a breath you had not noticed you were holding."

    $ rr_delta("threat_scan", -6)
    $ rr_delta("presence", +4)
    $ rr_delta("regulation", +5)
    $ rr_delta("interoception", +4)

    e "You say: \"yeah. here. sorry.\""

    mother "Okay."

    ## A REFLECTION credit — letting the silence hold is a noticing
    ## practice in itself.
    $ reco_credit("reflection_completed", "a1c2_mi_silence_test_pass")

    $ act1c2_mi_outcome = "silent_check"
    jump a1c2_mi_after_call


label a1c2_mi_voicemail:
    scene black
    e "You press the button that sends it to voicemail. You did not decide that with a sentence; your thumb did it."

    firefighter_voice "There. Now we don't have to scan today."

    e "The Firefighter takes over for a breath. You put the phone face-down. You sit for a minute with the decision."

    $ rr_delta("presence", -4)
    $ rr_delta("critic_volume", +5)
    $ rr_delta("self_trust", +3)

    critic_voice "You could have answered. It would have been a normal Tuesday call. You chose not to be able to know that."

    e "The Critic is saying a partial truth. The asymmetry is: if you answered and it was a bad stretch, you would have spent the evening on the bad stretch. If you did not answer, you are spending the evening wondering whether you missed a bad stretch."

    $ reco_credit("part_register_identified", "a1c2_mi_voicemail_asymmetry")

    $ act1c2_mi_outcome = "voicemail"
    jump a1c2_mi_after_call


label a1c2_mi_after_call:
    scene black
    with fade

    ## Verb-tense-torque flashback per verb_tense_torque.yaml adapted
    ## for MI-context. The childhood phone is not the kitchen phone;
    ## it is the hallway phone outside Mother's bedroom door. The
    ## non_flashback that precedes it stages the contrast PRD §7.1
    ## anticipates: the first reach lands as a no-landing; the second
    ## as a verbatim childhood room.
    e "After. The phone face-down. The apartment is the apartment."

    ## Flashback uses non_flashback.what_she_said_after
    e "You try to remember what she said after you put the phone down."
    e "You know she said something. You know you answered. You know the answer was a sentence with three words in it, maybe four."
    e "The three words are not available to you."

    e "There is a hallway with a telephone table in it. You are eight. You are standing outside a closed door."

    e "The door is the door to her bedroom. You are deciding whether to knock. You are counting to ninety before you decide."

    e "You are older. You are in your own apartment. The door is not a door; the door is an open doorway. Nobody is behind it."

    $ rr_delta("flashback_pressure", +8)
    $ rr_delta("presence", -4)

    flame "the calibration part of you did not choose to be the calibration part of you. it was a small child once who became the calibration part by necessity. today is not the day it retires."

    ## Audit P-11 closure (0.1.18-46): NAMED_FLASHBACK source. The
    ## hallway-with-telephone-table at eight during the call was a
    ## flashback. Same shape as a1c2.rpy (CEN) and a1c2_nim.rpy.
    menu:
        "name what just happened":
            e "You name it. You say to yourself: that was a flashback. The hallway at eight, the telephone table, the closed door, the count to ninety. You are at this apartment now. You are not eight in the hallway."
            $ rr_delta("self_trust", +3)
            $ rr_delta("presence", +2)
            $ reco_credit("named_flashback", "a1c2_mi_hallway_flashback")
        "let it pass":
            e "You let it pass. The hallway has been the hallway at eight many times before; it will be again. You do not have to name it every time."
            $ rr_delta("regulation", +2)

    ## Reflection.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a1c2_mi_feeling")

    menu:
        "continue to Chapter Three (MI)":
            jump a1c3_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a1c2_mi_skipped:
    scene black
    centered "Chapter Two (MI variant) was skipped."
    pause 1.5
    e "The phone rang. You did what you did. The day continued."
    $ rr_delta("threat_scan", +4)

    menu:
        "continue to Chapter Three (MI)":
            jump a1c3_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
