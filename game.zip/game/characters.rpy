## characters.rpy — Character() definitions.
##
## Narrator 'e' is declared in script.rpy. This file declares NPCs and the
## distinct voice registers that the parts system uses.

## NPCs
##
## Naming policy (see .claude/rules/naming.md, codified 0.1.18-18):
## non-fancy, internationally recognisable names; no abbreviations
## (no "R."); no clearly-marked single-language diminutives (no
## "Vitya"). Names should read in English, internationally, and in
## Russian transliteration where possible. Easily distinguishable
## from each other.
##
## Cast roster + protagonist's relationship to each:
##
## - **Lena**: the protagonist's **sister**. Lives with the protagonist
##   in the present-day apartment. Chronically depressed in her own
##   way. The protagonist's CEN-shaped Caretaker reactivates around
##   her every morning — a present-tense replay of the parentified-
##   child dynamic she grew up in.
## - **Sam**: the protagonist's **romantic partner**, **not** cohabiting.
##   Active, social, restaurant-picking, holds-hands-on-corners. They
##   have been together for years; they have not lived together; that
##   is one of the things between them.
##   (Earlier name "R." renamed 0.1.18-18 per the no-abbreviations
##   rule. Variable also renamed `r` → `sam`.)
## - **Ben**: the protagonist's **long-term friend** of twenty years.
##   Local. Night person. Witnessed-ending confidant.
##   (Earlier name "Vitya" renamed 0.1.18-18 per the no-clear-
##   russianisms rule. Variable also renamed `vitya` → `ben`.)
## - **Marina**: Ben's sister; quiz-night scorekeeper.
## - **Tom**: NIM-branch standup colleague (was "Marek").
## - **Tamara**: Mother's friend (mentioned in NIM Ch 2 phone call).
## - **Mother / Aunt / Therapist / Instructor**: roles.
## - **Ada**: reserved name, no scenes yet (was "Nadia").
##
## See docs/character-r-lena-reconciliation-0.1.18-14.md for the
## sister-vs-partner reconciliation history and
## docs/continuity.md for the full bible.
define lena = Character("Lena", color="#b3c9d6")
define sam = Character("Sam", color="#d6b3b3")
define ben = Character("Ben", color="#b8c2a8")
define ada = Character("Ada", color="#cda0b8")
define mother = Character("Mother", color="#a89870")
define therapist = Character("Therapist", color="#8fb89e")
define instructor = Character("Instructor", color="#a8b8c2")
define architect_voice = Character("Senior architect", color="#c2b8a8")

## Back-compat speak-prefix aliases (`r = sam`, `vitya = ben`,
## `nadia = ada`) were removed in 0.1.18-40, and the DATA-LAYER
## NPC keys followed in 0.1.18-42 — `connection_per_npc` dicts and
## `rr_npc_delta(...)` calls now use the canonical "sam" / "ben" /
## "ada" strings throughout. No save-migration shim was needed
## (project is pre-release, no shipped saves to protect). The
## structural test
## `tests/test_rpy_structure.py::test_no_legacy_character_speak_
## prefix_aliases` prevents `r/vitya/nadia` re-introduction at the
## Character-variable layer.

## Parts-voice characters.
## IMPORTANT writing rule (see .claude/rules/parts-language.md):
##   - Parts speak as "I" or via a pattern of phrasing, not by their own name.
##   - Never "your parts" in UI or narration. Always "a part of you."
##   - Inner Critic = second person, absolutism, tense-collapse.
##   - Exile = present tense, small sensory detail, child-age vocab.
define caretaker_voice = Character(
    "a part of you",
    who_color="#87755a",
    what_italic=True,
)
define firefighter_voice = Character(
    "a part of you",
    who_color="#6a7a7d",
    what_italic=True,
)
define critic_voice = Character(
    "a voice",
    who_color="#8b4c4c",
    what_italic=False,
    what_bold=False,
)
define exile_voice = Character(
    "a smaller voice",
    who_color="#9a8ca3",
    what_italic=True,
    what_size=22,
)

## "Flame" — LOKI-GPT-descended companion voice. Used in reflection scenes,
## not as a therapist. See PRD §4.6 — this is a storytelling device, not
## a simulated helper. Copy must never offer diagnosis or advice.
define flame = Character("the journal", color="#c8a07a", what_italic=True)
