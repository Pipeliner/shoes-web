## scenes/act2/chapter2_mi.rpy — Act II Ch 2 MI-branch exile-approach variant.
##
## Same exile-gate mechanic as CEN (PRD §4.6 + amendment A1):
##   - permission >= PERMISSION_MIN_EXILE (65)
##   - Both Manager and Firefighter have consented in a prior scene
##
## Different exile-scene prose:
##   - CEN exile: the quiet child on the cold kitchen squares,
##     waiting for Mother who is physically absent.
##   - MI exile: the eight-year-old standing outside Mother's
##     bedroom door, counting to ninety before knocking. Mother
##     is behind the door but she is not absent in the same way
##     — she is in a depressive stretch, in bed, and the child
##     has been calibrating since before they were old enough to
##     name the calibration.
##
## Same Recognition credit type (SAT_WITH_EXILE) but different
## event_id so a player who runs both branches accumulates both.

label a2c2_mi_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c2_mi", False):
        centered "Chapter Five — MI branch\n\nBrief contact with a childhood part of the protagonist. Present tense, small sensory detail. The MI-branch exile is eight, standing outside a bedroom door. Scene is skippable."
        $ chapter_notice_shown["a2c2_mi"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c2_mi_skipped

    ## Same gate evaluation as CEN. The gate does not know about branches.
    $ gate = pp_exile_gate()

    if gate.approved:
        jump a2c2_mi_approved
    else:
        jump a2c2_mi_gated


label a2c2_mi_gated:
    scene black
    e "There is a quieter part of you in the next room, so to speak."
    e "You can feel that there is a next room."

    if gate.missing_manager_consent and gate.missing_firefighter_consent:
        caretaker_voice "I am still doing the inventory. I have not agreed to this yet."
        firefighter_voice "And I have not agreed to stop taking you out of the room."
        e "Two parts of you are standing in front of the door. They are not hostile. They have not yet said yes."
    elif gate.missing_manager_consent:
        caretaker_voice "I am still doing the inventory. I have not agreed to this yet."
        e "The hypervigilant part is standing in front of the door. Not to stop you. To finish the inventory that keeps it — keeps you — safe."
    elif gate.missing_firefighter_consent:
        firefighter_voice "I have not agreed to stop taking you out of the room."
        e "The dissociative part is standing in front of the door. It does not trust you to stay in a room you cannot stay in."

    if gate.permission_too_low:
        e "Something else is also not yet in place. A kind of internal permission. It is not something you can decide from the outside."
        e "It grows when the parts in front of the door feel heard."

    e "The next room will still be there, later."

    menu:
        "sit with the part of you that is not yet ready":
            if gate.missing_manager_consent:
                $ which = "caretaker"
                caretaker_voice "Thank you for waiting. The inventory is long."
            elif gate.missing_firefighter_consent:
                $ which = "numb-out"
                firefighter_voice "Thank you for not pushing."
            else:
                $ which = "caretaker"
            $ intervention = renpy.call_screen(
                "negotiate",
                part_name=which,
                opening_line="I am not yet ready for you to go further. Ask me what I am trying to do for you.",
            )
            if intervention is None:
                $ intervention = ("ask", which)
            $ response_key = pp_intervene(intervention[0], intervention[1])
            e "A part of you breathes differently after that."
            jump a2c2_mi_after_negotiate

        "leave it for today":
            e "You leave it for today. The next room will still be there."
            jump a2c2_mi_after_negotiate


label a2c2_mi_after_negotiate:
    $ gate = pp_exile_gate()
    if gate.approved:
        e "Something has shifted. The door is no longer held."
        menu:
            "go in, for a moment":
                jump a2c2_mi_approved
            "another day":
                jump a2c2_mi_close
    else:
        jump a2c2_mi_close


label a2c2_mi_approved:
    ## The MI-specific exile scene. Different memory; same discipline
    ## per PRD §7.1 (present tense, child-age vocab, short sentences,
    ## no monologue).
    scene black
    with slowdissolve

    e "You step through."

    pause 1.0

    exile_voice "The hallway has a telephone table in it."

    exile_voice "I am standing in front of the door."

    pause 1.5

    exile_voice "The door is closed."

    exile_voice "I am counting."

    pause 1.5

    exile_voice "I am at sixty-four."

    ## The adult protagonist does not interrupt the count. This is
    ## the MI-exile-approach signature: the adult lets the counting
    ## be the counting.
    e "You are thirty-four. You are watching a child count in the hallway outside a closed door."

    e "You do not reach for the child. You do not hurry the count."

    exile_voice "Seventy-one."

    pause 1.5

    exile_voice "Seventy-two."

    pause 1.5

    e "At ninety the child knocks, or does not knock. You have not known, all your adult life, whether the child knocked."

    ## Intentionally ambiguous — the scene refuses the redemption
    ## of "remembering what happened next."
    pause 2.0

    e "The child looks up. The child sees you."

    exile_voice "Are you grown?"

    e "You say yes."

    exile_voice "Did we knock?"

    e "You say: \"I don't remember. I'm sorry.\""

    exile_voice "Oh."

    pause 1.5

    e "The child goes back to the counting. The counting does not end. You stand in the hallway with the child, not pretending to know the answer."

    ## Recognition: MI-specific SAT_WITH_EXILE event so a replay
    ## from CEN accumulates both.
    $ reco_credit("sat_with_exile", "a2c2_mi_hallway_door_count")

    ## State deltas — close to the CEN variant but with a different
    ## flashback-pressure profile (no wallpaper imagery; the memory
    ## was always partial to begin with).
    $ rr_delta("presence", +6)
    $ rr_delta("permission", -4)
    $ rr_delta("self_trust", +5)
    $ rr_delta("critic_volume", -6)
    $ rr_delta("flashback_pressure", +6)

    flame "you did not remember whether the knock happened. you said so to the child. that was the specific thing being asked of you this morning."

    jump a2c2_mi_close


label a2c2_mi_close:
    scene black
    with fade
    flame "nothing was fixed. you stood in a hallway next to a child."

    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c2_mi_feeling")

    e "The next part of the week is small, on-the-page choices. Some land. Some do not. The endings come after."

    menu:
        "continue to Chapter Six (MI)":
            jump a2c3_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c2_mi_skipped:
    scene black
    centered "Chapter Five (MI variant) was skipped."
    pause 1.5
    e "There is a hallway, and a door, and you did not walk through today."

    menu:
        "continue to Chapter Six (MI)":
            jump a2c3_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
