"""Shoes — pure-Python logic layer. No Ren'Py imports. pytest-covered."""

__version__ = "0.1.0"
