## scenes/act2/chapter7.rpy — Quiz Night with Ben.
##
## Scene type: Social (PRD §4.8 + profile inventory "Quiz Night").
## First direct Ben scene; before this chapter he's only been
## *referenced* in the witnessed ending. Quiz Night establishes the
## specific kind of friendship that makes the 2am text (Act III
## mention_the_childhood_thing) and the Saturday kitchen (witnessed
## ending) land as earned rather than arbitrary.
##
## Craft discipline:
##   - Ben is specific. A twenty-year friend. Shorthand comes easy.
##   - Group setting (pub trivia with a team of regulars) — player
##     is in the cast but not the centre of attention. This matters
##     because the witnessed-ending confidant is exactly the kind of
##     friend who is around without requiring performance.
##   - No Critic activation in the foreground. Social battery drains
##     per the scene contract; no unsafe-scene penalties.
##   - One gentle meta-choice near the end that lets the player signal
##     to Ben that something is off. Refusing is valid.

label a2c7_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c7", False):
        centered "Chapter Ten — Act II (continued)\n\nA short social scene at a pub trivia night with long-term friend Ben. No sensitive content."
        $ chapter_notice_shown["a2c7"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c7_skipped

    scene black
    with dissolve

    e "Saturday night. The pub has the particular kind of noise a pub has on Saturday night with a quiz on. Ninety percent of the noise is strangers who think they know the answer to the decade a specific song came out."

    e "Ben is at your table. So is Ben's sister. So are two of Ben's coworkers whose names you have learned and re-learned a combined eight times."

    ben "You're late."

    e "You are not late. You are three minutes early. This is a thing he says. This is a thing you smile at the way you always smile at it."

    menu:
        "smile; say nothing":
            e "You smile. You say nothing. Ben grins, hands you a menu you don't need."
            $ rr_delta("social_battery", -2)
            jump a2c7_round_1
        "say: you're eight minutes early":
            e "You say: \"You're eight minutes early.\" You checked, on the way in, because you wanted the specific number."
            ben "Eight is the number at which I am early, yes."
            $ rr_npc_delta("ben", +2, safe=True)
            jump a2c7_round_1
        "say hi to the coworkers by name":
            e "You look at them. You say their names. You get one of them right. You apologise, quickly, in the way a twenty-year friend of Ben's can apologise."
            ben "Marina. Again."
            e "Marina laughs. Ben's sister. The laugh of a person who has been in eight variations of this moment, with Ben in seven of them."
            $ rr_npc_delta("ben", +3, safe=True)
            jump a2c7_round_1


label a2c7_round_1:
    scene black
    e "Round one is geography. Ben's sister is carrying this round. You contribute two answers, both correct, both about rivers."

    e "Marina orders a second round of drinks. You switch to soda water. You do not announce the switch. Nobody announces anything at this table; it is a feature."

    $ rr_delta("social_battery", -3)
    $ rr_delta("presence", +2)
    $ rr_delta("regulation", +3)

    jump a2c7_break


label a2c7_break:
    scene black
    with fade

    e "Between rounds two and three, Ben leans over."

    ben "You're half-here tonight."

    e "It is not a question. It is not unkind. It is a specific sentence he has said to you maybe forty times over twenty years, going back to a school hallway. You have said versions of it back to him, several of those times."

    pause 1.0

    menu:
        "say: yeah. sorry. long week.":
            e "You say it. He nods. He does not push. The next round starts."
            $ rr_delta("social_battery", -1)
            $ rr_delta("critic_volume", +2)
            jump a2c7_round_4

        "say: yeah. there's a thing.":
            ben "A thing you want to talk about tonight, a thing you want to talk about later, or a thing you want to leave as a thing?"
            menu:
                "say: leave as a thing tonight.":
                    e "You say it. He says: copy. He means it."
                    $ rr_npc_delta("ben", +3, safe=True)
                    $ rr_delta("self_trust", +4)
                    jump a2c7_round_4
                "say: later.":
                    ben "Okay. I'm around this week."
                    $ rr_npc_delta("ben", +5, safe=True)
                    $ rr_delta("permission", +3)
                    $ rr_delta("self_trust", +4)
                    ## This quietly primes the Act III
                    ## mention_the_childhood_thing scene — Ben
                    ## has given an opening.
                    $ reco_credit("part_register_identified", "a2c7_opening_accepted")
                    jump a2c7_round_4
                "say: tonight. now.":
                    ben "Okay. Let's step outside for a minute."
                    e "You go outside. Round three starts without you."
                    $ rr_delta("presence", +4)
                    $ rr_delta("permission", +4)
                    $ rr_npc_delta("ben", +7, safe=True)
                    $ rr_delta("self_trust", +6)
                    $ reco_credit("reflection_completed", "a2c7_stepped_outside")
                    jump a2c7_stepped_outside

        "say: I'm fine. what's round three?":
            e "You say it the way you say it. He lets it go the way he lets it go."
            $ rr_delta("critic_volume", +4)
            $ rr_delta("self_trust", -2)
            jump a2c7_round_4


label a2c7_stepped_outside:
    scene black
    with fade

    e "The street outside the pub is cool enough that you are glad for the jacket you almost didn't bring. Ben leans against the brick. Ben has been leaning against the brick outside of pubs with you for half your life."

    ben "No pressure. What's the shape?"

    menu:
        "say: my aunt sent me an email about my mother.":
            e "You say it. You tell him what the email said. You tell him you archived it."
            ben "Mm. Okay."
            e "He does not fix it. Neither of you goes inside for another ten minutes."
            $ rr_npc_delta("ben", +8, safe=True)
            $ rr_delta("self_trust", +6)
            $ rr_delta("flashback_pressure", +4)
        "say: I don't know the shape yet. just — friction.":
            ben "Friction is a shape."
            e "You laugh, a little. He laughs."
            $ rr_npc_delta("ben", +4, safe=True)
            $ rr_delta("regulation", +3)

    jump a2c7_round_4


label a2c7_round_4:
    scene black
    e "The quiz ends. Your team places fourth out of eleven, which is exactly where your team places every week. Ben's sister has been keeping track of the placings on her phone for three years."

    e "Marina hugs you goodbye. The hug is short; she is good at short hugs. You appreciate Marina."

    $ rr_delta("social_battery", -3)

    jump a2c7_close


label a2c7_close:
    scene black
    with fade

    e "You walk home alone. The walk home is twenty minutes. You do not put the phone on during the walk."

    $ rr_delta("presence", +4)
    $ rr_delta("regulation", +3)

    flame "saturday nights at the pub are one of the places you come back to. noticing the coming-back is something."

    ## Chapter-end reflection.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c7_feeling")

    menu:
        "continue to Chapter Eleven":
            jump a2c8_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c7_skipped:
    scene black
    centered "Chapter Ten was skipped."
    pause 1.5
    e "There was a quiz night. You went. You saw Ben. You saw the regulars. It was the thing it always is."
    $ rr_delta("social_battery", -2)
    $ rr_npc_delta("ben", +1, safe=True)

    menu:
        "continue to Chapter Eleven":
            jump a2c8_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
