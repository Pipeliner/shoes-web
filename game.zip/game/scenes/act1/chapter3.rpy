## scenes/act1/chapter3.rpy — the afternoon at work.
##
## Content notice: a dissociative sequence written per PRD §7.1.
##   No desaturation, no piano sting, no screen shake. The craft markers
##   are hyper-specific irrelevant detail, loss of pronoun ownership,
##   temporal smearing, observer position. The narrator does not name it
##   as dissociation. The computed state does.
##
## This chapter is the Act I exit. Ends with a stressor (an email) that
## Herman's framework names as the pivot from safety to remembrance.

label a1c3_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a1c3", False):
        centered "Chapter Three\n\nThis chapter contains a work-afternoon scene with dissociative prose (no visual effect — the dissociation is in the writing)."
        $ chapter_notice_shown["a1c3"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a1c3_skipped

    scene black
    with dissolve

    e "You have been at the screen for a long time. The screen is blue. The cursor is in a box that has a field called 'Task Description.'"

    e "The task description is: implement the thing. The thing has a name. The name has acronyms in it."

    e "Your mug of coffee is empty. It has been empty for a while. You did not notice emptying it."

    $ rr_delta("energy", -8)
    $ rr_delta("presence", -10)
    $ rr_delta("interoception", -6)
    $ rr_delta("flashback_pressure", +4)

    ## The standup button is coming. The player has three options, one
    ## visibly-unavailable, one refused, one available.
    menu:
        "go to the standup":
            jump a1c3_standup
        "keep working, miss the standup":
            jump a1c3_miss_standup
        "take a real break — go outside, no phone":
            # Gated by not_flooded AND energy. At this point in the day
            # energy is usually below REST_MIN and flashback_pressure is
            # climbing. We expose the choice so the player sees it.
            # In practice this falls through as available-or-not based
            # on the player's first-chapter choices.
            if rr_get("energy") < 35:
                caretaker_voice "You don't have the energy to actually do that. You would end up scrolling on a bench."
                jump a1c3_standup
            else:
                jump a1c3_break


label a1c3_standup:
    scene black
    with fade
    e "You click the meeting link. The face of the person who runs the standup is a face that has been in a meeting since seven."

    e "There is also the face of a person on the west coast. That face is at the hour of the morning where faces are not yet faces."

    e "You say the thing you did yesterday. You say the thing you will do today."

    ## Fawn-on-the-page: micro-compliance written, not labelled.
    e "You also say, without meaning to, that it is going well. You did not mean to say that. You said it at the point in a sentence where a 'going well' goes."

    $ rr_delta("self_trust", -5)
    $ rr_delta("critic_volume", +6)

    critic_voice "You always say that. You always say that. Every standup. Fifteen years."

    e "Someone asks a clarifying question. You do not catch it the first time."

    $ rr_delta("presence", -8)
    $ rr_delta("flashback_pressure", +6)

    ## Dissociation-on-the-page — this is the core craft demonstration.
    ## Hyper-specific irrelevant detail. Loss of pronoun ownership.
    ## Temporal smearing. Observer position. Flat affect on high-stakes
    ## content. See PRD §7.1.
    ## Flashback uses verb_tense_torque.standup_screen_fingerprint
    e "The screen has a fingerprint on the lower-left quadrant. It is an index-finger print. The ridges are thin because the finger is always dry in the afternoons."

    e "Her hand is on the mouse."

    e "Someone says her name."

    e "She says something. The face on the west coast nods."

    e "It is maybe a minute later. Maybe more. She does not know."

    e "The meeting is over. Was it over?"

    ## Check whether dissociative_spell is computed. This is a narrative
    ## validation of the state-calculation layer.
    if rr_state("dissociative_spell"):
        e "Something has been taking a step back. Without noticing it."

    jump a1c3_post_standup


label a1c3_miss_standup:
    scene black
    e "You stay at the task. The meeting happens without you. You hear the tone of the app saying so."

    $ rr_delta("critic_volume", +10)
    $ rr_delta("self_trust", -8)
    $ rr_delta("connection", -4)

    critic_voice "You did that on purpose. You do it every time. You think nobody notices."

    e "Something inside you that has kept a schedule together for years does not respond."

    caretaker_voice "…"

    e "Even the Caretaker is quiet. The Caretaker is supposed to speak now. It is not speaking."

    $ rr_delta("flashback_pressure", +10)

    jump a1c3_post_standup


label a1c3_break:
    scene black
    e "You close the laptop. You put on your shoes — the old ones, with the heel wearing down on the outside."

    e "You go outside without the phone."

    e "Your feet feel the pavement. The pavement is uneven where the tree root has come up under it."

    $ rr_delta("presence", +12)
    $ rr_delta("interoception", +10)
    $ rr_delta("energy", +4)
    $ rr_delta("regulation", +8)

    e "You walk to the corner. You walk back."

    e "Nothing is fixed. The task is still there. The screen is still blue."

    e "Something that has been leaning heavy against your sternum has stepped back, a half-step."

    ## Recognition for noticing interoception — small sensory detail in
    ## the present tense is a form of naming. This is a cautious credit
    ## to avoid gamifying presence.
    $ reco_credit("part_register_identified", "a1c3_small_one_noticed")

    jump a1c3_post_standup


## After the standup / miss / break, a post-standup stretch of work.
## Whichever path got here, the narration rejoins.
label a1c3_post_standup:
    scene black

    e "You are back at the task. The cursor is in the field. 'Task Description' is still the field."

    e "It is later than you thought. Or the thought about time was wrong."

    $ rr_delta("energy", -4)

    ## The email. This is the Act I exit stressor — Herman's pivot.
    e "An email arrives."

    e "The subject line contains your mother's name."

    e "Your mother does not send you email. The email is not from her."

    e "The email is from your mother's sister. You have not spoken to her in eleven years."

    $ rr_delta("flashback_pressure", +16)
    $ rr_delta("threat_scan", +14)
    $ rr_delta("regulation", -8)

    e "The subject line is 'Your mother.'"

    ## We do not yet open the email. The chapter ends here, with the
    ## pivot unspoken. Act II Ch 1 picks it up.
    e "You stare at the subject line for a time that is not the time you think it is."

    e "A part of you is already moving in the direction you have seen it move before."

    firefighter_voice "Not now. Later. You can look later. You can look tomorrow. You do not have to look today."

    e "A different part of you has not yet decided whether to listen to that one."

    ## Chapter-end reflection, Recognition source.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a1c3_feeling")
    e "Chapter four — Act II — begins with the email."

    menu:
        "continue to Chapter Four — Act II":
            jump a2c1_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a1c3_skipped:
    scene black
    centered "Chapter Three was skipped."
    pause 1.5
    e "The afternoon passed. An email from your aunt arrived in your inbox at some point."
    e "The subject line contained your mother's name."
    e "what follows picks it up there."
    # Apply a modest equivalent stressor — the email still arrived, even
    # if the Ch 3 afternoon of work was elided. Without this, a skipper
    # arrives at Act 2 Ch 1 without the flashback-pressure priming that
    # the scene depends on.
    $ rr_delta("flashback_pressure", +10)
    $ rr_delta("threat_scan", +8)

    menu:
        "continue to Chapter Four — Act II":
            jump a2c1_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
