## scenes/act2/chapter7_nim.rpy — Quiz Night with Ben (NIM variant).
##
## Mirrors CEN `chapter7.rpy` and MI `chapter7_mi.rpy`
## structurally but lands on an NIM-specific texture: the
## threat-scanner Caretaker reads the pub's people first.
## The pub on Saturday night is *populated*. The threat-
## scanner does not get the night off, but it has, over
## twenty years of Quiz Nights with Ben, calibrated to *this
## room specifically*. None of the regulars are people who
## know Mother. Marina has known the protagonist since school
## and is not, in the threat-scanner's working model, a
## channel back to Mother. Ben is the one person in the room
## who knows the shape of how Mother gets discussed
## elsewhere — and Ben's pub is the room where that
## discussion does not happen.
##
## Where MI's a2c7 is about the half-channel for Mother held
## open in the phone pocket, NIM's is about the threat-
## scanner having one room in the world where its inventory
## comes up empty and *stays* empty. The room itself is the
## permission.
##
## Branch differences vs. CEN/MI:
##   - The opening register surfaces the threat-scanner's
##     calibration to this specific room.
##   - Ben's "half-here" is decoded specifically: he knows
##     the threat-scanning pattern from twenty years of
##     watching the protagonist *not* scan in this pub
##     and scan harder elsewhere.
##   - The stepped-outside-with-Ben email beat names the
##     Tamara-witness fact (per docs/continuity.md:695-701).
##     Ben knows the specific names that show up in this
##     kind of email.
##   - The Marina hug close: Marina is the threat-scanner's
##     calibration anchor — the protagonist has known her
##     since they were both children, and the scan has been
##     coming up empty on Marina for that long.
##
## State effects mirror chapter7.rpy line-for-line.

label a2c7_nim_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c7_nim", False):
        centered "Chapter Ten — Act II (continued, NIM branch)\n\nA short social scene at a pub trivia night with long-term friend Ben. No sensitive content."
        $ chapter_notice_shown["a2c7_nim"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c7_nim_skipped

    scene black
    with dissolve

    e "Saturday night. The pub has the particular kind of noise a pub has on Saturday night with a quiz on. Ninety percent of the noise is strangers who think they know the answer to the decade a specific song came out."

    e "Ben is at your table. So is Ben's sister. So are two of Ben's coworkers whose names you have learned and re-learned a combined eight times."

    ## NIM-specific opening: the threat-scanner's calibration
    ## to this specific room.
    e "Twenty-two people in the visible room. None of them is a person who knows your mother. The threat-scanner has been confirming this for the duration of every Quiz Night since you were twenty-two; it confirms again, fast, because it knows the answer."

    e "It is the room the scanner has, over years, designated as low-yield. The yield it is looking for is *people who could quote you to people who know your mother*. The yield is, here, reliably zero."

    ben "You're late."

    e "You are not late. You are three minutes early. This is a thing he says. This is a thing you smile at the way you always smile at it."

    menu:
        "smile; say nothing":
            e "You smile. You say nothing. Ben grins, hands you a menu you don't need."
            $ rr_delta("social_battery", -2)
            jump a2c7_nim_round_1
        "say: you're eight minutes early":
            e "You say: \"You're eight minutes early.\" You checked, on the way in, because you wanted the specific number."
            ben "Eight is the number at which I am early, yes."
            $ rr_npc_delta("ben", +2, safe=True)
            jump a2c7_nim_round_1
        "say hi to the coworkers by name":
            e "You look at them. You say their names. You get one of them right. You apologise, quickly, in the way a twenty-year friend of Ben's can apologise."
            ben "Marina. Again."
            ## NIM-specific: Marina is the threat-scanner
            ## calibration anchor. The scanner's working
            ## model has a Marina-shaped exception slot.
            e "Marina laughs. Ben's sister. The laugh of a person who has been in eight variations of this moment, with Ben in seven of them. The threat-scanner has, over two decades, declined to flag her in any room you have ever been in together. The slot is settled."
            $ rr_npc_delta("ben", +3, safe=True)
            jump a2c7_nim_round_1


label a2c7_nim_round_1:
    scene black
    e "Round one is geography. Ben's sister is carrying this round. You contribute two answers, both correct, both about rivers."

    e "Marina orders a second round of drinks. You switch to soda water. You do not announce the switch. Nobody announces anything at this table; it is a feature."

    ## NIM-specific: the scanner counts a couple at the bar
    ## who are unfamiliar — checks them, releases.
    e "There is a couple at the bar you do not recognise. The scanner takes a moment, checks them — neither of them looks at you, neither of them looks like a person who would later be at one of Mother's dinners — releases them. The release is what makes the round actually work."

    $ rr_delta("social_battery", -3)
    $ rr_delta("presence", +2)
    $ rr_delta("regulation", +3)

    jump a2c7_nim_break


label a2c7_nim_break:
    scene black
    with fade

    e "Between rounds two and three, Ben leans over."

    ben "You're half-here tonight."

    ## NIM-specific decode: Ben knows the scanning pattern.
    e "It is not a question. It is not unkind. It is a specific sentence he has said to you maybe forty times over twenty years, going back to a school hallway. Ben has watched the threat-scanner do its thing in every other room you've been in together — the school, the office building lobbies, the rare time you went to a wedding she was at — and he has watched it NOT do it here, in this pub, on Saturday nights. Half-here in the pub means something is up."

    pause 1.0

    menu:
        "say: yeah. sorry. long week.":
            e "You say it. He nods. He does not push. The next round starts."
            $ rr_delta("social_battery", -1)
            $ rr_delta("critic_volume", +2)
            jump a2c7_nim_round_4

        "say: yeah. there's a thing.":
            ben "A thing you want to talk about tonight, a thing you want to talk about later, or a thing you want to leave as a thing?"
            menu:
                "say: leave as a thing tonight.":
                    e "You say it. He says: copy. He means it. Ben has, over twenty years, learned the difference between a *leave-as-a-thing* and a *can't-say-yet*."
                    $ rr_npc_delta("ben", +3, safe=True)
                    $ rr_delta("self_trust", +4)
                    jump a2c7_nim_round_4
                "say: later.":
                    ben "Okay. I'm around this week."
                    $ rr_npc_delta("ben", +5, safe=True)
                    $ rr_delta("permission", +3)
                    $ rr_delta("self_trust", +4)
                    $ reco_credit("part_register_identified", "a2c7_nim_opening_accepted")
                    jump a2c7_nim_round_4
                "say: tonight. now.":
                    ben "Okay. Let's step outside for a minute."
                    e "You go outside. Round three starts without you. The threat-scanner is on the street with you, but the street is also low-yield — Ben is the only person on it who can quote you to anyone."
                    $ rr_delta("presence", +4)
                    $ rr_delta("permission", +4)
                    $ rr_npc_delta("ben", +7, safe=True)
                    $ rr_delta("self_trust", +6)
                    $ reco_credit("reflection_completed", "a2c7_nim_stepped_outside")
                    jump a2c7_nim_stepped_outside

        "say: I'm fine. what's round three?":
            e "You say it the way you say it. He lets it go the way he lets it go."
            $ rr_delta("critic_volume", +4)
            $ rr_delta("self_trust", -2)
            jump a2c7_nim_round_4


label a2c7_nim_stepped_outside:
    scene black
    with fade

    e "The street outside the pub is cool enough that you are glad for the jacket you almost didn't bring. Ben leans against the brick. Ben has been leaning against the brick outside of pubs with you for half your life."

    ben "No pressure. What's the shape?"

    menu:
        "say: my aunt sent me an email. my mother said something at a dinner.":
            ## NIM-specific: the Tamara-witness email + Ben's
            ## I-know-the-names response.
            e "You say it. The dinner, the saying-something. Tamara was there."
            ben "Tamara, again."
            e "He says her name flat, the way he says the names of people who have been on the wrong side of this kind of email more than once. Ben knows, from twenty years, which names show up in the aunt's emails. He does not, in the way other people might, ask what was said. He knows what *Tamara was there* means: it means it isn't private."
            ben "Has anyone else called you about it?"
            e "You say: no, not yet. He says: tell me when. Neither of you goes inside for another ten minutes."
            $ rr_npc_delta("ben", +8, safe=True)
            $ rr_delta("self_trust", +6)
            $ rr_delta("flashback_pressure", +4)
        "say: I don't know the shape yet. just — friction.":
            ben "Friction is a shape."
            e "You laugh, a little. He laughs. The threat-scanner is, in this thirty-second exchange on the street, not running. Ben is not a yield-point. The pub is not a yield-point. The friction is a friction."
            $ rr_npc_delta("ben", +4, safe=True)
            $ rr_delta("regulation", +3)

    jump a2c7_nim_round_4


label a2c7_nim_round_4:
    scene black
    e "The quiz ends. Your team places fourth out of eleven, which is exactly where your team places every week. Ben's sister has been keeping track of the placings on her phone for three years."

    ## NIM-specific: Marina's hug.
    e "Marina hugs you goodbye. The hug is short; she is good at short hugs. The threat-scanner has been confirming-Marina-is-Marina since you were both seven; the eight-second hug is one of the few touches the scanner does not put through any inventory at all. You appreciate Marina."

    $ rr_delta("social_battery", -3)

    jump a2c7_nim_close


label a2c7_nim_close:
    scene black
    with fade

    $ chapter_completed["a2c7_nim"] = True

    e "You walk home alone. The walk home is twenty minutes. You do not put the phone on during the walk."

    ## NIM-specific close: the scanner stays gentle for the
    ## walk; the apartment is a different yield-context.
    e "The street is low-yield. The block is low-yield. The block your apartment is on is medium-yield, because there is a cafe on the corner where someone Mother knows once happened to be. The walk has not yet reached that block. For the next twenty minutes the scanner is on its lowest setting."

    $ rr_delta("presence", +4)
    $ rr_delta("regulation", +3)

    flame "saturday nights at the pub are one of the places you come back to. noticing the coming-back is something."

    ## Chapter-end reflection.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c7_nim_feeling")

    menu:
        "continue to Chapter Eleven (NIM)":
            jump a2c8_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c7_nim_skipped:
    scene black
    centered "Chapter Ten (NIM variant) was skipped."
    pause 1.5
    e "There was a quiz night. You went. You saw Ben. You saw the regulars. The threat-scanner ran its inventory on the room and came up empty, the way it always does in this room. It was the thing it always is."
    $ rr_delta("social_battery", -2)
    $ rr_npc_delta("ben", +1, safe=True)

    menu:
        "continue to Chapter Eleven (NIM)":
            jump a2c8_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
