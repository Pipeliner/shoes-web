## scenes/act3/tell_r_no_mi.rpy — Act III structural-change scene
## (MI variant).
##
## Per S1+S2 (0.1.18-46): Act III per-branch variants. CEN
## equivalent: scenes/act3/tell_r_no.rpy. Same gated-menu shape
## (say_it / wait / nothing) and Recognition gate threshold (14
## in ACT_III_STRUCTURAL_GATES) — but the prose lands on
## MI-specific texture.
##
## Branch differences vs. CEN:
##   - The kettle-flashback opens onto a *stretch-kitchen* —
##     Mother is not at the counter because Mother is in bed.
##     The kettle clicks off in an empty kitchen. The
##     protagonist at eight, alone, listening. The MI-specific
##     trauma-writing register per PRD §7.1 (verb-tense torque,
##     the absence of Mother as the noticing) is what the scene
##     pivots on.
##   - The fawn-yes pattern's MI-shape: said yes on Tuesday
##     because the stretch-watcher needed Sunday-as-a-known-
##     quantity. Sundays in stretches were the worst.
##   - Sam's tactful response: Sam knows the stretch-watcher
##     has been loud this week (per Sam-knows-the-branch-
##     register, R2 a2c5).
##   - Critic on landed-success: stretch-rationalising the
##     original yes — "you always do this. you said yes
##     because you needed her not to be in a stretch about
##     Sunday."
##
## Reuses the gated-choice screen `a3_tell_r_no_menu` from
## tell_r_no.rpy (branch-agnostic UI).

label a3_tell_r_no_mi:
    scene black
    show screen tooltip_overlay

    e "It is Thursday evening. You are at Sam's. Sam is on the couch with the book that has been on the couch for a week."

    e "Sunday brunch was your yes. You said it on Tuesday, without thinking. Sam's friends are Sam's friends; they are fine. You do not know them."

    e "You do not want to go."

    ## MI-specific: the fawn-yes traces to the stretch-watcher.
    e "A part of you knew on Tuesday that you did not want to go. You said yes anyway. The stretch-watcher needed Sunday to be a known quantity. Sundays in stretches were the worst, and the stretch-watcher could not, on Tuesday, rule out Sunday being a stretch-Sunday for her."

    e "That is the whole shape of this for you. The yes was for the stretch-watcher. The Sunday is for you."

    pause 1.0

    e "Sam has not looked up from the book. The kettle in Sam's kitchen is cooling on the counter."

    ## MI-specific kettle-flashback: the stretch-kitchen.
    ## Mother in bed. Empty kitchen. Eight years old. Per PRD
    ## §7.1: verb-tense torque, intrusive partial. No clinical
    ## framing.
    e "The kettle clicks off."

    e "The kettle in your mother's kitchen clicked off the same way. Nobody was at the counter. She was in the bedroom with the door closed; she had been there all afternoon."

    e "You are eight. You are standing in the kitchen because you came in to ask if she wanted tea, and she did not, but you stayed for the kettle anyway."

    e "The kettle is louder than it should be in an empty kitchen. The empty kitchen is louder than the kettle."

    e "You are in Sam's kitchen. The book is the book. The kettle is cooling. Sam is right there."

    call screen a3_tell_r_no_menu

    if _return == "say_it":
        jump a3_tell_r_no_mi_said
    elif _return == "say_it_refused":
        ## Flashback uses non_flashback.the_sentence_you_almost_said
        e "There is a sentence you almost say."
        e "You can feel the shape of it in the lower part of your throat. You know its first word and its last word."
        e "You do not say it."
        ## MI-specific firefighter line: the dissociative one.
        firefighter_voice "No. Not now. We can take Sunday. We have always taken Sunday."
        e "You stay on the chair. The kettle is the kettle. The book is the book."
        jump a3_tell_r_no_mi_not_said
    elif _return == "wait":
        jump a3_tell_r_no_mi_waited
    else:
        jump a3_tell_r_no_mi_not_said


label a3_tell_r_no_mi_said:
    scene black
    with fade
    e "You say it. The sentence comes out shorter than you planned."

    e "\"I was thinking about Sunday. Can I take back the yes?\""

    pause 1.0

    e "Sam looks up. Sam's thumb stays on the page. This is not hostile. This is Sam finishing the sentence Sam was reading."

    ## MI-specific Sam: knows the stretch-watcher's been loud.
    sam "Yeah. Want me to still go? Or — has it been a week?"

    e "Sam has not asked the second question outright. The *or* is what Sam has, over years, learned to put after a question like this. Sam knows what *a week* means in this apartment. Sam is not going to make you say it."

    menu:
        "say: yes, go":
            e "You say: yes. Go."
            $ rr_npc_delta("sam", +4, safe=True)
        "say: i'd rather we stayed in":
            e "You say: i'd rather we stayed in."
            $ rr_npc_delta("sam", +6, safe=True)
            sam "Okay. We can do soup. We can do nothing."
        "say: i don't know yet":
            e "You say: i don't know yet."
            sam "Okay. Let me know."
            $ rr_npc_delta("sam", +3, safe=True)

    ## Base effects of the successful boundary.
    $ rr_delta("self_trust", +8)
    $ rr_delta("permission", +4)

    ## MI-specific Critic: stretch-rationalising the Tuesday yes.
    critic_voice "You always do this. You said yes because you needed her not to be in a stretch about Sunday. The yes was for her. You always make the yes for her."

    $ rr_delta("critic_volume", +7)

    e "The Critic's line is about Tuesday, not about now. You notice the distinction. You notice, also, that the Critic has the Caretaker's diagnosis."

    $ reco_credit("reflection_completed", "a3_tell_r_no_mi_succeeded")
    $ reco_credit("part_register_identified", "a3_tell_r_no_mi_critic_timing")

    flame "you took back a yes. that is a specific thing. the critic's timing on it was information about where you have lived for a long time."

    $ act3_outcomes["tell_r_no"] = "said"
    $ renpy.fix_rollback()
    jump a3_tell_r_no_mi_close


label a3_tell_r_no_mi_waited:
    scene black
    e "You wait for the right moment. The right moment does not come."

    e "Sam closes the book at ten, makes tea, goes to bed."

    e "You stay on the chair. Sunday is still happening. The stretch-watcher has, by ten-twenty, started running its forecast for Sunday — what cadence Mother might be in by then, whether you should call her on Saturday to check, whether Sunday-in-a-known-stretch is better or worse than Sunday-with-Sam's-friends."

    $ rr_delta("self_trust", -3)
    $ rr_delta("critic_volume", +5)
    $ rr_delta("presence", +3)

    critic_voice "The right moment was always right now. You know that."

    $ reco_credit("part_register_identified", "a3_tell_r_no_mi_waited_pattern")

    $ act3_outcomes["tell_r_no"] = "waited"
    $ renpy.fix_rollback()
    jump a3_tell_r_no_mi_not_said


label a3_tell_r_no_mi_not_said:
    scene black
    with fade
    e "Sunday happens. The brunch is fine. The brunch is an hour and forty minutes."

    e "You say the things people say at brunch. You laugh at the things people laugh at. The stretch-watcher is at brunch with you, scanning the table for tones-that-are-like-Mother's, finding none, scanning anyway."

    $ rr_delta("social_battery", -12)
    $ rr_delta("presence", -6)

    e "Monday you are tired in the way that means a specific tired."

    flame "you did not take back the yes this time. that is also information. the stretch-watcher is allowed to want a known sunday. you are also allowed to stay home."

    if act3_outcomes.get("tell_r_no") != "waited":
        $ act3_outcomes["tell_r_no"] = "not_said"
        $ renpy.fix_rollback()
    jump a3_tell_r_no_mi_close


label a3_tell_r_no_mi_close:
    scene black
    with fade
    e "The Thursday closes. The week continues."
    return
