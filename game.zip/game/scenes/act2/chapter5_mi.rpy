## scenes/act2/chapter5_mi.rpy — the dinner with Sam (MI variant).
##
## Mirrors the structural arc of `game/scenes/act2/chapter5.rpy`
## (CEN dinner scene with Sam — the named partner, see
## characters.rpy). This is Sam's first direct scene on the MI
## branch; Act III's `tell_r_no` is a second Sam scene that
## references the history this one establishes. Per audit
## parity-and-onboarding-audit-0.1.18-15: a first-time MI player
## meeting Sam for the first time at Act III is a thinner
## experience than CEN; this scene gives MI players a Sam
## relationship to draw on at tell_r_no.
##
## Reuses the gated-choice screen `a2c5_dinner_menu` (branch-
## agnostic — same five choice labels) authored at
## game/scenes/act2/sam_dinner_choices.yaml. The five outcome
## labels (a2c5_mi_*) carry MI register: the aunt-email content,
## the firefighter / critic / caretaker voice lines, and the
## "ache" gloss are MI-flavoured.
##
## MI-specific differences vs. CEN:
##   - Aunt-email content: per docs/continuity.md:688-694,
##     MI-aunt-email is *"your mother had a fall. … is in the
##     hospital. … is stable. … she thought you should know"*
##     (factual, medical, no commentary). The CEN version was
##     about "calling everyone except you." MI's confront-path
##     references the hospital fact.
##   - Firefighter on fight_the_ache: MI dissociative
##     firefighter (a2c1_mi:96-103 "you are somewhere
##     mostly-not-here") rather than CEN's numb-out
##     firefighter. The "Nothing here" line stays — both
##     firefighters use that move — but the after-prose names
##     the MI dissociative texture rather than the CEN body-
##     stop.
##   - Caretaker on confront_refused: MI Caretaker register
##     (house-listener / stretch-watcher) reads the restaurant
##     as a no-go context for the same reason it reads
##     phone-call timing — too many variables, the audience is
##     wrong, the cadence is wrong. Same shape as CEN ("Not
##     over dinner") with MI flavour.
##
## Writing discipline (per chapter5.rpy header):
##   - Sam is a person the protagonist has been with long
##     enough that small talk has specific shapes. Write the
##     familiar tempo. Sam is constant across branches per
##     docs/continuity.md (Sam is branch-parity-clean).
##   - The "ache" fight_the_ache references is low-grade
##     dissociation, not a flashback. Don't stage-manage it.
##     Per A7: successful confront still ends with a critic
##     spike. Don't soften.
##   - State effects mirror chapter5.rpy line-for-line; the
##     simulator applies BRANCH_BIAS[MI] (FLASHBACK_PRESSURE
##     ×1.2 worse, INTEROCEPTION ×1.2 worse, PRESENCE ×1.3
##     worse). Do not pre-bias here.

label a2c5_mi_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c5_mi", False):
        centered "Chapter Eight — Act II (continued, MI branch)\n\nA quiet dinner scene with Sam, the partner. No sensitive content beyond adult dialogue about intimacy, routine, and one archived email about Mother's hospitalisation."
        $ chapter_notice_shown["a2c5_mi"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c5_mi_skipped

    scene black
    with dissolve

    e "It is Thursday. Sam is the person you have been with for years and have not lived with for any of them — that arrangement is one of the deliberate things between you, and you are not, mostly, planning to talk about it tonight."

    e "The arrangement is the one you both call {i}how we do this{/i}. Not a stage. Sam likes their own apartment; you like the one space in your life that is not asking anything of you. The other thing the arrangement gives you that you have never named to Sam: the apartment Mother could phone is not the apartment Sam is sitting in."

    e "Sam picked the restaurant. Sam always picks the restaurant, a fact you both find mildly amusing and mildly revealing."

    e "The restaurant is small. The table is small. The menu is on a clipboard. You have ordered the thing you always order here; so has Sam."

    sam "You look a little far away tonight."

    e "Sam is not wrong. Sam is rarely wrong about this. Sam has, over years, learned to tell the difference between *far away because today was a long day* and *far away because the half-channel for Mother is open under the conversation*. Sam does not, mostly, ask which it is. Sam has, however, learned to notice the half-second pause when your phone buzzes."

    ## MI-flavoured aunt-email frame: per docs/continuity.md
    ## :688-694, the MI aunt-email is the hospital one — factual,
    ## medical, no commentary, the kind the protagonist has been
    ## receiving variants of since she was eight (Mother MI
    ## subtype: hospitalised periodically since age 8).
    e "The archived email from your aunt is still archived. The hospital one. You have not mentioned it. You are not sure whether Sam knows and is waiting, or does not know and should."

    call screen a2c5_dinner_menu

    if _return == "i_missed_you":
        jump a2c5_mi_i_missed_you
    elif _return == "stay_quiet":
        jump a2c5_mi_stay_quiet
    elif _return == "ask_about_day":
        jump a2c5_mi_ask_about_day
    elif _return == "confront":
        jump a2c5_mi_confront
    elif _return == "confront_refused":
        ## MI Caretaker register: house-listener / stretch-watcher.
        ## The stretch-watcher reads the restaurant as a wrong-
        ## cadence context for hospital news, the same way it
        ## reads ring-counts on phone calls. Same beat-shape as
        ## CEN ("Not over dinner") with MI flavour.
        caretaker_voice "Not in the restaurant. Not over a clipboard menu. Not while there is a table next to us where a couple is laughing."
        e "You do not confront. You reach for the bread basket, which does not need reaching for."
        jump a2c5_mi_stay_quiet
    elif _return == "fight_the_ache":
        jump a2c5_mi_fight_the_ache
    elif _return == "fight_the_ache_refused":
        ## MI dissociative firefighter (per a2c1_mi:96-103).
        ## "Nothing here" is the same move both firefighters
        ## make; the after-prose names the MI dissociative
        ## texture (the somewhere-mostly-not-here register)
        ## rather than the CEN numb-out body-stop.
        firefighter_voice "Don't. There is nothing there. You know what happens when there is nothing there and you push. We end up not-here for a while."
        e "You look. You agree with the part of you that keeps agreeing. There is nothing there."
        jump a2c5_mi_stay_quiet
    else:
        jump a2c5_mi_stay_quiet


label a2c5_mi_i_missed_you:
    scene black
    with fade
    e "You say it without preface. \"I missed you.\""

    sam "I'm here."

    e "Sam is here. The sentence does not fix what you were missing — the thing you were missing is not Sam, exactly, it is the version of yourself without the stretch-watcher always running. The stretch-watcher is the part of you that has been listening, since you were eight, for which kind of stretch Mother is in this week — the third step on the stairs, the ring-count before she picks up, the way she does or does not say *anyway* between sentences. The version of yourself without it always-on is a version that exists for, occasionally, an hour at a time. Sam's sentence does not give the stretch-watcher an hour off, but it lands."

    $ rr_npc_delta("sam", +7, safe=True)
    $ rr_delta("self_trust", +3)
    $ rr_delta("presence", +3)

    sam "You want to tell me what's been off?"

    menu:
        "say: not tonight. thank you for asking.":
            e "You say what you said."
            $ rr_delta("self_trust", +4)
            $ rr_npc_delta("sam", +3, safe=True)
            sam "Okay. I'm around."

        "say: I don't know what's been off.":
            e "You say it and you notice, as you say it, that you do know. You say it anyway."
            $ rr_delta("critic_volume", +3)
            $ rr_delta("presence", +2)

        "say: there is a thing. I'm not ready.":
            e "You say it. It is a specific sentence. It is the first time you have been ahead of the sentence on a Thursday at this restaurant."
            $ rr_delta("self_trust", +6)
            $ rr_delta("permission", +3)
            $ reco_credit("part_register_identified", "a2c5_mi_naming_the_thing_before_telling_it")
            sam "Okay."

    $ act2c5_outcome = "i_missed_you"
    jump a2c5_mi_close


label a2c5_mi_stay_quiet:
    scene black
    with fade
    e "You stay quiet. You finish the plate. The plate is fine."

    e "Sam lets the quiet hold. Sam is good at this, has been for years, a specific kind of good-at-this that means Sam will not press. Sam learned the no-press version after one early-relationship dinner where you went very quiet about Mother and Sam tried to ask. Sam has not, since, asked at a restaurant."

    $ rr_npc_delta("sam", +1, safe=True)
    $ rr_delta("social_battery", -4)
    $ rr_delta("critic_volume", +3)

    critic_voice "You should have said something. The space is right there."

    e "The Critic is saying something that is half-right. The space is right there. You have not used it."

    $ act2c5_outcome = "stay_quiet"
    jump a2c5_mi_close


label a2c5_mi_ask_about_day:
    scene black
    e "\"How was the meeting this morning?\""

    sam "Fine. The new PM is still mostly nodding. Wait til week three."

    e "Sam tells you about the week. You follow most of it. You miss a beat halfway through and Sam notices and goes back."

    $ rr_npc_delta("sam", +3, safe=True)
    $ rr_delta("social_battery", -2)
    $ rr_delta("presence", -2)

    sam "Where did you go just then?"

    menu:
        "say: sorry — here now":
            e "You say sorry. You say here now. Sam does not push."
            $ rr_delta("self_trust", -2)
            $ rr_delta("critic_volume", +4)
        "say: I was thinking about the email from my aunt":
            ## MI flavour: the email is "the hospital one"
            ## (per docs/continuity.md:688-694).
            e "Sam puts the fork down. The restaurant gets slightly louder around the specific quiet at your table."
            $ rr_delta("self_trust", +6)
            $ rr_delta("permission", +3)
            $ rr_npc_delta("sam", +5, safe=True)
            $ reco_credit("reflection_completed", "a2c5_mi_mentioned_the_email")

    $ act2c5_outcome = "ask_about_day"
    jump a2c5_mi_close


label a2c5_mi_confront:
    scene black
    with fade
    e "You push the plate an inch forward. You do not look up from the plate."

    ## MI confront line: the hospital fact is the email's
    ## content. Same one-sentence shape as CEN; the noun is
    ## different.
    e "\"There was an email from my aunt. About my mother. She had a fall. She is in the hospital. She is stable. I archived it on Tuesday.\""

    e "Your aunt knew Mother as a younger woman than you have ever known her. The aunt's emails come from someone who has been watching the same person for longer than you have been alive. The aunt has sent variants of this email periodically since you were eight. You knew the format on sight."

    pause 1.0

    sam "Oh."

    pause 1.0

    e "Sam is not a person who reflexively says the right thing in restaurants. Sam is, however, a person who waits for the second sentence. Sam has, over years, watched you receive the kind of news that comes via your aunt; this is not the first such email Sam has been near. Sam knows the email's category."

    menu:
        "say: I don't know what to do with it.":
            e "You say it. It is the truest sentence you have said out loud this week."
            sam "We can look at it at home, if you want. Or not. Whatever you need."
            $ rr_delta("self_trust", +8)
            $ rr_delta("permission", +4)
            $ rr_npc_delta("sam", +8, safe=True)

        "say: I don't know if I want to do anything with it.":
            sam "Okay."
            $ rr_delta("self_trust", +5)
            $ rr_npc_delta("sam", +5, safe=True)

    ## ACoA per A7: the critic arrives even when the confront
    ## lands. MI Critic register: flat-tense absolutism (cf.
    ## a2c1_mi:157 "you always archive"). Same critic-on-
    ## schedule arrival as CEN.
    critic_voice "You shouldn't have made this Sam's problem. Not the hospital one. Not over a clipboard."

    $ rr_delta("critic_volume", +6)

    e "The Critic is saying a thing that is not wholly true and not wholly false. You notice it arriving on schedule."

    $ reco_credit("part_register_identified", "a2c5_mi_confront_critic_timing")
    $ reco_credit("reflection_completed", "a2c5_mi_named_email_to_r")

    $ act2c5_outcome = "confronted"
    jump a2c5_mi_close


label a2c5_mi_fight_the_ache:
    scene black

    ## "The ache" — first MI-branch use of the family idiom. CEN
    ## glossed it at chapter5.rpy:272; MI mirrors the gloss
    ## here so an MI-only player gets the in-character anchor
    ## per .claude/rules/clarity.md rule 1.
    e "There is an ache in the centre of you. Not pain, exactly. More like a missing — the kind that has been there long enough you stopped naming it."

    e "You push through. \"No, I'm fine. Tell me about the thing with the PM.\""

    e "Sam picks it up. You listen. You keep listening. You keep hearing words, but somewhere after the second sentence you are not really in the restaurant anymore."

    ## MI-coded dissociative texture rather than CEN's body-
    ## stop. The hand still cuts the food (carry-through from
    ## CEN), but the *register* is "somewhere mostly-not-here"
    ## (per a2c1_mi:96-103) rather than "close the laptop".
    e "Your hand is cutting into the food on the plate. The cutting is a thing your hand is doing. You are somewhere mostly-not-here for a minute, or maybe several. The clipboard menu is far away."

    $ rr_delta("presence", -6)
    $ rr_delta("flashback_pressure", +8)
    $ rr_delta("interoception", -5)
    $ rr_delta("social_battery", -6)

    firefighter_voice "Nothing here. Nothing here. Stay with the words. Stay with Sam's words."

    e "You keep going. The dissociative part keeps the script running. Sam finishes the PM story. Sam eats. You nod at the right places."

    $ act2c5_outcome = "fought_the_ache"
    jump a2c5_mi_close


label a2c5_mi_close:
    scene black
    with fade

    $ chapter_completed["a2c5_mi"] = True

    e "After the restaurant, there is the walk home. Sam does not say much. You do not either. Sam has, on past hospital-email Thursdays, walked the silent-walk version of this with you; Sam is doing it again."

    e "Sam reaches for your hand on the corner where you always cross. You take it."

    $ rr_npc_delta("sam", +2, safe=True)

    ## Chapter-end reflection.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c5_mi_feeling")

    menu:
        "continue to Chapter Nine (MI)":
            jump a2c6_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c5_mi_skipped:
    scene black
    centered "Chapter Eight (MI variant) was skipped."
    pause 1.5
    e "A Thursday passed. There was a restaurant. There was a walk home. Sam held your hand."
    $ rr_npc_delta("sam", +1, safe=True)

    menu:
        "continue to Chapter Nine (MI)":
            jump a2c6_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
