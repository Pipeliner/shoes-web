## options.rpy — build classifications and project metadata.
##
## Authored 0.1.16 in service of the web-build pipeline. Without
## this file Ren'Py's `distribute` packs the entire project directory
## (renpy-sdk/, tests/, docs/, the .md files, etc.) into the bundle,
## which is wrong for a runtime distribution. Classifying explicitly.
##
## Per Ren'Py docs: every file under the project root is classified
## into one or more "tags" (e.g. "all", "linux", "windows", "web").
## A tag of None excludes the file from every package.

define config.name = _("Shoes")
define config.version = "0.1.18-46"

## Window title (desktop window chrome and browser tab). Defaults to
## config.name; setting explicitly is the convention.
define config.window_title = "Shoes"

## Save-directory name. Without this, Ren'Py uses a hash of the project
## path under `~/.renpy/`, so saves break if the project moves machines
## or paths. The "Shoes-0.1.18" base is stable across point releases —
## bump only when introducing save-format-incompatible changes.
define config.save_directory = "Shoes-0.1.18"

init python:
    ## Project metadata that drives the output filename
    ## (`<build.name>-<config.version>-<package>.zip`).
    build.name = "shoes"

    ## Default-include the runtime under game/. The base Ren'Py
    ## default already does this, but stating it explicitly for clarity.
    build.classify("game/**", "all")

    ## Runtime caches and player saves never ship.
    build.classify("game/cache/**", None)
    build.classify("game/saves/**", None)
    build.classify("game/**/__pycache__/**", None)
    build.classify("**.pyc", None)

    ## Source / dev / scaffolding artefacts that live alongside the
    ## game in this repository but are NOT part of a player-facing
    ## distribution.
    build.classify("README.md", None)
    build.classify("CHANGELOG.md", None)
    build.classify("CLAUDE.md", None)
    build.classify("AGENTS.md", None)
    build.classify("docs/**", None)
    build.classify("tests/**", None)
    build.classify("tools/**", None)
    build.classify("renpy_tests/**", None)
    build.classify("pyproject.toml", None)
    build.classify("play.sh", None)
    build.classify("web-build/**", None)
    ## Build artifacts that live at project root: each `play.sh web`
    ## drops `web-build.zip` next to web-build/, and Ren'Py's
    ## classify-by-glob did not catch the file (only the directory).
    ## The 0.1.18-32 build-bloat audit found 787MB of recursive
    ## self-inclusion bundled into game.zip. Belt-and-braces: catch
    ## the .zip explicitly + any other top-level zip artifacts.
    build.classify("web-build.zip", None)
    build.classify("*.zip", None)
    ## Reddit-corpus research data — gitignored but Ren'Py classify
    ## treats research/ as a candidate "all" directory unless told
    ## otherwise. Same for screenshots/ (playtest-agent captures)
    ## and exports/ (any future export staging area).
    build.classify("research/**", None)
    build.classify("screenshots/**", None)
    build.classify("exports/**", None)
    ## Build / runtime log artifacts.
    build.classify("log.txt", None)
    build.classify("traceback.txt", None)

    ## Test scripts: ship Ren'Py source for testcases is a bad
    ## practice (per docs/renpy-flow-best-practices.md item 5).
    ## game/testcases.rpy is dev-only — run via `./play.sh test`,
    ## never bundled in web/desktop distributions.
    build.classify("game/testcases.rpy", None)
    build.classify("game/testcases.rpyc", None)
    build.classify("game/test_screen_renders.rpy", None)
    build.classify("game/test_screen_renders.rpyc", None)

    ## Local-only developer state (Loki, IDE configs, git metadata,
    ## the bundled SDK itself).
    build.classify(".loki/**", None)
    build.classify(".claude/**", None)
    build.classify(".cursor/**", None)
    build.classify(".github/**", None)
    build.classify(".venv/**", None)
    build.classify(".pytest_cache/**", None)
    build.classify(".hypothesis/**", None)
    build.classify(".gitignore", None)
    build.classify(".gitattributes", None)
    build.classify(".pre-commit-config.yaml", None)
    build.classify(".coverage", None)
    build.classify("renpy-sdk/**", None)

    ## Editor / OS detritus.
    build.classify("**~", None)
    build.classify("**.swp", None)
    build.classify(".DS_Store", None)

    ## Web build is a separate package class; the launcher's
    ## `--package web` flow builds it from the same `all` set.
