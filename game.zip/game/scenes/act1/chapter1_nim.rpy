## scenes/act1/chapter1_nim.rpy — Act I Ch 1 NIM-branch seed.
##
## Per PRD §4.3 NIM branch:
##   - Overt invalidation, contempt, or grandiosity.
##   - Dominant 4F pull: fight/flight.
##   - Parts skew toward a harsh inner critic (identified-with-
##     aggressor) and angry-protector firefighters.
##   - BRANCH_BIAS[NIM]: THREAT_SCAN ×1.3 worse/0.85 better,
##     CRITIC_VOLUME ×1.3 worse/0.85 better, REGULATION ×1.2 worse
##     /0.9 better.
##
## Subtype for this seed: overt contempt + performative grandiosity.
## Mother is a person who performs expertise and identity loudly,
## and delivers sharp, specific contempt to the protagonist.
## Childhood memory: Mother publicly evaluating the protagonist
## in a way that was available for others to hear.
##
## Craft discipline (NIM-specific):
##   - Critic voice uses language that sounds like Mother. Not
##     generic "you should." Specific phrases Mother said or says.
##   - Firefighter is an angry-protector. The protagonist *wants
##     to leave*. Wants to confront. The impulse is not to freeze
##     or fawn.
##   - Prose has sharper edges. More short sentences. Less soft
##     hedging.

label a1c1_nim_start:
    scene black
    show screen tooltip_overlay

    ## Set the branch.
    $ resource_snapshot = resource_snapshot.__class__(
        values=resource_snapshot.values,
        connection_per_npc=resource_snapshot.connection_per_npc,
        branch=_res.Branch.NIM,
    )

    if not chapter_notice_shown.get("a1c1_nim", False):
        centered "Chapter One — NIM branch\n\nNarcissistic/immature-parent backstory variant. Contempt and grandiosity patterns. The opening-scene critic uses language that sounds like Mother — this is by design (identified-with-aggressor). No on-screen parent contact in this chapter."
        $ chapter_notice_shown["a1c1_nim"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a1c1_nim_skipped

    scene black
    with dissolve

    e "Morning. The phone is on, because you slept with it on, because sleeping without it is a conversation you had with yourself at two AM and lost."

    e "You scroll for four minutes. Four is the minimum. Four is a number you negotiated with yourself once."

    ## The NIM-branch critic speaks in Mother-derived cadences.
    ## Short declarative sentences. Specific nouns. A specific
    ## contempt-flavour that is hers, not the generic critic's.
    critic_voice "Look at you. Four minutes of this already. At forty-three minutes you will still be doing this. You do not have the discipline."

    e "The Critic did not invent the word discipline. Mother used it. Mother used it at dinner parties where people could hear. Mother used it on you in particular, in company."

    $ rr_delta("critic_volume", +10)
    $ rr_delta("threat_scan", +6)
    $ rr_delta("self_trust", -4)

    ## Fight/flight firefighter arrives. Its impulse is to leave.
    firefighter_voice "Let's get up. Not to be good. To not be here. Move."

    e "The Firefighter's suggestion is the Firefighter's suggestion. It is not wrong. It is also not a plan."

    menu:
        "get up; move; do not read the scroll":
            jump a1c1_nim_move
        "stay; argue with the Critic in your head":
            jump a1c1_nim_argue
        "scroll harder; outrun it":
            jump a1c1_nim_scroll_harder


label a1c1_nim_move:
    scene black
    e "You get up. You do not look at the screen. You make the bed with specific corners."

    e "The corners are a Mother corner. You fold them the way she folded them. You cannot unfold them the way she folded them; the fold is under the nail of your right thumb."

    $ rr_delta("presence", +3)
    $ rr_delta("self_trust", +3)
    $ rr_delta("interoception", +3)

    critic_voice "Look. The corner is wrong."

    e "You look at the corner. The corner is not wrong. You made the corner exactly. The Critic is saying the Mother-thing that has nothing to do with the corner."

    $ rr_delta("critic_volume", -3)
    $ rr_delta("self_trust", +3)

    ## Recognition: noticed the critic using Mother's register on
    ## an unrelated target.
    $ reco_credit("part_register_identified", "a1c1_nim_critic_mother_register")

    $ act1c1_nim_outcome = "moved"
    jump a1c1_nim_close


label a1c1_nim_argue:
    scene black
    e "You stay in bed. You start the argument. You have had this argument a thousand times. You are not going to win this argument."

    e "The Critic is saying the specific sentences Mother said. You are saying the specific sentences you learned to say back."

    $ rr_delta("critic_volume", +6)
    $ rr_delta("energy", -6)
    $ rr_delta("regulation", -4)

    critic_voice "You are already late. You have already failed. You have already been failing for two years."

    e "You are answering. Your hand is doing the thing where it makes a fist under the blanket. Fights, even lost ones, are exhausting."

    $ rr_delta("threat_scan", +5)
    $ rr_delta("social_battery", -4)

    $ act1c1_nim_outcome = "argued"
    jump a1c1_nim_close


label a1c1_nim_scroll_harder:
    scene black
    e "You scroll harder. You do not leave the bed. You do not make the corner."

    e "The scroll is not the point. The scroll is the moving-away-from-the-Critic."

    firefighter_voice "Go faster. Don't give her anything to land on."

    ## Angry-protector firefighter is doing its fight-flight thing.
    $ rr_delta("energy", -8)
    $ rr_delta("presence", -6)
    $ rr_delta("critic_volume", +4)
    $ rr_delta("flashback_pressure", +4)

    e "Twenty minutes pass. You have won the argument by not being in the argument. The Critic is still there. Mother is in the Critic and the Critic is in Mother."

    $ act1c1_nim_outcome = "scrolled_harder"
    jump a1c1_nim_close


label a1c1_nim_close:
    scene black
    with fade
    e "The morning continues. The Critic continues. Mother is asleep, or at a pilates class, or lecturing someone at a wine bar. She is not in this apartment. She is very much in this apartment."

    e "Your sister is also not in the apartment yet. Your sister will be in the apartment by the time you are in the kitchen, and the kitchen is a different kitchen now."

    flame "the critic on this path is not a generic inner critic. it has been a person's voice. noticing whose voice is not the same as silencing the voice. noticing is its own thing."

    ## Chapter-end reflection.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a1c1_nim_feeling")
    e "This path continues in a future update; for now you can return here to try the other paths."

    menu:
        "continue to Chapter Two (NIM)":
            jump a1c2_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a1c1_nim_skipped:
    scene black
    centered "Chapter One (NIM variant) was skipped."
    pause 1.5
    e "The morning happened. The critic happened. You did what you did."
    $ rr_delta("critic_volume", +4)
    $ rr_delta("threat_scan", +4)

    menu:
        "continue to Chapter Two (NIM)":
            jump a1c2_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
