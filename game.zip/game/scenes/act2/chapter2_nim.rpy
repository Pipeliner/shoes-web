## scenes/act2/chapter2_nim.rpy — Act II Ch 2 NIM-branch exile-approach variant.
##
## Same exile-gate mechanic as CEN and MI (PRD §4.6 + amendment A1):
##   - permission >= PERMISSION_MIN_EXILE (65)
##   - Both Manager and Firefighter have consented in a prior scene.
##
## Branch-specific memory textures (per PRD §4.3 and amendment A10):
##   - CEN exile: 7yo on cold kitchen squares, Mother physically absent.
##   - MI exile:  8yo outside Mother's bedroom door, counting to ninety.
##     Mother behind the door in a depressive stretch.
##   - NIM exile: 11yo in her own bedroom, pale blue dress still on,
##     listening to Mother on the phone through the wall, retelling
##     the dining-party story from earlier. Mother is saying the
##     child's name the way she said it at dinner.
##
## The NIM exile signature is *listening*, not waiting (CEN) or
## counting (MI). The child is ears-forward, pulling in a version
## of herself being narrated by Mother to someone else. The adult
## arrives and also listens — the contact is double-witness, not
## rescue. Per the "approach rather than catharsis" thesis (PRD
## §4.6), the adult does NOT go to the hallway, does NOT cover the
## child's ears, and does NOT interrupt. Staying-and-hearing is
## the scene.
##
## Refusal-of-false-resolution moment parallels MI's "I don't
## remember whether the knock happened." For NIM, the adult's line
## is "I don't remember what she said next." Both refuse the
## redemption of retrospective clarity; both keep the memory
## honestly partial.
##
## Same Recognition credit type (SAT_WITH_EXILE) with a distinct
## event_id so a player running all three branches accumulates
## all three exile contacts.
##
## The memory bridges from a1c2_nim (post-call dining-room
## flashback) and a2c1_nim (post-email dining-room flashback)
## via the shared library snippet
## verb_tense_torque.public_humiliation_eleven_pale_blue — the
## exile scene zooms from the public humiliation into the private
## post-party bedroom where Mother's retelling continues through
## a wall.

label a2c2_nim_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c2_nim", False):
        centered "Chapter Five — NIM branch\n\nBrief contact with a childhood part of the protagonist. Present tense, small sensory detail. The NIM-branch exile is eleven, listening to Mother retelling a dining-party story through a bedroom wall. Scene is skippable."
        $ chapter_notice_shown["a2c2_nim"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c2_nim_skipped

    ## Same gate evaluation as CEN/MI. The gate does not know about
    ## branches.
    $ gate = pp_exile_gate()

    if gate.approved:
        jump a2c2_nim_approved
    else:
        jump a2c2_nim_gated


label a2c2_nim_gated:
    scene black
    e "There is a quieter part of you in the next room, so to speak."
    e "You can feel that there is a next room."

    ## NIM-register protector voices: threat-scan / angry-protector.
    if gate.missing_manager_consent and gate.missing_firefighter_consent:
        caretaker_voice "I am still calculating whether it is safe to hear any of this. I have not agreed yet."
        firefighter_voice "And I have not agreed to stop getting you out of rooms you cannot be in."
        e "Two parts of you are standing in front of the door. They are not hostile. They have not yet said yes."
    elif gate.missing_manager_consent:
        caretaker_voice "I am still calculating whether it is safe to hear any of this. I have not agreed yet."
        e "The threat-scanning part is standing in front of the door. Not to stop you. To finish the calculation that keeps it — keeps you — ready."
    elif gate.missing_firefighter_consent:
        firefighter_voice "I have not agreed to stop getting you out of rooms you cannot be in."
        e "The angry-protector part is standing in front of the door. It does not trust you to stay in a room with a voice on the other side of the wall."

    if gate.permission_too_low:
        e "Something else is also not yet in place. A kind of internal permission. It is not something you can decide from the outside."
        e "It grows when the parts in front of the door feel heard."

    e "The next room will still be there, later."

    menu:
        "sit with the part of you that is not yet ready":
            if gate.missing_manager_consent:
                $ which = "caretaker"
                caretaker_voice "Thank you for not pushing past me. The calculation is long."
            elif gate.missing_firefighter_consent:
                $ which = "numb-out"
                firefighter_voice "Thank you for not telling me to leave."
            else:
                $ which = "caretaker"
            $ intervention = renpy.call_screen(
                "negotiate",
                part_name=which,
                opening_line="I am not yet ready for you to go further. Ask me what I am trying to do for you.",
            )
            if intervention is None:
                $ intervention = ("ask", which)
            $ response_key = pp_intervene(intervention[0], intervention[1])
            e "A part of you breathes differently after that."
            jump a2c2_nim_after_negotiate

        "leave it for today":
            e "You leave it for today. The next room will still be there."
            jump a2c2_nim_after_negotiate


label a2c2_nim_after_negotiate:
    $ gate = pp_exile_gate()
    if gate.approved:
        e "Something has shifted. The door is no longer held."
        menu:
            "go in, for a moment":
                jump a2c2_nim_approved
            "another day":
                jump a2c2_nim_close
    else:
        jump a2c2_nim_close


label a2c2_nim_approved:
    ## The NIM-specific exile scene. Different memory; same
    ## discipline per PRD §7.1 (present tense, child-age vocab,
    ## short sentences, no monologue, small sensory detail).
    ## Flashback uses verb_tense_torque.public_humiliation_eleven_pale_blue
    scene black
    with slowdissolve

    e "You step through."

    pause 1.0

    exile_voice "The bedroom has a door."

    exile_voice "The door is not closed all the way."

    pause 1.5

    exile_voice "I am in the pale blue dress still."

    exile_voice "She has not said I can take it off."

    pause 1.5

    ## The auditory anchor. Mother is on the phone in the hallway,
    ## retelling the dining-party story to someone else. The child
    ## is listening through the wall.
    exile_voice "I can hear her on the phone."

    exile_voice "She is telling the story. The one from dinner."

    pause 1.5

    ## The adult arrives and also listens. Double-witness. The
    ## adult's role is NOT to shield or interrupt — staying and
    ## hearing is the scene.
    e "You are thirty-four. You are standing in a bedroom with an eleven-year-old in a pale blue dress. You can also hear Mother in the hallway through the wall."

    e "You do not cover the child's ears. You do not go out to the hallway. You do not interrupt."

    exile_voice "She is saying my name."

    exile_voice "She is saying it the way she said it at dinner."

    pause 2.0

    e "You hear it too. You hear it the way it was said at dinner."

    exile_voice "Are you grown?"

    e "You say yes."

    exile_voice "What does she say next?"

    ## Refusal-of-false-resolution. Parallel to MI's "I don't
    ## remember whether the knock happened." The adult does not
    ## supply retrospective clarity the memory does not carry.
    e "You say: \"I don't remember what she said next.\""

    exile_voice "Oh."

    pause 1.5

    e "The child goes back to listening. The adult stays and listens too. The listening is the listening."

    ## Recognition: NIM-specific SAT_WITH_EXILE event so a replay
    ## across branches accumulates all three.
    $ reco_credit("sat_with_exile", "a2c2_nim_bedroom_door_listening")

    ## State deltas — same contract as CEN (+6 presence, −4
    ## permission, +5 self_trust, −6 critic) per A10 parity.
    ## Flashback-pressure delta +7 sits between CEN's +8 (visual
    ## wallpaper imagery) and MI's +6 (counting-without-imagery):
    ## the NIM memory is heavier in auditory intrusion — the
    ## mother's voice through the wall — but lighter than CEN's
    ## full sensory scene.
    $ rr_delta("presence", +6)
    $ rr_delta("permission", -4)
    $ rr_delta("self_trust", +5)
    $ rr_delta("critic_volume", -6)
    $ rr_delta("flashback_pressure", +7)

    flame "you stood in a bedroom with an eleven-year-old who was hearing her own name said that way on the other side of a wall. you heard it too. you did not pretend not to. that was the specific thing being asked of you this morning."

    jump a2c2_nim_close


label a2c2_nim_close:
    scene black
    with fade
    flame "nothing was fixed. you listened with a child to a voice through a wall."

    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c2_nim_feeling")

    e "The next part of the week is small, on-the-page choices. Some land. Some do not. The endings come after."

    menu:
        "continue to Chapter Six (NIM)":
            jump a2c3_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c2_nim_skipped:
    scene black
    centered "Chapter Five (NIM variant) was skipped."
    pause 1.5
    e "There was a voice in a hallway, and a dress, and you did not stay to hear today."

    menu:
        "continue to Chapter Six (NIM)":
            jump a2c3_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
