"""Parts system — IFS as generative metaphor.

Five archetypes (Manager, Firefighter, Exile, Inner Critic, Self-energy).
Negotiation loop with five intervention verbs. Consent tracking gates
exile-approach scenes.

Iatrogenic-fragmentation caveat is addressed in the writing layer (see
`.claude/rules/parts-language.md`); this module enforces the structural
constraints: exile approach requires BOTH a manager and a firefighter to
have consented in a prior scene, plus `permission >= PERMISSION_MIN_EXILE`.

Pickle-safe: top-level functions, enum state, dispatch tables by name,
no lambdas on instances.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field, replace
from typing import Optional

from game.logic.gates import PERMISSION_MIN_EXILE
from game.logic.resources import Band, Resource, ResourceSnapshot, band_for


class PartKind(str, enum.Enum):
    MANAGER = "manager"
    FIREFIGHTER = "firefighter"
    EXILE = "exile"
    CRITIC = "critic"
    # Self-energy is not a part; not enumerated here.


class Intervention(str, enum.Enum):
    """The negotiation-loop verbs (PRD §4.6)."""

    LISTEN = "listen"
    ASK = "ask"  # "ask what it is trying to do for you"
    DISAGREE = "disagree"  # gently
    DEFER = "defer"  # agree to wait
    OVERRIDE = "override"  # only when permission AND self_trust are high


# Per PRD §4.6, OVERRIDE is only visible when both permission and self_trust
# are high; and it has consequences — the part's trust in the self drops.
OVERRIDE_PERMISSION_MIN = 70
OVERRIDE_SELF_TRUST_MIN = 70
OVERRIDE_TRUST_DROP = 15  # damage to part.trust_in_self
OVERRIDE_CRITIC_SPIKE = 10  # collateral: critic_volume climbs after override


@dataclass
class Part:
    """A part's current relationship with the protagonist.

    Pickle-safe: plain fields, no lambdas.

    Attributes:
      name: stable identifier for dispatch (e.g., "caretaker").
      kind: which archetype.
      introduced: whether we've shown this part to the player.
      trust_in_self: 0..100, how much this part trusts the protagonist's
        self-energy. Decreases on OVERRIDE, recovers on LISTEN/ASK.
      consented_for_exile: has this part given the prior-scene consent
        required for exile approach? See `ExileGate`.
      intensity: 0..100. Parts at high intensity speak more often and can
        seize narration (firefighter turn).
    """

    name: str
    kind: PartKind
    introduced: bool = False
    trust_in_self: int = 30
    consented_for_exile: bool = False
    intensity: int = 40


@dataclass
class PartsState:
    """Collection of parts. Keyed by name for dispatch.

    A firefighter-turn counter ticks when a firefighter hits intensity >= FIREFIGHTER_SEIZE.
    """

    parts: dict[str, Part] = field(default_factory=dict)

    def get(self, name: str) -> Part:
        return self.parts[name]

    def add(self, part: Part) -> "PartsState":
        new_parts = dict(self.parts)
        new_parts[part.name] = part
        return replace(self, parts=new_parts)

    def with_part(self, part: Part) -> "PartsState":
        return self.add(part)

    def introduce(self, name: str) -> "PartsState":
        p = self.parts[name]
        return self.with_part(replace(p, introduced=True))


# ---------------------------------------------------------------------------
# Intervention application
# ---------------------------------------------------------------------------


FIREFIGHTER_SEIZE_THRESHOLD = 75


@dataclass(frozen=True)
class InterventionResult:
    """Outcome of applying an intervention to a part.

    `snapshot` is the new ResourceSnapshot. `parts` is the new PartsState.
    `part_response_key` names a dispatch key into scene-layer dialogue
    (the actual line text lives in `.rpy` files).
    """

    snapshot: ResourceSnapshot
    parts: PartsState
    part_response_key: str


def apply_intervention(
    intervention: Intervention,
    part_name: str,
    snapshot: ResourceSnapshot,
    parts: PartsState,
) -> InterventionResult:
    """Apply a negotiation-loop intervention to a part.

    Tuning is deliberately gentle — negotiation, not defeat (PRD §4.6).
    """
    part = parts.get(part_name)
    return _INTERVENTION_DISPATCH[intervention](part, snapshot, parts)


def _listen(
    part: Part, snap: ResourceSnapshot, parts: PartsState
) -> InterventionResult:
    new_part = replace(
        part,
        trust_in_self=_clamp(part.trust_in_self + 8),
        intensity=_clamp(part.intensity - 10),
        introduced=True,
    )
    new_parts = parts.with_part(new_part)
    new_snap = snap.with_delta(Resource.CRITIC_VOLUME, -3)
    new_snap = new_snap.with_delta(Resource.SELF_TRUST, +3)
    return InterventionResult(
        new_snap, new_parts, f"{part.name}_listened_to"
    )


def _ask(
    part: Part, snap: ResourceSnapshot, parts: PartsState
) -> InterventionResult:
    """'Ask what it is trying to do for you.'

    The big move. This is what actually moves permission over time.

    **Depleted-band bonus** (PRD amendment A13, audit P-3 closure
    0.1.18-46): when permission is currently in DEPLETED band
    (< 30), grant an additional +6 permission on top of the
    standard +5. The bonus exists because the
    critic_volume↔permission inverse reactive pair drains
    permission hardest in depleted band; without the bonus,
    NIM playthroughs (CRITIC_VOLUME ×1.3 BRANCH_BIAS) cannot
    reach the 65-permission exile gate even with optimal play.
    The bonus is branch-blind (applies on all three branches)
    but in practice only NIM and the deepest-depleted MI/CEN
    paths are likely to be in DEPLETED band when ASKing. See
    M1 simulator validation (`tests/e2e/test_playthroughs.py
    ::TestCycleWitnessedNIM`) for the calibration.
    """
    new_part = replace(
        part,
        trust_in_self=_clamp(part.trust_in_self + 12),
        intensity=_clamp(part.intensity - 15),
        introduced=True,
    )
    # Consent for exile-approach — earned by protector-focused work.
    if part.kind in (PartKind.MANAGER, PartKind.FIREFIGHTER):
        new_part = replace(new_part, consented_for_exile=True)
    new_parts = parts.with_part(new_part)
    # Determine band BEFORE applying the delta, so the bonus
    # depends on entry-state (the band the protagonist is in
    # at the moment of asking, not the post-ASK band).
    permission_band = band_for(
        Resource.PERMISSION, snap.get(Resource.PERMISSION)
    )
    new_snap = snap.with_delta(Resource.PERMISSION, +5)
    if permission_band == Band.DEPLETED:
        new_snap = new_snap.with_delta(Resource.PERMISSION, +6)
    new_snap = new_snap.with_delta(Resource.CRITIC_VOLUME, -4)
    new_snap = new_snap.with_delta(Resource.SELF_TRUST, +4)
    return InterventionResult(new_snap, new_parts, f"{part.name}_asked_intent")


def _disagree(
    part: Part, snap: ResourceSnapshot, parts: PartsState
) -> InterventionResult:
    """Disagree gently. Mid-tier: small self-trust gain, small part-trust cost."""
    new_part = replace(
        part,
        trust_in_self=_clamp(part.trust_in_self - 3),
        intensity=_clamp(part.intensity - 5),
        introduced=True,
    )
    new_parts = parts.with_part(new_part)
    new_snap = snap.with_delta(Resource.SELF_TRUST, +2)
    return InterventionResult(new_snap, new_parts, f"{part.name}_disagreed_with")


def _defer(
    part: Part, snap: ResourceSnapshot, parts: PartsState
) -> InterventionResult:
    """Agree to wait. Part-trust recovers; self-trust unchanged."""
    new_part = replace(
        part,
        trust_in_self=_clamp(part.trust_in_self + 4),
        intensity=_clamp(part.intensity - 8),
        introduced=True,
    )
    new_parts = parts.with_part(new_part)
    return InterventionResult(snap, new_parts, f"{part.name}_deferred_to")


def _override(
    part: Part, snap: ResourceSnapshot, parts: PartsState
) -> InterventionResult:
    """Only visible when permission AND self_trust are high.

    Consequences: part.trust_in_self drops; critic_volume climbs.
    """
    new_part = replace(
        part,
        trust_in_self=_clamp(part.trust_in_self - OVERRIDE_TRUST_DROP),
        intensity=_clamp(part.intensity + 10),
        introduced=True,
    )
    new_parts = parts.with_part(new_part)
    new_snap = snap.with_delta(Resource.CRITIC_VOLUME, +OVERRIDE_CRITIC_SPIKE)
    new_snap = new_snap.with_delta(Resource.PERMISSION, -8)
    return InterventionResult(new_snap, new_parts, f"{part.name}_overridden")


_INTERVENTION_DISPATCH: dict[Intervention, callable] = {
    Intervention.LISTEN: _listen,
    Intervention.ASK: _ask,
    Intervention.DISAGREE: _disagree,
    Intervention.DEFER: _defer,
    Intervention.OVERRIDE: _override,
}


def override_available(snap: ResourceSnapshot) -> bool:
    """OVERRIDE only visible when permission AND self_trust are both high."""
    return (
        snap.get(Resource.PERMISSION) >= OVERRIDE_PERMISSION_MIN
        and snap.get(Resource.SELF_TRUST) >= OVERRIDE_SELF_TRUST_MIN
    )


# ---------------------------------------------------------------------------
# Firefighter-turn seizure
# ---------------------------------------------------------------------------


def firefighter_seizing(parts: PartsState) -> Optional[Part]:
    """Return a firefighter that is seizing narration, or None.

    A firefighter-turn replaces the next player choice with a part-authored
    action. Per PRD §4.6, this triggers when intensity crosses the seizure
    threshold.
    """
    for part in parts.parts.values():
        if (
            part.kind is PartKind.FIREFIGHTER
            and part.intensity >= FIREFIGHTER_SEIZE_THRESHOLD
        ):
            return part
    return None


# ---------------------------------------------------------------------------
# Exile-approach gate
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ExileGateResult:
    approved: bool
    # Reasons populated when approved is False. Used to tell the player which
    # protector hasn't consented yet.
    missing_manager_consent: bool = False
    missing_firefighter_consent: bool = False
    permission_too_low: bool = False


def exile_gate(
    snapshot: ResourceSnapshot, parts: PartsState
) -> ExileGateResult:
    """Can we approach an exile right now?

    Requires (PRD §4.6):
      - `permission >= PERMISSION_MIN_EXILE`
      - At least one Manager has consented in a prior scene.
      - At least one Firefighter has consented in a prior scene.
    """
    manager_consent = any(
        p.kind is PartKind.MANAGER and p.consented_for_exile
        for p in parts.parts.values()
    )
    firefighter_consent = any(
        p.kind is PartKind.FIREFIGHTER and p.consented_for_exile
        for p in parts.parts.values()
    )
    permission_ok = snapshot.get(Resource.PERMISSION) >= PERMISSION_MIN_EXILE
    if manager_consent and firefighter_consent and permission_ok:
        return ExileGateResult(approved=True)
    return ExileGateResult(
        approved=False,
        missing_manager_consent=not manager_consent,
        missing_firefighter_consent=not firefighter_consent,
        permission_too_low=not permission_ok,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _clamp(v: int) -> int:
    if v < 0:
        return 0
    if v > 100:
        return 100
    return v


# Starter cast for the CEN branch MVP (per PRD §5.3). Three parts + critic.
def starter_parts_cen() -> PartsState:
    """Starting parts for the CEN branch MVP. One manager, one firefighter,
    one critic, plus a silent-exile stub (not introduced)."""
    ps = PartsState()
    ps = ps.add(Part(name="caretaker", kind=PartKind.MANAGER, intensity=55))
    ps = ps.add(Part(name="numb-out", kind=PartKind.FIREFIGHTER, intensity=40))
    ps = ps.add(Part(name="critic", kind=PartKind.CRITIC, intensity=65))
    ps = ps.add(Part(name="small-one", kind=PartKind.EXILE, intensity=20))
    return ps


__all__ = [
    "ExileGateResult",
    "FIREFIGHTER_SEIZE_THRESHOLD",
    "Intervention",
    "InterventionResult",
    "OVERRIDE_CRITIC_SPIKE",
    "OVERRIDE_PERMISSION_MIN",
    "OVERRIDE_SELF_TRUST_MIN",
    "OVERRIDE_TRUST_DROP",
    "Part",
    "PartKind",
    "PartsState",
    "apply_intervention",
    "exile_gate",
    "firefighter_seizing",
    "override_available",
    "starter_parts_cen",
]
