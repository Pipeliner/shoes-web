## scenes/act2/chapter3_nim.rpy — Act II Ch 3 NIM-branch variant.
##
## Mirrors the structural arc of `game/scenes/act2/chapter3.rpy`
## (the CEN therapist session) and `chapter3_mi.rpy` in the NIM
## register. Same eight-beat shape: chapter notice + skip menu;
## opening on the rug; therapist's email-prompt with three
## response options; opened branch; deflect branch; silence
## branch; mid-session *Both are true* moment with a cross-
## temporal anchor; close + between-session task; out + Flame.
##
## NIM-bias amplifications per PRD §4.3 BRANCH_BIAS[NIM]:
##   - CRITIC_VOLUME ×1.3 worse
##   - THREAT_SCAN ×1.3 worse
##   - SOCIAL_BATTERY ×1.2 worse
## Authored deltas mirror the CEN scene; the simulator applies
## the bias multipliers. Do not pre-bias here.
##
## Cross-temporal anchor pivot (the highest-risk decision per
## docs/mi-act2-ch3-4-plan-0.1.18-31.md §7, applied to NIM).
## CEN's mid-session beat pivots on the kitchen with the yellow
## wallpaper at age 13. MI's pivots on the hallway with the
## telephone table at age 8. The NIM variant pivots on the
## **dining room with six adults at age eleven** — the pale-blue-
## dress public-humiliation memory established in `a1c2_nim:177`
## and reused in `a2c1_nim:109` as the signature childhood
## scene. The therapist references a dining-room-adjacent earlier
## session as the way the topic surfaced; the texture the
## protagonist drifts into is the dining room, not a kitchen or
## a hallway.
##
## Craft discipline (per chapter3.rpy header):
##   - Therapist asks more than she tells.
##   - No diagnosis names; no modality labels; no outcome
##     promises.
##   - The therapist does not articulate the protagonist's parts
##     for her (per docs/continuity.md:842-846).
##   - The protagonist's register is allowed to drift into the
##     exile register for one paragraph at most, mid-session, via
##     verb-tense torque.
##
## State effects match the interior_work_therapist_session beat
## family in tests/e2e/beats.py.

label a2c3_nim_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c3_nim", False):
        centered "Chapter Six — Act II (continued, NIM branch)\n\nThis chapter contains a depicted therapy session. The game is not therapy; this scene is fiction. The therapist is trauma-informed. The session opens on the aunt's email about Mother."
        $ chapter_notice_shown["a2c3_nim"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c3_nim_skipped

    scene black
    with dissolve

    e "It is Wednesday. The room has a rug that is older than you are. The rug has a coffee-stain on it that you have not once asked about."

    e "You take your shoes off on the rug. You have been doing that for fourteen months. The rug is the reason."

    e "You sit in the chair you always sit in. Not the couch. The chair."

    therapist "We left off last time with the email from your aunt. Have you opened it?"

    menu:
        "say yes, and what happened after":
            jump a2c3_nim_opened
        "say you opened it and you are trying not to think about it":
            jump a2c3_nim_deflect
        "say nothing for a moment":
            jump a2c3_nim_silence


label a2c3_nim_opened:
    e "You say yes. You say you opened it, and then your knees were straight before the thought was, and the next thing you remember clearly is the stairwell."

    therapist "Where did you go?"

    e "You say: out. Not far. The street."

    therapist "The part of you that got you out of the chair — was it trying to protect something?"

    menu:
        "say: I think it was":
            firefighter_voice "It was."
            ## The angry-protector firefighter answers in its own
            ## voice (established at a2c1_nim:131 — "Get up. Get
            ## out. Now."). The narrator names the noticing-of-the-
            ## answering as its own beat, same pattern as
            ## chapter3.rpy:72 and chapter3_mi.rpy:89.
            e "You can feel which part of you turned to face the question. You say what you noticed: that something inside you got the body up before the thinking caught up, and the getting-up was old, and it had been keeping you out of rooms it had decided were not safe for as long as you could remember."
            $ rr_delta("permission", +6)
            $ rr_delta("self_trust", +5)
            $ rr_delta("critic_volume", -4)
            therapist "That noticing is the work. Not the answer. The noticing."
            $ reco_credit("part_register_identified", "a2c3_nim_angry_protector_named")
            jump a2c3_nim_midsession

        "say: I don't know":
            e "You say you don't know."
            therapist "That is also a real answer."
            $ rr_delta("self_trust", +2)
            jump a2c3_nim_midsession


label a2c3_nim_deflect:
    e "You say you are trying not to think about it."

    therapist "Mm."

    e "The therapist does not pursue. This is the thing she does. She leaves the silence unfilled."

    $ rr_delta("regulation", +2)

    menu:
        "let the silence hold":
            ## NIM-flavour deflect: the manager that runs the
            ## threat-scan inventory is still working under the
            ## silence. Same shape as MI's deflect (chapter3_mi.rpy
            ## :115) — hypervigilant manager — but the NIM register
            ## is *scanning the room for what's about to happen*,
            ## not *counting rings*. The scan is the texture
            ## established by the threat_scan resource and the
            ## a1c2_nim public-humiliation lead-up.
            e "You let it. The silence is long and specific. The part of you that scans rooms is still scanning under the silence; you can feel it doing that — clocking the door, the window, the therapist's hands."
            $ rr_delta("presence", +4)
            $ rr_delta("interoception", +3)
            jump a2c3_nim_midsession
        "break the silence, anything":
            e "You fill the silence with a story about nothing. The scan keeps running underneath."
            $ rr_delta("critic_volume", +3)
            jump a2c3_nim_midsession


label a2c3_nim_silence:
    e "You say nothing for a moment. The therapist does not hurry."
    pause 1.0
    e "The moment is long enough that you notice what you are not saying."

    $ rr_delta("presence", +5)
    $ rr_delta("interoception", +4)
    $ rr_delta("regulation", +4)
    $ rr_delta("permission", +3)

    therapist "What's here, right now?"

    menu:
        "say: something small, in the chest":
            e "You say: something small, in the chest."
            therapist "Can it stay there for a moment, while we talk?"
            $ rr_delta("presence", +3)
            jump a2c3_nim_midsession
        "say: I don't know":
            e "You say you don't know."
            therapist "Then we don't have to know. Yet."
            $ rr_delta("self_trust", +3)
            jump a2c3_nim_midsession


label a2c3_nim_midsession:
    ## The mid-session moment — a permitted exile-register
    ## paragraph, via verb-tense torque. No full flashback; no
    ## library entry; no visual effect. The pivot is the dining
    ## room with six adults at age eleven (per
    ## docs/continuity.md:551-555 + a1c2_nim:177 + a2c1_nim:109),
    ## NOT the yellow wallpaper at thirteen (CEN signature) or
    ## the hallway at eight (MI signature).
    ##
    ## The therapist's referencing line keeps the prior-session
    ## bridge in the same shape as CEN/MI: the protagonist
    ## mentioned, last week, that her childhood had a dining
    ## table she remembered. This session, the therapist comes
    ## back to a different specific from the same childhood: the
    ## dress, the room, the laughing.
    scene black
    with fade

    therapist "You said last week that there was a dining table in your childhood you came back to. I want to come back to that, if it's ok."

    e "There is a dining room with six adults at it."

    e "You are eleven. You are in a pale blue dress. She has dressed you in it for the evening. The room is laughing, not unkindly, at something she is telling them about you."

    e "You are in the chair. In the office. The rug is older than you are."

    therapist "Where are you right now?"

    e "You say: in the chair."

    therapist "And also?"

    e "You say: sometimes in the dining room."

    therapist "Both are true."

    ## The therapist's signature move: permitting both, not
    ## forcing a return. State effects match the CEN/MI authored
    ## deltas; bias is applied by the simulator.
    ##
    ## No Recognition credit at this beat — CEN's equivalent at
    ## chapter3.rpy:155-164 and MI's at chapter3_mi.rpy:198-202
    ## also do not credit Recognition here. The mid-session
    ## moment's value is the state weight, not a Recognition tick;
    ## the close-path task earns the reflection_completed credit
    ## on the same beat schedule as CEN/MI.
    $ rr_delta("permission", +8)
    $ rr_delta("regulation", +8)
    $ rr_delta("critic_volume", -6)
    $ rr_delta("self_trust", +4)
    $ rr_delta("presence", +4)

    jump a2c3_nim_close


label a2c3_nim_close:
    scene black
    with fade

    therapist "We're near the end of the hour. How do you want to leave?"

    menu:
        "with a small task to try this week":
            therapist "Okay. Something small. What feels small enough?"
            ## The between-session task names the angry-protector
            ## firefighter in the same noticing register the scene
            ## has been using — *the part that gets you out of the
            ## room* (per a2c1_nim:131-134 and the firefighter's
            ## answer in a2c3_nim_opened above). The therapist does
            ## not articulate it as a "part" diagnostically; she
            ## uses the protagonist's words back.
            e "You say: noticing when the part that gets you out of the room shows up."
            therapist "That's a good one. You don't have to do anything with it. Just notice."
            $ rr_delta("permission", +2)
            $ reco_credit("reflection_completed", "a2c3_nim_between_session_task")
            jump a2c3_nim_out

        "with nothing; I don't want homework":
            therapist "Okay. We'll talk Wednesday."
            $ rr_delta("self_trust", +3)
            jump a2c3_nim_out

        "with the silence from the middle":
            therapist "Let's leave it there."
            e "The silence sits down again between you."
            $ rr_delta("presence", +3)
            $ rr_delta("regulation", +3)
            jump a2c3_nim_out


label a2c3_nim_out:
    scene black
    $ chapter_completed["a2c3_nim"] = True
    e "You put your shoes back on. You did not realize you had taken them off. The rug is the reason. You always take them off on the rug."

    ## Prior-week task callback. In NIM the prior-week task was
    ## *noticing when the scan was running*. The threat-scanning
    ## hypervigilant manager from a1c1_nim and a1c2_nim — the
    ## part that clocks rooms for what is about to be said — is
    ## the NIM-signature counterpart to MI's inventory-counting
    ## manager and CEN's noticing-what-you-take-your-shoes-off-
    ## for. Same shape, NIM-flavoured.
    e "Last week's task was noticing when the scan was running. The dinner with Sam. The pub with Ben. Anything that has the texture of a room being clocked. You have not yet said out loud what the noticing has been finding."

    e "You pay the co-pay at the desk."

    e "The afternoon is the afternoon."

    flame "wednesdays are the days with less friction, she said. that sounds right."

    ## Reflection prompt as chapter-end. Recognition source.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c3_nim_feeling")

    menu:
        "continue to Chapter Seven (NIM)":
            jump a2c4_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c3_nim_skipped:
    scene black
    centered "Chapter Six (NIM variant) was skipped."
    pause 1.5
    e "You had a session. Something happened in it. The next chapter continues."
    ## Modest between-session gain so the skipped chapter doesn't
    ## penalise committed players who skip for content reasons.
    ## Does NOT set chapter_completed — that's reserved for the
    ## close path.
    $ rr_delta("regulation", +3)
    $ rr_delta("permission", +3)

    menu:
        "continue to Chapter Seven (NIM)":
            jump a2c4_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
