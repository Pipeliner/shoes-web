## scenes/act3/endings.rpy — ending dispatch and the four endings.
##
## Per PRD §4.9: four endings, none of which is "healed." Identical
## credits text across all four (PRD §4.9). Residue that doesn't resolve
## is the honesty marker.
##
## Semantic precision from docs/prd-amendments.md:
##   - Cycle repeating: returned to a pattern; named; no shame.
##   - Cycle paused:    stepped out of an arrangement without replacing
##                      it; unstable.
##   - Cycle shifting:  consent earned from protectors; permission below
##                      exile-threshold; a small partial change holds
##                      elsewhere. Residue visible.
##   - Cycle witnessed: named what happened to a specific other and was
##                      met, partially. Relationship does not repair
##                      fully. Highest Recognition.

label ending_dispatch:
    scene black
    with fade

    $ available = list(recognition_ledger.available_endings())
    $ ending_keys = [e.value for e in available]

    ## Priority dispatch: the highest-tier ending the player has
    ## unlocked shows. Players can replay to see others. We do not
    ## pick mechanically — the premise refuses reward-for-noticing
    ## as a win condition.
    if "cycle_witnessed" in ending_keys:
        jump ending_cycle_witnessed
    elif "cycle_shifting" in ending_keys:
        jump ending_cycle_shifting
    elif "cycle_paused" in ending_keys:
        jump ending_cycle_paused
    else:
        jump ending_cycle_repeating


## -----------------------------------------------------------------
## CYCLE_REPEATING — always available.
## "The protagonist returns to a pattern. The game names the pattern
## and stops. No shame frame."
## -----------------------------------------------------------------

label ending_cycle_repeating:
    scene black

    e "It is a morning like the morning you began with."

    e "The phone is warm in your hand."

    e "Lena is in the kitchen. The kettle is on."

    e "You scroll for a while. You do not yet stand up."

    e "A part of you clears its throat. You know what it is going to say."

    e "It is the same part that cleared its throat last week, and the week before, and the year before that. It is tired. So are you."

    e "You stand up. You go to the kitchen. You do the thing."

    e "The pattern names itself."

    ## Per U1 (0.1.18-46): per-branch Caretaker close-line.
    ## The pattern is the same; the Caretaker that has been
    ## holding the pattern reads the morning differently per
    ## branch. The lines stay short — REPEATING is a
    ## pattern-naming ending, not a Caretaker monologue.
    if resource_snapshot.branch == res.Branch.MI:
        caretaker_voice "I have been here, on this morning, with you, since you were eight. I have not been wrong about it yet."
    elif resource_snapshot.branch == res.Branch.NIM:
        caretaker_voice "Nobody is going to hear about this morning. The room is quiet. The room is mostly always quiet at this hour. That is, in its way, a small kind of safety."

    jump credits_text


## -----------------------------------------------------------------
## CYCLE_PAUSED — stepped out of an arrangement without replacing it.
## Unstable. The epilogue admits so.
## -----------------------------------------------------------------

label ending_cycle_paused:
    scene black
    with fade

    e "There is a conversation you did not have."

    e "Earlier in the week, you walked out of the thing you were about to do. Not to do a different thing — to not do the thing."

    e "You put your shoes on. You went outside. You walked to the corner, then past the corner, then to the bench where you stopped."

    pause 1.0

    e "You sat there for a while. The while was long. Nothing replaced the arrangement you had walked out of."

    e "At the bench you thought: so this is what this part of the day is now."

    e "The pause has no plan after it. You do not know if it holds."

    e "A part of you — the one that makes plans — is quiet, and the quiet is new. It is not a relief. It is a vacancy."

    flame "pauses are not strategies. they are pauses."

    ## Per U1 (0.1.18-46): per-branch Caretaker close-line.
    ## PAUSED is a quiet-vacancy ending; the Caretaker line
    ## stays short to honor that. Each branch's Caretaker
    ## registers what the bench-pause means within its own
    ## working model.
    if resource_snapshot.branch == res.Branch.MI:
        caretaker_voice "I do not have a stretch-prediction for this. I have not had a no-data-input hour in a long time."
    elif resource_snapshot.branch == res.Branch.NIM:
        caretaker_voice "Nobody knows you are on this bench. The bench is not in the inventory. I do not have a forecast for this hour."

    e "You walked home in the evening. You did not restart the arrangement. You also did not replace it."

    e "The epilogue is the bench."

    jump credits_text


## -----------------------------------------------------------------
## CYCLE_SHIFTING — consent earned, threshold not crossed. A small
## specific partial change holds; other things do not. Residue visible.
## (Amendment A3.)
## -----------------------------------------------------------------

label ending_cycle_shifting:
    scene black
    with fade

    e "One thing was different this time. You could point to it."

    e "In the kitchen on Wednesday you asked Lena how she slept, and you waited for the answer before you added the other sentence."

    e "That was the whole shift. The waiting."

    pause 1.0

    e "Other things did not shift. The phone is still warm at the wrong hour. You still say 'it's going well' at the pitch of obedience. You are still a person who archives her mother's sister's emails."

    e "A part of you has been willing to stand aside at a door you have not yet walked through. Another part of you has not yet given the permission needed to walk through."

    e "This ending is not the one where you walk through the door. It is the one where, once, you waited for an answer before adding a sentence."

    pause 1.0

    caretaker_voice "I have not agreed to this yet."
    caretaker_voice "But I agreed to what you did on Wednesday."

    ## Per S4 (0.1.18-46): per-branch Caretaker close-line. The
    ## stretch-watcher (MI) and the threat-scanner (NIM) read
    ## "what you did on Wednesday" differently than CEN's
    ## general Caretaker.
    if resource_snapshot.branch == res.Branch.MI:
        caretaker_voice "Asking how she slept and waiting was the move I would have, in another year, called a stretch-check. This week it was just a question. I noticed."
    elif resource_snapshot.branch == res.Branch.NIM:
        caretaker_voice "Waiting for an answer was the move I would have, in another year, scanned for what came back. This week I let the answer be what came back. I noticed."

    e "The residue of the other things sits in the room with you. You do not pretend it is gone."

    flame "a partial change is not a lesser change. it is a specific one."

    jump credits_text


## -----------------------------------------------------------------
## CYCLE_WITNESSED — named what happened to a specific other person
## and was met, partially. The relationship does not repair fully.
## Highest Recognition required.
## -----------------------------------------------------------------

label ending_cycle_witnessed:
    scene black
    with fade

    ## This ending requires that the `mention_the_childhood_thing`
    ## structural-change scene landed "sent" or "long_sent". If it
    ## didn't, the witnessed ending is narratively unavailable —
    ## fall back to shifting. The Recognition threshold check in
    ## RecognitionLedger.available_endings() should usually make
    ## this unreachable without having sent; the jump here is a
    ## belt-and-braces narrative guard.
    $ _mention_outcome = act3_outcomes.get("mention_the_childhood_thing")
    if _mention_outcome not in ("sent", "long_sent"):
        ## Per playtest 2026-04-26: rewriting the fallback prose to
        ## stay in narrator voice rather than reference internal
        ## dispatcher mechanics. The protagonist would not say
        ## "the ending-dispatcher offered this variant"; she
        ## experiences (or doesn't experience) the choice she made.
        e "You wrote the text at two in the morning. You held the phone for a long time. You deleted the sentence before you sent it."
        e "The Saturday that follows the sending did not come. This is a different ending."
        jump ending_cycle_shifting

    e "You said it out loud, to a person, in a room."

    pause 1.0

    ## Per docs/clarity-pass-2-act2-act3.md item 5: the therapist
    ## scene (act2/chapter3.rpy) is skippable, so a player who
    ## skipped it has no referent for "the therapist". State-check
    ## the chapter notice flag and use a phrasing that doesn't
    ## assume the visit happened.
    if chapter_completed.get("a2c3", False):
        e "Not to the therapist, who has heard most of it. Not to Lena, who is tired in her own way, and whose room you have always kept this out of."
    else:
        e "Not to a therapist, though you have thought about it. Not to Lena, who is tired in her own way, and whose room you have always kept this out of."

    e "To Ben. In his kitchen, on a Saturday, because you had already said it to him in a text at two in the morning, and he had written back, and the Saturday followed from the text."

    pause 1.0

    if resource_snapshot.branch == res.Branch.MI:
        e "You told him about the hallway, the one with the telephone table, and the door that did not open and did not open. Not all of it. The specific part you can still hear in the silence between your sentences."
        e "You told him about the counting. Counting to ninety before you decided whether to knock. Counting again from the beginning whenever a sound from the room interrupted the count. The number ninety, you told him, you have not been able to figure out where it came from. Ninety was just the number."
    elif resource_snapshot.branch == res.Branch.NIM:
        e "You told him about the dining room with six adults, and the laughing that was not unkind, and the pale blue dress. Not all of it. The specific part you can still see when a room of strangers gets quiet at the wrong time."
        e "You told him about the laughing. The laughing was the part. The laughing was loud enough that it was not, you knew now, about you specifically — it was about the joke she had told them, which was about you, but the laughing belonged to her. The laughing was hers. You were eleven and the laughing was hers."
    else:
        e "You told him about the kitchen with the yellow wallpaper. Not all of it. The specific part you can still feel in the soles of your feet on certain floors."
        e "You told him about the squares. Cold squares with lines between them. The lines were what you were tracing when the call came. You had been tracing the lines for what may have been an hour. You had not eaten. The hour was, you said, the part."

    e "He did not fix it. He did not say the wrong thing. He also did not say the right thing, because there is no right thing, and he knew it."

    e "He said: okay."

    e "He said: thank you for telling me."

    ## Branch-flavored read of Ben's "what do you need" question.
    ## The line itself is the same; what the protagonist's
    ## branch-specific Caretaker hears in it differs.
    if resource_snapshot.branch == res.Branch.MI:
        e "He said: what do you need right now."
        e "The stretch-watcher heard the question correctly. Ben was asking what you needed. Ben was not — and this took the stretch-watcher a moment to register — checking on a stretch. The stretch-watcher does not have a category for that question, and so was, for a moment, quiet in a way it has not been quiet in twenty-three years."
    elif resource_snapshot.branch == res.Branch.NIM:
        e "He said: what do you need right now."
        e "The threat-scanner heard the question correctly. Ben was the only person in the room who knew which version of this question would NOT have worked. He did not ask if you were okay. He did not ask if you were going to be okay. He did not ask whether you were going to tell anyone else. He asked what you needed right now."
    else:
        e "He said: what do you need right now."

    flame "two years ago you were not the person who would have said this in his kitchen. you are now."

    menu:
        "say: I don't know yet":
            e "You said you did not know yet."
            $ rr_delta("self_trust", +4)
        "say: to not be alone for the next hour":
            e "You said: to not be alone for the next hour."
            # Per-NPC connection delta — ben is a named NPC in the
            # witnessed-ending scene; see characters.rpy. The safe=True
            # path applies the gentler social_battery cost.
            $ rr_npc_delta("ben", +6, safe=True)
        "say nothing for a long minute":
            e "You said nothing for a long minute. He let the minute hold."
            $ rr_delta("presence", +4)

    pause 1.0

    e "He put the kettle on. The kettle was already on. He put it on again because he had forgotten."

    e "You laughed. It was a real laugh. The first real laugh was small, not bigger than the room allowed."

    pause 1.0

    e "The relationship did not repair fully. He did not become a person who had always been a person you could say this to. You did not become a person for whom saying this is something you have always been able to do."

    e "He became a person who once, in a specific kitchen, on a specific Saturday, sat with you while you named a thing."

    e "You became a person who, once, named it."

    flame "being met partially is being met. the partially is the honest part."

    jump credits_text


## -----------------------------------------------------------------
## credits_text — identical across all endings.
## Explicitly refuses a moral (PRD §4.9).
## -----------------------------------------------------------------

label credits_text:
    scene black
    with fade
    pause 1.0

    centered "{b}Shoes{/b}\n\nThis was a fiction about being unable to do the sensible thing.\nIt was not a moral. It was not a prescription. It was not therapy.\n\nIf you recognized yourself, please seek qualified support."
    pause 5.0

    centered "— end —"
    pause 3.0

    return
