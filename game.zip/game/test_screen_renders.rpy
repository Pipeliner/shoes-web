## game/test_screen_renders.rpy — render-coverage testcases.
##
## Authored 0.1.18-40 in response to the 2026-04-30 web-build
## investigation. Phase A confirmed gui.init was missing and viewport
## was painting empty on web. These testcases regress-protect the
## structural rendering of every player-facing custom screen on
## desktop (under xvfb in CI). The corresponding web-rendering check
## is the Playwright playtest harness, which inspects the canvas
## directly.
##
## What these tests verify (and what they don't):
##
## - `if screen "<name>"` — the screen is currently on the layer.
##   Cheap, robust, catches "screen failed to load / call_screen
##   raised mid-init / wrong screen got pushed."
## - `click "<button_label>"` — a focusable element with that label
##   is on screen and accepting input. Catches "button clipped
##   offscreen by bad ypos / button rendering failed."
## - `advance until "<button_label>"` — same. Used when we want to
##   wait for an upstream transition to settle.
##
## What they CANNOT verify:
##
## - The visual content of plain `text "..."` widgets (the framework's
##   text selector matches only focusable elements per
##   renpy-sdk/doc/testcases.html § Text Selector). Body-text rendering
##   on web is the Playwright harness's job.
##
## File is excluded from distributions in game/options.rpy.

testsuite screen_renders:
    before testcase:
        $ _test.transition_timeout = 0.05
        $ _test.timeout = 20.0
        $ persistent.content_notice_acknowledged = False

    teardown:
        exit


testcase main_menu_start_button_works:
    ## Custom main_menu (game/screens/main_menu.rpy) renders Start /
    ## Load / Preferences / Quit. Clicking Start invokes Start() and
    ## advances to content_notice_screen. If main_menu doesn't
    ## render, or Start is clipped offscreen, click times out.
    click "Start"
    advance until screen "content_notice_screen"


testcase content_notice_buttons_clickable:
    ## Both choice-button labels in content_notice must be on screen
    ## and clickable. The 2026-04-30 web regression had the body of
    ## the screen empty but buttons present — these tests don't
    ## catch that, but they DO catch a regression where buttons get
    ## clipped or fail to render. Body-text rendering is the
    ## Playwright harness's job.
    click "Start"
    advance until "I'm ready to begin."
    advance until "Not right now. Take me back to the title screen."
    click "I'm ready to begin."
    advance until not screen "content_notice_screen"


testcase branch_select_shows_all_four_options:
    ## branch_select has 4 menu items: CEN, MI, NIM, "What are these
    ## branches?". The 2026-04-30 regression had the bottom 2 of 4
    ## offscreen because `style choice_vbox: ypos 690 yanchor 1.0`
    ## was authored under a 720px assumption but the project ran at
    ## the 800×600 default. After gui.init(1280, 720) and
    ## `ypos 1.0 yoffset -gui.scale(20)` (relative-to-bottom), all
    ## four must be visible. advance-until matches focusable
    ## elements — any choice item not rendered = timeout.
    click "Start"
    advance until "I'm ready to begin."
    click "I'm ready to begin."
    advance until "CEN — childhood emotional neglect. The main path; the complete game."
    advance until "MI — a parent with a recurring mental-illness pattern. Act I complete; Act II playable through the exile approach."
    advance until "NIM — a narcissistic or immature parent. Act I complete; Act II Ch 1 playable."
    advance until "What are these branches?"


testcase grounding_screen_renders_and_dismisses:
    ## G opens the safety-surface grounding screen from any scene.
    ## Per clarity.md rule 7 the screen must never clip critical
    ## text — including the "back to the scene" exit. Verifies both
    ## exit textbuttons render and that clicking dismisses cleanly.
    click "Start"
    advance until "I'm ready to begin."
    click "I'm ready to begin."

    advance until "CEN — childhood emotional neglect. The main path; the complete game."
    click "CEN — childhood emotional neglect. The main path; the complete game."

    keysym "grounding"
    advance until screen "grounding"
    advance until "Close the game"
    advance until "back to the scene"
    click "back to the scene"
    advance until not screen "grounding"


testcase negotiate_screen_renders_and_dismisses:
    ## screen negotiate (game/parts.rpy) is the parts-interaction
    ## surface. Fires when the player picks a part-aware intervention.
    ## On the kitchen path of CEN Ch 1, the caretaker negotiation is
    ## reached after the first kitchen choice. Verifies all 5 verb
    ## buttons (listen, ask, disagree, defer, override) plus the
    ## "How do you respond?" prompt are reachable; the click on
    ## "ask what it is trying to do for you" advances out of the
    ## screen into the chapter-end reflection flow.
    click "Start"
    advance until "I'm ready to begin."
    click "I'm ready to begin."
    advance until "CEN — childhood emotional neglect. The main path; the complete game."
    click "CEN — childhood emotional neglect. The main path; the complete game."

    ## Chapter-one notice + continue menu (a1c1_start label).
    advance until "continue"
    click "continue"

    advance until "get up, go to the kitchen, stand with Lena"
    click "get up, go to the kitchen, stand with Lena"

    ## Now in the negotiate screen. All 5 verbs should be reachable.
    advance until screen "negotiate"
    advance until "listen"
    advance until "ask what it is trying to do for you"
    advance until "disagree gently"
    advance until "defer — agree to wait"
    click "ask what it is trying to do for you"
    advance until not screen "negotiate"


testcase reflection_feeling_wheel_renders:
    ## screen reflection_feeling_wheel (game/screens/reflection.rpy)
    ## fires at chapter end as the journal feeling-wheel. After H1
    ## the choice labels are `_("{i}tired{/i}")` etc. — the test
    ## framework's text selector matches the rendered text content
    ## stripping {i}/{/i} markup, so the bare-text match still works.
    ## Verifies all 5 emotion buttons + the skip option render.
    click "Start"
    advance until "I'm ready to begin."
    click "I'm ready to begin."
    advance until "CEN — childhood emotional neglect. The main path; the complete game."
    click "CEN — childhood emotional neglect. The main path; the complete game."
    ## Chapter-one notice + continue menu (a1c1_start label).
    advance until "continue"
    click "continue"
    advance until "get up, go to the kitchen, stand with Lena"
    click "get up, go to the kitchen, stand with Lena"
    advance until "ask what it is trying to do for you"
    click "ask what it is trying to do for you"

    ## Reflection feeling-wheel screen.
    advance until screen "reflection_feeling_wheel"
    advance until "tired"
    advance until "careful"
    advance until "numb"
    advance until "alert"
    advance until "small"
    advance until "skip — nothing to write today"
    click "skip — nothing to write today"
    advance until not screen "reflection_feeling_wheel"


testcase reflection_part_picker_renders:
    ## screen reflection_part_picker (game/screens/reflection.rpy)
    ## follows the feeling-wheel. Four part-identity buttons + a skip.
    ## Same H1 wrapping caveat as reflection_feeling_wheel.
    click "Start"
    advance until "I'm ready to begin."
    click "I'm ready to begin."
    advance until "CEN — childhood emotional neglect. The main path; the complete game."
    click "CEN — childhood emotional neglect. The main path; the complete game."
    ## Chapter-one notice + continue menu (a1c1_start label).
    advance until "continue"
    click "continue"
    advance until "get up, go to the kitchen, stand with Lena"
    click "get up, go to the kitchen, stand with Lena"
    advance until "ask what it is trying to do for you"
    click "ask what it is trying to do for you"
    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    ## Reflection part-picker screen.
    advance until screen "reflection_part_picker"
    advance until "the part that takes care of others first"
    advance until "the part that goes numb and scrolls"
    advance until "the voice that says"
    advance until "something smaller"
    advance until "skip — nothing to name today"
    click "skip — nothing to name today"
    advance until not screen "reflection_part_picker"
