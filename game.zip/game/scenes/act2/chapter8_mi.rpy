## scenes/act2/chapter8_mi.rpy — Sunday accounting (MI variant).
##
## Mirrors the structural arc of `game/scenes/act2/chapter8.rpy`
## (CEN Sunday-accounting interior-work scene with a Caretaker
## re-ASK negotiation beat per amendment A2). Same five-beat
## shape: chapter notice + skip; opening on the kitchen table;
## three-option menu (ask the Caretaker / notice the cold /
## skip the noticing); after-negotiate close; skipped path.
##
## Branch differences vs. CEN:
##   - The Caretaker's calibration target is Mother's *stretch*,
##     not Wednesday-call-anticipation. The MI Caretaker is the
##     house-listener (a1c1_mi.rpy:64, a1c2_mi.rpy:47, :86) —
##     monitoring for stretch-signs. Its Sunday-evening
##     anxiety is about whether next week is a *bad-stretch
##     week* and what that requires.
##   - The Critic-half-right line (skip-noticing path) carries
##     the MI Critic's flat-tense register established at
##     a2c1_mi.rpy:157 ("you always archive"); the same
##     cadence is reused here as "you should have looked at
##     the cold."
##   - The cold-feet beat itself, the kettle, the dishwasher,
##     the laundry, the calendar — all branch-neutral. The
##     Sunday-evening interior is the same room across all
##     three Mothers.
##
## Why here in the arc:
##   - MI Ch 3 was the therapist; Ch 4 was the journal. None
##     of those is the protagonist alone with the Caretaker on
##     a Sunday with nothing to do. Per parity audit P-1 + P-4,
##     this chapter lets a late-Act-II MI player nudge
##     `permission` toward the exile gate and provides the
##     Caretaker re-ASK that A2 names as the canonical
##     permission-accumulation move.
##   - Primes Act III's `cancel_the_call` (Sunday → the
##     Wednesday call).
##
## Craft discipline:
##   - No new NPCs. No new flashbacks. (A8.3 contract.)
##   - Body sensations specific, not generic.
##   - The Caretaker's MI register: monitoring, scheduling,
##     pre-soaking. Match a1c1_mi / a1c2_mi voice.
##   - "the cold" is family-lexicon; gloss before the first
##     weighted use per clarity.md rule 1. Same gloss as CEN.
##   - Length budget: ~150 lines.
##
## State contract (matches the a2c8_mi_* beats in
## tests/e2e/beats.py):
##   Caretaker re-ASK path: +permission, +self_trust,
##     -critic_volume; part trust_in_self up; part intensity
##     down; consented_for_exile becomes True (A2: ASK on a
##     Manager sets consent).
##   Body-cold path: +interoception, small +presence, no
##     critic spike.
##   Skip-the-noticing path: +critic_volume, -self_trust, no
##     permission.
##
## Recognition: at most one PART_REGISTER_IDENTIFIED on the
## ASK path; one REFLECTION_COMPLETED at chapter close via
## the feeling wheel. Per A8.3, no SAT_WITH_EXILE here — that
## is reserved for the exile-approach scene (a2c2_mi).

label a2c8_mi_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c8_mi", False):
        centered "Chapter Eleven — Act II (continued, MI branch)\n\nA quiet Sunday-evening interior scene. No sensitive content beyond a small body-cold beat and a negotiation with a part of you."
        $ chapter_notice_shown["a2c8_mi"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c8_mi_skipped

    scene black
    with dissolve

    e "Sunday. The kind of Sunday that happens after a Saturday that went well."

    e "The flat is quiet. The dishwasher is on its second cycle of the weekend. The laundry on the chair is folded; the laundry in the basket is not, but it is the basket-laundry's turn next weekend, and you have made peace with that."

    e "You sit at the kitchen table. The week ahead is on the laptop, in calendar form. Tuesday has a deadline. Wednesday has the call with your mother that you have not yet decided to make or to not make."

    ## A small competency beat. The inbox is zero. The Caretaker is
    ## satisfied, in its way. The body is not.
    e "You answered the last unread email twenty minutes ago. The inbox is at zero. You closed the laptop and then opened it again, because the closing did not produce the thing the closing was supposed to produce."

    ## MI Caretaker register: house-listener / stretch-watcher.
    ## Per a1c2_mi.rpy:86, the MI Caretaker tracks Mother's
    ## stretch via meal-planning indicators (soup vs. barley vs.
    ## pre-soaking). Sunday-evening Caretaker monitors whether
    ## the coming week reads as bad-stretch or not.
    caretaker_voice "We are ahead. We are, for the first time this month, ahead. We have not heard from your aunt this week. We are not in a bad stretch."

    e "The Caretaker is not lying. You are ahead. The week is set. Tuesday is doable. The grocery list is on the fridge. There has not been an aunt-email."

    pause 1.0

    ## In-character gloss for "the cold" before its weighted use,
    ## per clarity.md rule 1. Branch-neutral — Sunday-evening
    ## body-temperature signal works the same across all three
    ## branches; the cold is in the body, not in the branch.
    e "There is a thing your feet do, on Sunday evenings, that you have, at various points in your life, called several different things. The body version of it is: cold. The feeling version of it is: a kind of small dread that has nothing in particular to be about."

    e "The cold is here. The cold has been here, low and even, since about three in the afternoon."

    menu:
        "ask the Caretaker what the rush is for":
            jump a2c8_mi_ask_caretaker
        "notice the cold; just notice":
            jump a2c8_mi_notice_cold
        "open the laptop again; there is always one more thing":
            jump a2c8_mi_skip_noticing


label a2c8_mi_ask_caretaker:
    scene black

    e "You sit with the Caretaker for a moment. You ask the question you have been learning to ask."

    ## The full negotiation screen. Caretaker is a Manager, so an
    ## ASK here sets `consented_for_exile = True` (per
    ## parts.py::_ask) and raises permission +5 pre-amplification.
    ## Same canonical Sunday-evening interior-work move as CEN.
    caretaker_voice "We are ahead. We should be making sure we stay ahead. We should be checking the aunt's email cadence. The cadence is the only signal we get."

    $ intervention = renpy.call_screen(
        "negotiate",
        part_name="caretaker",
        opening_line="We should be checking the aunt's email cadence. The cadence is the only signal we get.",
    )
    if intervention is None:
        $ intervention = ("ask", "caretaker")
    $ response_key = pp_intervene(intervention[0], intervention[1])

    if response_key == "caretaker_asked_intent":
        ## MI Caretaker's deepest stated intent: monitoring for
        ## stretch onset. The MI Caretaker has been doing this
        ## since before the protagonist had words for it.
        caretaker_voice "I am trying to make sure I see it coming. I am trying to make sure no one calls and tells you about it because we missed the third step on the stairs."
        e "The Caretaker says it the way the Caretaker says these things — without self-pity, the way a person who has held a schedule together for years describes a schedule."
        e "You notice that the sentence is older than this Sunday. The sentence is older than your job. The sentence is older than Sam."
        $ reco_credit("part_register_identified", "a2c8_mi_caretaker_register")
    elif response_key == "caretaker_listened_to":
        caretaker_voice "Yeah. Yeah."
        e "The Caretaker shifts weight, in the way a part of you shifts weight when it has not been asked to leave but has been asked to sit down."
    elif response_key == "caretaker_deferred_to":
        caretaker_voice "Good. The cadence matters."
        e "You let the Caretaker keep the wheel. The cadence will, in fact, matter; the Caretaker is not wrong about that."
    elif response_key == "caretaker_disagreed_with":
        caretaker_voice "Fine. We will see."
        e "The Caretaker is sceptical, in the way of a part of you that has been right before."
    elif response_key == "caretaker_overridden":
        caretaker_voice "…"
        e "You closed the calendar over the Caretaker's small objection. The Caretaker has its arms crossed now. It will be back."
    else:
        caretaker_voice "Hm."

    jump a2c8_mi_after_negotiate


label a2c8_mi_notice_cold:
    scene black

    e "You do not move. You let your attention go to your feet, which are, indeed, cold."

    e "The cold is in the soles, mostly. The arches are warmer than the soles, which is information you did not expect to have."

    e "Your hands are the temperature of your hands. Your face is the temperature of your face. The cold is foot-shaped tonight."

    $ rr_delta("interoception", +6)
    $ rr_delta("presence", +4)
    $ rr_delta("regulation", +3)

    pause 1.0

    e "You do not name what the cold is for. You note that it is here."

    flame "noticing where the cold is, on a sunday, is not nothing. it is a specific noticing."

    jump a2c8_mi_after_negotiate


label a2c8_mi_skip_noticing:
    scene black

    e "You open the laptop. You re-open the calendar. You add a note to Tuesday that does not need to be added."

    e "The cold goes on being cold under the table. You go on not-noticing it. The not-noticing takes a small, ongoing amount of attention you do not register as attention."

    $ rr_delta("critic_volume", +5)
    $ rr_delta("self_trust", -3)
    $ rr_delta("energy", -3)

    ## MI Critic register: flat-tense absolutism. Reuses the
    ## "always" cadence established at a2c1_mi.rpy:157 ("you
    ## always archive") — same one-word verb, same flat-affect
    ## judgment.
    critic_voice "You should have looked at the cold. You always do this."

    e "The Critic is half-right. The Critic is also doing what the Critic does, which is arrive late to a moment you could have had with less of it."

    jump a2c8_mi_after_negotiate


label a2c8_mi_after_negotiate:
    scene black
    with fade

    ## Whichever path was taken, the chapter closes the same way:
    ## the week is still queued; the body is still the body;
    ## nothing "resolves." The protagonist has had a small
    ## Sunday. That is the whole shape.
    e "You stand up. You put the kettle on. The kettle takes the time the kettle always takes."

    e "Wednesday is still on the calendar. Tuesday is still on the calendar. The cold is still in your feet, or it isn't, depending on what you did."

    e "It is the kind of evening you used to walk through without registering, on the way to a Monday that would also not register."

    flame "sundays are the days the noticing is hardest, because nothing in particular is asking for it. you noticed something, or you didn't. either way, the noticing is the thing."

    ## Chapter-end reflection. Recognition source.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c8_mi_feeling")

    menu:
        "continue to Act III":
            jump act3_dispatcher
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c8_mi_skipped:
    scene black
    centered "Chapter Eleven (MI variant) was skipped."
    pause 1.5
    e "It was a Sunday. You did or did not notice the cold in your feet. The week stayed queued either way."
    ## Modest equivalent gain so a skipper does not arrive at
    ## Act III in an inconsistent state. Mirrors a2c8.rpy
    ## skipped path.
    $ rr_delta("regulation", +3)
    $ rr_delta("interoception", +2)

    menu:
        "continue to Act III":
            jump act3_dispatcher
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
