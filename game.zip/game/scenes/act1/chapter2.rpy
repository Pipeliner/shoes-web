## scenes/act1/chapter2.rpy — the phone call.
##
## Content notice at chapter start (PRD §4.10). Skippable at the scene
## level. Demonstrates:
##   - Trigger-scene pattern (stressor raises flashback_pressure)
##   - Emotional flashback without visual cliché (verb-tense torque,
##     sensory pivot, intrusive partial). See PRD §7.1.
##   - Inner Critic register after the call.
##
## This is a scene stub — minimal branching. Full branching lands in
## Act 2 work.

label a1c2_start:
    scene black
    show screen tooltip_overlay

    ## Per-chapter content notice.
    if not chapter_notice_shown.get("a1c2", False):
        centered "Chapter Two\n\nThis chapter contains a phone call from a parent, after which the narration briefly slips into childhood.\n\nYou can skip the chapter at any point."
        $ chapter_notice_shown["a1c2"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a1c2_skipped

    scene black
    with dissolve

    e "The phone's ring tone is the old one. The one you never changed."

    e "It is Mother."

    ## The player can still stop here.
    menu:
        "answer":
            jump a1c2_answer
        "don't answer — send to voicemail":
            jump a1c2_voicemail
        "skip the whole scene":
            jump a1c2_skipped


label a1c2_answer:
    mother "Allo. I was starting to think you had gone out of signal again."

    $ rr_delta("flashback_pressure", +12)
    $ rr_delta("regulation", -6)

    e "You say hello. You ask how she is."

    mother "I am tired. I don't know why I am always so tired. You know, yesterday the pharmacy said — well. That is not why I called."

    e "You say mm-hm. You say it at the point in a sentence where a mm-hm goes."

    e "She has been {i}I am tired{/i} for longer than you have a memory of her not being. The sentence is older than you are."

    ## Emotional flashback, written per PRD §7.1: no cliché, verb-tense
    ## torque (past intrudes into present), sensory pivot (the weight
    ## of the phone against the ear), intrusive partial.
    ## Flashback uses verb_tense_torque.hallway_telephone_table_eight
    e "The phone is warm against your ear. It has always been warm. You are holding the phone in the kitchen in the apartment that had the kitchen with the yellow wallpaper."

    e "There is a stool you are sitting on. You do not remember pulling it over."

    e "You are thirteen and she is telling you about her back again."

    e "You are older. You are holding a phone. The wallpaper is white."

    $ rr_delta("presence", -8)
    $ rr_delta("critic_volume", +6)

    mother "Are you listening?"

    e "You say yes. You say it at the pitch of obedience."

    $ rr_delta("self_trust", -4)

    menu:
        "let her finish; say the things she wants you to say":
            caretaker_voice "Yes. Yes, let her finish. You can process it later. You always can."
            $ rr_delta("social_battery", -8)
            $ rr_delta("flashback_pressure", +4)
            jump a1c2_after_call

        "tell her you have to go":
            ## Availability check: guarded by self_trust.
            e "The sentence is already leaving your mouth, or maybe not. You do not know, for a second, whether you said it."
            if rr_get("self_trust") >= 30:
                e "You say you have to go. She sighs. You end the call."
                $ rr_delta("self_trust", +3)
                $ rr_delta("presence", +4)
            else:
                e "You open your mouth and hear yourself say 'go on, mom.' You did not mean to."
                critic_voice "You never say it. You never will."
                $ rr_delta("critic_volume", +8)
            jump a1c2_after_call

        "just listen to the silence between her words":
            e "You listen to the silence between her words. It is not really silence. It is breath."
            $ rr_delta("presence", +3)
            $ rr_delta("interoception", +4)
            jump a1c2_after_call


label a1c2_voicemail:
    e "You thumb the button to mute the ring. You put the phone face-down."
    $ rr_delta("self_trust", +4)
    $ rr_delta("critic_volume", +6)
    critic_voice "You never answer. You never answer for her."
    e "The Critic is right in the technical sense. The Critic is also not the authority you think it is."
    ## Small Recognition for noticing the Critic's register.
    $ reco_credit("part_register_identified", "a1c2_critic_identified")
    jump a1c2_after_call


label a1c2_after_call:
    scene black
    with fade
    e "After. The phone face-down. The apartment is the apartment. Not the kitchen with the yellow wallpaper."

    ## Flashback uses non_flashback.what_she_said_after
    e "You try to remember what she said after you put the phone down."
    e "You know she said something. You know you answered. You know the answer was a sentence with three words in it, maybe four."
    e "The three words are not available to you."

    ## Non-feeling-for-Mother interior aside, CEN-only. The corpus's
    ## 3,809-score live wound is the absence of feeling itself. Per
    ## CEN reader-persona §6 finding: a single line of post-call
    ## interior that names the absence as itself a noticing — the
    ## chapter honours the chronicity of Mother elsewhere; this line
    ## meets the reader for whom the not-feeling is the wound.
    ## Show-not-name discipline preserved (no "I'm fine" lexical
    ## handle in protagonist's interior; the noticing is the
    ## register).
    e "You notice you did not feel anything during the call. The not-feeling is the noticing this time."

    e "Your feet are cold."

    ## Audit P-11 closure (0.1.18-46): NAMED_FLASHBACK source. The
    ## kitchen-with-yellow-wallpaper at thirteen during the call was
    ## a flashback. A small noticing menu — naming it earns 3 points;
    ## letting it pass is a valid choice (not every flashback needs
    ## to be named). Per the design intent: noticing is ambivalent,
    ## not maximizing. Same shape lands on a1c2_mi (hallway) and
    ## a1c2_nim (pale-blue dress).
    menu:
        "name what just happened":
            e "You name it. You say to yourself: that was a flashback. The kitchen at thirteen, in the yellow wallpaper, in the apartment that was that apartment. You are at this apartment now. You are not in the kitchen at thirteen."
            $ rr_delta("self_trust", +3)
            $ rr_delta("presence", +2)
            $ reco_credit("named_flashback", "a1c2_kitchen_flashback")
        "let it pass":
            e "You let it pass. The kitchen has been the kitchen at thirteen many times before; it will be again. You do not have to name it every time."
            $ rr_delta("regulation", +2)

    ## Chapter-end reflection — Recognition source.
    $ renpy.call_screen("reflection_feeling_wheel", event_id="a1c2_feeling")

    menu:
        "continue to Chapter Three":
            jump a1c3_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a1c2_skipped:
    scene black
    centered "Chapter Two was skipped."
    pause 1.5
    e "The phone rang. You did what you did. The day continued."
    e "What comes next does not punish the skip. Some later moments have wanted you to have sat with this one; they will say so, gently, when they are reached."

    menu:
        "continue to Chapter Three":
            jump a1c3_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
