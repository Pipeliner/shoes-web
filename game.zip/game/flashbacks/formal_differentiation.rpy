# GEN-CHECKSUM: c3e1fe18edb42fef
## Flashback snippets — technique: formal_differentiation
## The child-scene uses a different Character voice + different pacing.
##
## Generated from formal_differentiation.yaml. Hand-edit below the
## GEN-CHECKSUM line preserved by --force only.
##
## This file is a reference catalog, not live scene code.
## Scene authors grep for snippet IDs, then hand-adapt
## the prose into the target scene's voice. Do not
## import this file or reference its contents at runtime.

## --- snippet: exile_voice_in_act2_ch2 ---
## layers:
##   present: {'character': 'e', 'style': 'prose paragraphs, center-framed'}
##   past: {'character': 'exile_voice', 'style': 'one-sentence lines, italic, size 22'}
## example:
##   present_line: 'You step through.'
##   past_line: 'the kitchen floor has squares. the squares have lines. i am sitting on a square.'
##   pause_seconds: 1.5
##   past_line: 'the squares are cold.'
##   pause_seconds: 1.5
##   present_line: 'You are in the kitchen. You are thirty-four.'

## --- snippet: instructor_voice_as_differentiator ---
## layers:
##   present_ordinary: {'character': 'e', 'style': 'default prose'}
##   present_somatic: {'character': 'instructor', 'style': 'short imperative, permissive'}
## authoring_note:
##   'Reserved for somatic-practice scenes; not a general flashback tool.'

