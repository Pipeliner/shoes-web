## scenes/act2/chapter1.rpy — the email.
##
## Herman's Stage 2 (remembrance and mourning) opens here. The stressor
## from Act 1 Ch 3 is still there. The protagonist either opens the
## email or does not.
##
## This chapter demonstrates:
##   - Firefighter Turn: when numb-out hits FIREFIGHTER_SEIZE_THRESHOLD
##     the player's next choice is replaced with a part-authored action.
##   - Amplified reactive-pair dynamics at Stretched/Depleted band.
##   - Flashback via parallel-action cut (Godfather II). Two scenes
##     alternate without transition — the present scene (email, room)
##     and the past scene (a moment of childhood). No screen effect.

label a2c1_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c1", False):
        centered "Chapter Four — Act II begins\n\nThis chapter contains a brief childhood flashback written as a parallel-action cut between now and then.\n\nNothing graphic. You can skip the chapter."
        $ chapter_notice_shown["a2c1"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c1_skipped

    scene black
    with dissolve

    e "The email has been unopened for a day and a part of a day."

    e "Your aunt's name in your inbox is a particular kind of silence."

    e "Your aunt has been sending these for as long as you have had an inbox to receive them. Before that, on paper. She is the person in the family who, when nobody is going to say the obvious thing, sends a sentence that at least notes it."

    ## Pre-raise firefighter intensity to demonstrate Firefighter Turn.
    ## In the full game this is the accumulated pressure from Act 1 Ch 3.
    python:
        from logic.parts import Part, PartKind
        _numb = parts_state.get("numb-out")
        parts_state = parts_state.with_part(Part(
            name=_numb.name, kind=_numb.kind, introduced=True,
            trust_in_self=_numb.trust_in_self,
            consented_for_exile=_numb.consented_for_exile,
            intensity=70,  # approaching seize threshold (75)
        ))

    menu:
        "open the email":
            jump a2c1_open
        "mark it read and archive it without opening":
            jump a2c1_archive
        "delete it":
            jump a2c1_delete


label a2c1_open:
    scene black
    e "You click. The subject line is 'Your mother.'"
    e "The body is short."
    e "She writes that your mother has been calling everyone in the family except you. She writes that your mother has not said why. She writes that she thought you should know."

    e "She closes the way she always closes — {i}she thought you should know{/i} — and the way she always closes is also the way she always declines to advise."

    $ rr_delta("flashback_pressure", +18)
    $ rr_delta("threat_scan", +12)
    $ rr_delta("regulation", -10)
    $ rr_delta("energy", -6)

    ## Parallel-action cut. Past intrudes mid-paragraph. Intrusive partial.
    ## CEN childhood signature is the yellow-wallpaper kitchen at 13
    ## (see docs/continuity.md). Earlier draft erroneously imported
    ## the MI-coded hallway-with-telephone-table at 8; corrected
    ## 0.1.18-15 per the continuity audit.
    ##
    ## Flashback uses parallel_action_cut.email_and_hallway
    ## (the structural pattern: present-room weave with childhood-
    ## room intrusion at email-open. The library's snippet still
    ## documents the MI hallway as the past-thread example; the
    ## structural cuts apply to either the hallway or this CEN
    ## yellow-wallpaper kitchen variant. YAML past-thread content
    ## update tracked.)
    ## Flashback uses sensory_pivot.wallpaper_yellow
    ## (the wallpaper-as-anchor sensory pivot — *"There is a
    ## kitchen with yellow wallpaper. You are thirteen."* lands
    ## the wallpaper-pattern-in-a-periphery anchor described in
    ## the YAML.)
    e "There is a kitchen with yellow wallpaper. You are thirteen."

    e "You sit down where you are."

    e "The chair holds. The kitchen has linoleum. The room has a laptop."

    e "You are thirteen and you are thirty-four."

    e "You are holding the email open with your thumb."

    ## Bump firefighter to seize threshold.
    python:
        _numb = parts_state.get("numb-out")
        parts_state = parts_state.with_part(Part(
            name=_numb.name, kind=_numb.kind, introduced=True,
            trust_in_self=_numb.trust_in_self,
            consented_for_exile=_numb.consented_for_exile,
            intensity=85,  # above SEIZE_THRESHOLD 75
        ))

    ## Firefighter Turn. PRD §4.6 — a "Firefighter Turn" replaces the
    ## next player choice with a part-authored action.
    if pp_firefighter_seizing():
        firefighter_voice "Close the laptop."
        e "You close the laptop."
        e "You did not decide that."
        e "The part of you that takes you out of rooms you cannot stay in has taken you out of this room."
        $ rr_delta("presence", -10)
        $ rr_delta("flashback_pressure", -4)
        # A Firefighter Turn credits Recognition if the player would have
        # been about to name it (we don't — the scene is about the
        # involuntariness of it).
        jump a2c1_after_firefighter
    else:
        jump a2c1_after_open


label a2c1_after_firefighter:
    scene black
    e "It is later."

    e "You have done several things that are not the laptop. You have taken the trash down. You have sat on the sofa for a time you did not track. You have thought about dinner without making any of it."

    e "The email is still there. Unopened in your memory, because you were not, while reading it, in the room."

    firefighter_voice "You don't have to go back to it. Not today."

    ## Negotiation with the firefighter. This is where the Part system
    ## is the central mechanic.
    $ intervention = renpy.call_screen(
        "negotiate",
        part_name="numb-out",
        opening_line="You don't have to go back to it. Not today.",
    )
    if intervention is None:
        $ intervention = ("defer", "numb-out")
    $ response_key = pp_intervene(intervention[0], intervention[1])

    if response_key == "numb-out_asked_intent":
        firefighter_voice "I am trying to keep you from having to feel it. That is what I do. That is all I do."
        e "The Firefighter trusts you a little more today than yesterday."
    elif response_key == "numb-out_listened_to":
        firefighter_voice "Yeah. Yeah."
        e "It does not retreat. It shifts weight to its other foot."
    elif response_key == "numb-out_deferred_to":
        firefighter_voice "Good."
        e "The laptop stays closed. Tomorrow is another decision."
    elif response_key == "numb-out_overridden":
        firefighter_voice "…"
        e "You opened the laptop anyway. The Firefighter has its back turned now."
    else:
        firefighter_voice "Fine. Fine."

    jump a2c1_reflection


label a2c1_after_open:
    # This path runs when firefighter didn't seize — player retains the
    # choice. For the MVP we fold both paths into the same reflection.
    scene black
    e "You stay with the email a while."
    e "You do not reply yet. You do not have to reply yet."
    jump a2c1_reflection


label a2c1_archive:
    scene black
    e "You archive the email without opening it."
    $ rr_delta("critic_volume", +12)
    $ rr_delta("self_trust", -8)
    critic_voice "You always do this. You archive the thing. You archive and you forget and you tell yourself you did not forget."
    e "You do not know, in that moment, whether the Critic is right or wrong. You know only that it is loud."
    jump a2c1_reflection


label a2c1_delete:
    scene black
    e "You delete the email."
    e "Deleted emails are not really deleted. You know this. A part of you knows this too."

    $ rr_delta("critic_volume", +8)
    $ rr_delta("flashback_pressure", +10)

    e "It is, for a few hours, as if the email was never sent."
    e "Your aunt knows it was. Your mother, who will know without being told, knows it was."
    e "A part of you knows it was."

    jump a2c1_reflection


label a2c1_reflection:
    scene black
    with fade

    flame "this was the stressor. in a lot of writing about this, the stressor is a door. you pass through it or you do not. either way, you notice it."

    ## Feeling wheel for Act II entry.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c1_feeling")
    e "The next scene — the one with the child — is held closed for now. It will only open if, in the scenes between, both the part of you that takes care of others first and the part of you that takes you out of rooms have, separately, said yes."

    menu:
        "continue to Chapter Five":
            jump a2c2_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c1_skipped:
    scene black
    centered "Chapter Four was skipped."
    pause 1.5
    e "The email was there. Time passed. You read it later, or you did not."

    menu:
        "continue to Chapter Five":
            jump a2c2_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
