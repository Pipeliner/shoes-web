"""Computed states.

Per PRD §4.5 "Computed states": derived from primary resources (and per-NPC
Connection) and used for option gating and scene selection. Names are
descriptive, not diagnostic, in the UI.

Pure functions. No mutable state. Pickle-safe.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Optional

from game.logic.resources import Resource, ResourceSnapshot


class ComputedState(str, enum.Enum):
    ANXIOUS_EPISODE = "anxious_episode"
    DEPRESSIVE_EPISODE = "depressive_episode"
    DISSOCIATIVE_SPELL = "dissociative_spell"
    FLOODED = "flooded"
    GROUNDED = "grounded"
    FAWN_ACTIVE = "fawn_active"  # context-sensitive; carries NPC label


@dataclass(frozen=True)
class StateReading:
    """A computed-state evaluation. `npc` is populated only for FAWN_ACTIVE."""

    state: ComputedState
    active: bool
    npc: Optional[str] = None


# Thresholds — named constants rather than magic numbers so tuning is cheap.
HIGH = 70
LOW = 30
MODERATE_LOW = 40
MODERATE_HIGH = 60

# Flooded threshold from PRD: any two state-adjacent resources above 80
# simultaneously.
FLOODED_THRESHOLD = 80
STATE_ADJACENT_RESOURCES = (
    Resource.FLASHBACK_PRESSURE,
    Resource.PRESENCE,  # inverted — high is good; "above 80" for flooded means high presence doesn't count
    Resource.THREAT_SCAN,
)

# For grounded, we need high presence + moderate regulation + low threat_scan.
GROUNDED_PRESENCE_MIN = HIGH  # 70
GROUNDED_REGULATION_MIN = MODERATE_HIGH  # 60
GROUNDED_THREAT_SCAN_MAX = MODERATE_LOW  # 40


def anxious_episode(snap: ResourceSnapshot) -> bool:
    """High threat_scan + low regulation + low energy."""
    return (
        snap.get(Resource.THREAT_SCAN) >= HIGH
        and snap.get(Resource.REGULATION) < MODERATE_LOW
        and snap.get(Resource.ENERGY) < MODERATE_LOW
    )


def depressive_episode(snap: ResourceSnapshot) -> bool:
    """Low energy + low connection + high critic + low permission."""
    return (
        snap.get(Resource.ENERGY) < LOW
        and snap.get(Resource.CONNECTION) < LOW
        and snap.get(Resource.CRITIC_VOLUME) >= HIGH
        and snap.get(Resource.PERMISSION) < LOW
    )


def dissociative_spell(snap: ResourceSnapshot) -> bool:
    """Low presence + high flashback_pressure + low interoception."""
    return (
        snap.get(Resource.PRESENCE) < LOW
        and snap.get(Resource.FLASHBACK_PRESSURE) >= HIGH
        and snap.get(Resource.INTEROCEPTION) < LOW
    )


def flooded(snap: ResourceSnapshot) -> bool:
    """Any two state-adjacent resources above 80 simultaneously.

    PRESENCE is inverted (high = good) so it doesn't contribute to 'flooded'
    on being high. We count FLASHBACK_PRESSURE and THREAT_SCAN above 80, and
    low PRESENCE (i.e., high dissociation pressure: 100 - PRESENCE > 80,
    i.e., PRESENCE < 20).
    """
    hits = 0
    if snap.get(Resource.FLASHBACK_PRESSURE) > FLOODED_THRESHOLD:
        hits += 1
    if snap.get(Resource.THREAT_SCAN) > FLOODED_THRESHOLD:
        hits += 1
    if snap.get(Resource.PRESENCE) < (100 - FLOODED_THRESHOLD):  # < 20
        hits += 1
    return hits >= 2


def grounded(snap: ResourceSnapshot) -> bool:
    """PRESENCE > 70 AND REGULATION > 60 AND THREAT_SCAN < 40.

    Required for some exile-approach scenes (gate enforced in
    game/logic/gates.py and game/logic/parts.py).
    """
    return (
        snap.get(Resource.PRESENCE) > GROUNDED_PRESENCE_MIN
        and snap.get(Resource.REGULATION) > GROUNDED_REGULATION_MIN
        and snap.get(Resource.THREAT_SCAN) < GROUNDED_THREAT_SCAN_MAX
    )


def fawn_active_for(snap: ResourceSnapshot, npc: str) -> bool:
    """Triggers when connection to NPC is threatened and critic is high.

    Per PRD §4.5:
      "context-sensitive: triggers when `connection` to a specific NPC is
      threatened and `critic_volume` is high; behaviourally rendered as
      over-apology, anticipatory caretaking, voice-up on statement ends."

    We interpret "connection threatened" as: connection_with(npc) below
    MODERATE_LOW (40) AND critic_volume at or above HIGH (70).
    """
    return (
        snap.connection_with(npc) < MODERATE_LOW
        and snap.get(Resource.CRITIC_VOLUME) >= HIGH
    )


def fawn_active_npcs(snap: ResourceSnapshot) -> tuple[str, ...]:
    """Which NPCs have fawn_active right now. Empty tuple if none."""
    return tuple(
        npc for npc in snap.connection_per_npc if fawn_active_for(snap, npc)
    )


def all_active_states(
    snap: ResourceSnapshot, npcs: tuple[str, ...] = ()
) -> tuple[StateReading, ...]:
    """Return one StateReading per ComputedState (plus one per fawn-active NPC)."""
    readings = [
        StateReading(ComputedState.ANXIOUS_EPISODE, anxious_episode(snap)),
        StateReading(ComputedState.DEPRESSIVE_EPISODE, depressive_episode(snap)),
        StateReading(ComputedState.DISSOCIATIVE_SPELL, dissociative_spell(snap)),
        StateReading(ComputedState.FLOODED, flooded(snap)),
        StateReading(ComputedState.GROUNDED, grounded(snap)),
    ]
    # FAWN_ACTIVE per NPC. If the caller supplied an explicit list of NPCs
    # we check, otherwise we scan everyone the snapshot has a record of.
    scan = npcs or tuple(snap.connection_per_npc.keys())
    for npc in scan:
        readings.append(
            StateReading(
                ComputedState.FAWN_ACTIVE,
                fawn_active_for(snap, npc),
                npc=npc,
            )
        )
    return tuple(readings)


__all__ = [
    "ComputedState",
    "FLOODED_THRESHOLD",
    "GROUNDED_PRESENCE_MIN",
    "GROUNDED_REGULATION_MIN",
    "GROUNDED_THREAT_SCAN_MAX",
    "HIGH",
    "LOW",
    "MODERATE_HIGH",
    "MODERATE_LOW",
    "StateReading",
    "all_active_states",
    "anxious_episode",
    "depressive_episode",
    "dissociative_spell",
    "fawn_active_for",
    "fawn_active_npcs",
    "flooded",
    "grounded",
]
