## scenes/act2/chapter7_mi.rpy — Quiz Night with Ben (MI variant).
##
## Mirrors CEN `chapter7.rpy` structurally (one menu opener,
## round 1, break beat, optional stepped-outside, round 4
## close) but lands on an MI-specific texture: the
## stretch-watcher Caretaker keeps the phone in pocket-hand-
## reach. Quiz Night IS one of the protagonist's reliable
## contexts — Ben's pub Saturday, twenty years deep — but the
## stretch-watcher does not get the night off. It is, at some
## level, listening for a Tuesday-or-Wednesday-call-from-home
## that hasn't come. Ben's *"you're half-here tonight"*
## (forty times over twenty years) lands precisely on this
## pattern; he has been watching her hold the half-channel
## open since they were both fourteen.
##
## Branch differences vs. CEN/NIM:
##   - The opening register acknowledges the phone-in-pocket
##     listening — the half-channel for Mother that the
##     stretch-watcher keeps open even on Saturday night.
##   - Ben's "half-here" is decoded specifically: he knows the
##     phone-in-pocket pattern from twenty years of watching
##     it.
##   - The stepped-outside-with-Ben email beat names the
##     hospital fact (per docs/continuity.md:688-694). Ben's
##     response is calibrated to having seen the protagonist
##     receive variants of this email since age eight.
##   - The Marina hug close: Marina's short hug is the kind
##     of physical contact the stretch-watcher does NOT have
##     to scan, because Marina is not a channel back to
##     Mother — and the not-needing-to-scan is briefly
##     audible.
##
## Per chapter7 craft discipline:
##   - Ben is specific. A twenty-year friend.
##   - Group setting (pub trivia with the regulars).
##   - No Critic activation in the foreground. Social
##     battery drains.
##   - One gentle meta-choice near the end.
##
## State effects mirror chapter7.rpy line-for-line.

label a2c7_mi_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c7_mi", False):
        centered "Chapter Ten — Act II (continued, MI branch)\n\nA short social scene at a pub trivia night with long-term friend Ben. No sensitive content."
        $ chapter_notice_shown["a2c7_mi"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c7_mi_skipped

    scene black
    with dissolve

    e "Saturday night. The pub has the particular kind of noise a pub has on Saturday night with a quiz on. Ninety percent of the noise is strangers who think they know the answer to the decade a specific song came out."

    e "Ben is at your table. So is Ben's sister. So are two of Ben's coworkers whose names you have learned and re-learned a combined eight times."

    ## MI-specific opening: phone in pocket, the half-channel.
    e "Your phone is in the pocket of the jacket on the back of your chair. The pocket is on the side of the chair Ben is sitting on. You did not arrange the chair this way; you arranged the chair this way. The phone has been on silent since you walked in. The stretch-watcher has, even so, not stopped tracking which side of the room the chair is on."

    ben "You're late."

    e "You are not late. You are three minutes early. This is a thing he says. This is a thing you smile at the way you always smile at it."

    menu:
        "smile; say nothing":
            e "You smile. You say nothing. Ben grins, hands you a menu you don't need."
            $ rr_delta("social_battery", -2)
            jump a2c7_mi_round_1
        "say: you're eight minutes early":
            e "You say: \"You're eight minutes early.\" You checked, on the way in, because you wanted the specific number."
            ben "Eight is the number at which I am early, yes."
            $ rr_npc_delta("ben", +2, safe=True)
            jump a2c7_mi_round_1
        "say hi to the coworkers by name":
            e "You look at them. You say their names. You get one of them right. You apologise, quickly, in the way a twenty-year friend of Ben's can apologise."
            ben "Marina. Again."
            e "Marina laughs. Ben's sister. The laugh of a person who has been in eight variations of this moment, with Ben in seven of them."
            $ rr_npc_delta("ben", +3, safe=True)
            jump a2c7_mi_round_1


label a2c7_mi_round_1:
    scene black
    e "Round one is geography. Ben's sister is carrying this round. You contribute two answers, both correct, both about rivers."

    e "Marina orders a second round of drinks. You switch to soda water. You do not announce the switch. Nobody announces anything at this table; it is a feature."

    ## MI-specific: the stretch-watcher checks the phone.
    e "Sometime between the answer about the Niger and the answer about the Volga, your hand has been at your pocket. You did not decide this. The stretch-watcher checks. The phone has not lit up."

    $ rr_delta("social_battery", -3)
    $ rr_delta("presence", +2)
    $ rr_delta("regulation", +3)

    jump a2c7_mi_break


label a2c7_mi_break:
    scene black
    with fade

    e "Between rounds two and three, Ben leans over."

    ben "You're half-here tonight."

    ## MI-specific decode: Ben knows the half-channel
    ## pattern from twenty years.
    e "It is not a question. It is not unkind. It is a specific sentence he has said to you maybe forty times over twenty years, going back to a school hallway. He has watched the half-channel for almost as long as you have had it. The first time he said the sentence, you were both fourteen, and you had a pager in your pocket because Mother was in a stretch."

    pause 1.0

    menu:
        "say: yeah. sorry. long week.":
            e "You say it. He nods. He does not push. The next round starts."
            $ rr_delta("social_battery", -1)
            $ rr_delta("critic_volume", +2)
            jump a2c7_mi_round_4

        "say: yeah. there's a thing.":
            ben "A thing you want to talk about tonight, a thing you want to talk about later, or a thing you want to leave as a thing?"
            menu:
                "say: leave as a thing tonight.":
                    e "You say it. He says: copy. He means it. Ben has, over twenty years, learned to take 'copy' literally."
                    $ rr_npc_delta("ben", +3, safe=True)
                    $ rr_delta("self_trust", +4)
                    jump a2c7_mi_round_4
                "say: later.":
                    ben "Okay. I'm around this week."
                    $ rr_npc_delta("ben", +5, safe=True)
                    $ rr_delta("permission", +3)
                    $ rr_delta("self_trust", +4)
                    $ reco_credit("part_register_identified", "a2c7_mi_opening_accepted")
                    jump a2c7_mi_round_4
                "say: tonight. now.":
                    ben "Okay. Let's step outside for a minute."
                    e "You go outside. Round three starts without you. The phone in your pocket is still silent. The stretch-watcher is, briefly, not the loudest part of you."
                    $ rr_delta("presence", +4)
                    $ rr_delta("permission", +4)
                    $ rr_npc_delta("ben", +7, safe=True)
                    $ rr_delta("self_trust", +6)
                    $ reco_credit("reflection_completed", "a2c7_mi_stepped_outside")
                    jump a2c7_mi_stepped_outside

        "say: I'm fine. what's round three?":
            e "You say it the way you say it. He lets it go the way he lets it go."
            $ rr_delta("critic_volume", +4)
            $ rr_delta("self_trust", -2)
            jump a2c7_mi_round_4


label a2c7_mi_stepped_outside:
    scene black
    with fade

    e "The street outside the pub is cool enough that you are glad for the jacket you almost didn't bring. Ben leans against the brick. Ben has been leaning against the brick outside of pubs with you for half your life."

    ben "No pressure. What's the shape?"

    menu:
        "say: my aunt sent me an email. my mother had a fall.":
            ## MI-specific: the hospital email + Ben's
            ## already-knows-the-pattern response.
            e "You say it. The fall, the hospital, the stable. You tell him you archived it on Tuesday."
            ben "Mm. Hospital one."
            e "He says it the way you would name a known kind of weather. Ben has watched you receive variants of this email periodically since you were eight. He does not, in the way that other people might, ask if she's okay. He knows what *okay-as-far-as-okay-goes* looks like for Mother in a stretch."
            ben "Is it the kind of stretch where you call your aunt back, or the kind where you don't?"
            e "You say: don't, this time. He nods. Neither of you goes inside for another ten minutes."
            $ rr_npc_delta("ben", +8, safe=True)
            $ rr_delta("self_trust", +6)
            $ rr_delta("flashback_pressure", +4)
        "say: I don't know the shape yet. just — friction.":
            ben "Friction is a shape."
            e "You laugh, a little. He laughs. Friction-as-shape is a Ben-ism; he uses it when something hurts but doesn't have a name yet, and the hurt-without-a-name is itself a kind of name."
            $ rr_npc_delta("ben", +4, safe=True)
            $ rr_delta("regulation", +3)

    jump a2c7_mi_round_4


label a2c7_mi_round_4:
    scene black
    e "The quiz ends. Your team places fourth out of eleven, which is exactly where your team places every week. Ben's sister has been keeping track of the placings on her phone for three years."

    ## MI-specific: Marina's hug. The not-scanning of it.
    e "Marina hugs you goodbye. The hug is short; she is good at short hugs. The stretch-watcher does not, in the eight seconds of the hug, check anything. Marina is not a channel back to Mother and the part of you that scans for channels-back-to-Mother knows it."

    e "You appreciate Marina."

    $ rr_delta("social_battery", -3)

    jump a2c7_mi_close


label a2c7_mi_close:
    scene black
    with fade

    $ chapter_completed["a2c7_mi"] = True

    e "You walk home alone. The walk home is twenty minutes. You do not put the phone on during the walk."

    ## MI-specific close: the stretch-watcher will be back
    ## inside the apartment, but the walk is the walk.
    e "The phone stays in the pocket. The stretch-watcher will pick up its inventory when you get inside; the apartment is the listening-apartment in a way the pub on Saturday night isn't. But the walk is the walk."

    $ rr_delta("presence", +4)
    $ rr_delta("regulation", +3)

    flame "saturday nights at the pub are one of the places you come back to. noticing the coming-back is something."

    ## Chapter-end reflection.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c7_mi_feeling")

    menu:
        "continue to Chapter Eleven (MI)":
            jump a2c8_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c7_mi_skipped:
    scene black
    centered "Chapter Ten (MI variant) was skipped."
    pause 1.5
    e "There was a quiz night. You went. You saw Ben. You saw the regulars. The phone stayed silent in your pocket. It was the thing it always is."
    $ rr_delta("social_battery", -2)
    $ rr_npc_delta("ben", +1, safe=True)

    menu:
        "continue to Chapter Eleven (MI)":
            jump a2c8_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
