## scenes/act2/chapter3.rpy — the therapist.
##
## A trauma-informed session, written as a between-chapter scene. The
## therapist is an NPC (not a part of you), a person who does therapy,
## not a function that fixes you. The game itself is not therapy
## (PRD §3); this scene depicts therapy, which is different.
##
## Craft discipline:
##   - Session framing: the therapist asks more than she tells.
##   - No diagnosis names. No outcome promises. No "healing," "recovery."
##   - Short turns. Room to not answer.
##   - The therapist's register is formal-but-warm. Not folksy. Not
##     clinical-cold. Specific.
##   - The protagonist's register is allowed to drift into the exile
##     register for one paragraph at most, mid-session. Handled via
##     verb-tense torque, not flashback prose.
##
## State effects (match interior_work_therapist_session beat in
## tests/e2e/beats.py so the simulator and scene stay in sync):
##   +regulation, +permission, -critic_volume, +self_trust

label a2c3_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c3", False):
        centered "Chapter Six — Act II (continued)\n\nThis chapter contains a depicted therapy session. The game is not therapy; this scene is fiction. The therapist is trauma-informed."
        $ chapter_notice_shown["a2c3"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c3_skipped

    scene black
    with dissolve

    e "It is Wednesday. The room has a rug that is older than you are. The rug has a coffee-stain on it that you have not once asked about."

    e "The stain is older than you are. Your sessions in this room are long enough that you forget when you started. The rug has watched newer things than you in the chair."

    e "You sit in the chair you always sit in. Not the couch. The chair."

    therapist "We left off last time with the email from your aunt. Have you opened it?"

    menu:
        "say yes, and what you did after":
            jump a2c3_opened
        "say you opened it and you are trying not to think about it":
            jump a2c3_deflect
        "say nothing for a moment":
            jump a2c3_silence


label a2c3_opened:
    e "You say yes. You say you opened it, and then something inside you closed the laptop, and then hours of the day were not things you remember."

    therapist "The part of you that closed the laptop — was it trying to protect something?"

    menu:
        "say: I think it was":
            caretaker_voice "It was."
            ## Per docs/clarity-pass-2-act2-act3.md item 1: the
            ## "which part answered" phrasing was metaphysically
            ## ambiguous on first read (does the part literally
            ## speak aloud, or is "answered" a metaphor?). The
            ## explicit voice marker above (caretaker_voice)
            ## already grounds it; one added narrator line names
            ## the noticing-of-the-answering as its own beat.
            e "It was the Caretaker — you can feel which part of you turned to face the question. You say what you noticed."
            $ rr_delta("permission", +6)
            $ rr_delta("self_trust", +5)
            $ rr_delta("critic_volume", -4)
            therapist "That noticing is the work. Not the answer. The noticing."
            jump a2c3_midsession

        "say: I don't know":
            e "You say you don't know."
            therapist "That is also a real answer."
            $ rr_delta("self_trust", +2)
            jump a2c3_midsession


label a2c3_deflect:
    e "You say you are trying not to think about it."

    therapist "Mm."

    e "The therapist does not pursue. This is the thing she does. She leaves the silence unfilled."

    $ rr_delta("regulation", +2)

    menu:
        "let the silence hold":
            e "You let it. The silence is long and specific."
            $ rr_delta("presence", +4)
            $ rr_delta("interoception", +3)
            jump a2c3_midsession
        "break the silence, anything":
            e "You fill the silence with a story about nothing."
            $ rr_delta("critic_volume", +3)
            jump a2c3_midsession


label a2c3_silence:
    e "You say nothing for a moment. The therapist does not hurry."
    pause 1.0
    e "The moment is long enough that you notice what you are not saying."

    $ rr_delta("presence", +5)
    $ rr_delta("interoception", +4)
    $ rr_delta("regulation", +4)
    $ rr_delta("permission", +3)

    therapist "What's here, right now?"

    menu:
        "say: something small, in the chest":
            e "You say: something small, in the chest."
            therapist "Can it stay there for a moment, while we talk?"
            $ rr_delta("presence", +3)
            jump a2c3_midsession
        "say: I don't know":
            e "You say you don't know."
            therapist "Then we don't have to know. Yet."
            $ rr_delta("self_trust", +3)
            jump a2c3_midsession


label a2c3_midsession:
    ## The mid-session moment — a permitted exile-register paragraph,
    ## via verb-tense torque. No full flashback; no visual effect.
    scene black
    with fade

    therapist "You said last week that the apartment had yellow wallpaper. I want to come back to that, if it's ok."

    e "The apartment had yellow wallpaper."

    e "The wallpaper has a pattern that is not quite a pattern. You look at it when you are not looking at anyone. You look at it now."

    e "You are in the chair. In the office. The rug is older than you are."

    therapist "Where are you right now?"

    e "You say: in the chair."

    therapist "And also?"

    e "You say: sometimes in the kitchen."

    therapist "Both are true."

    ## This is the therapist's signature move: permitting both, not
    ## forcing a return. The state effect is the moment's full weight.
    $ rr_delta("permission", +8)
    $ rr_delta("regulation", +8)
    $ rr_delta("critic_volume", -6)
    $ rr_delta("self_trust", +4)
    $ rr_delta("presence", +4)

    jump a2c3_close


label a2c3_close:
    scene black
    with fade

    therapist "We're near the end of the hour. How do you want to leave?"

    menu:
        "with a small task to try this week":
            therapist "Okay. Something small. What feels small enough?"
            e "You say: noticing when the part that closes the laptop shows up."
            therapist "That's a good one. You don't have to do anything with it. Just notice."
            $ rr_delta("permission", +2)
            # Credits Recognition — a named-noticing task is itself a kind
            # of reflection-completed.
            $ reco_credit("reflection_completed", "a2c3_between_session_task")
            jump a2c3_out

        "with nothing; I don't want homework":
            therapist "Okay. We'll talk Wednesday."
            $ rr_delta("self_trust", +3)
            jump a2c3_out

        "with the silence from the middle":
            therapist "Let's leave it there."
            e "The silence sits down again between you."
            $ rr_delta("presence", +3)
            $ rr_delta("regulation", +3)
            jump a2c3_out


label a2c3_out:
    scene black
    $ chapter_completed["a2c3"] = True
    e "You put your shoes back on. You did not realize you had taken them off. The rug is the reason. You always take them off on the rug."

    e "Last week's task was noticing what you take your shoes off for. The rug, the kitchen threshold at home, the studio above the cafe. You have not yet said out loud what the noticing has been finding."

    e "You pay the co-pay at the desk."

    e "The afternoon is the afternoon."

    flame "wednesdays are the days with less friction, she said. that sounds right."

    ## Reflection prompt as chapter-end. Recognition source.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c3_feeling")

    menu:
        "continue to Chapter Seven":
            jump a2c4_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c3_skipped:
    scene black
    centered "Chapter Six was skipped."
    pause 1.5
    e "You had a session. Something happened in it. The next chapter continues."
    # Still apply a modest between-session gain so the skipped chapter
    # doesn't penalise committed players who skip for content reasons.
    $ rr_delta("regulation", +3)
    $ rr_delta("permission", +3)

    menu:
        "continue to Chapter Seven":
            jump a2c4_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
