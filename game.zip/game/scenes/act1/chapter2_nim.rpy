## scenes/act1/chapter2_nim.rpy — Act I Ch 2 NIM-branch variant.
##
## CEN Ch 2 Mother: distant, guilt-trippy. Protagonist fawns.
## MI Ch 2 Mother: depleted, in a depressive stretch. Protagonist
##   scans for warning signs and freezes.
## NIM Ch 2 Mother: overtly contemptuous. Protagonist's
##   fight/flight activates.
##
## Per PRD §4.3 NIM branch:
##   - Overt invalidation, contempt, or grandiosity.
##   - Dominant 4F pull: fight/flight.
##   - Harsh critic identified-with-aggressor (echoes Mother).
##   - Angry-protector firefighter.
##
## Craft discipline (NIM-specific):
##   - Mother's lines are specific and sharp, not vague. Contempt
##     is articulable. Quote it.
##   - The protagonist's options include *firing back*. That is
##     the fight/flight signature.
##   - The Critic that arrives after the call speaks in Mother's
##     phrases, lightly rearranged. Identified-with-aggressor.
##   - No flashback tail to childhood kitchen (CEN) or hallway
##     door (MI). NIM flashback is to a specific *public* moment
##     — Mother saying something cutting at a dinner party where
##     other people heard.

label a1c2_nim_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a1c2_nim", False):
        centered "Chapter Two — NIM branch\n\nA phone call from Mother. This Mother delivers specific cutting remarks. Scene contains one quoted line of contempt and a brief flashback to a childhood public-humiliation moment (written, not visual). Skippable at the chapter and scene level."
        $ chapter_notice_shown["a1c2_nim"] = True
        pause 2.0

    menu:
        "continue (NIM Ch 2)":
            pass
        "skip this chapter":
            jump a1c2_nim_skipped

    scene black
    with dissolve

    e "The phone rings. Her ringtone. You changed it once, five years ago. She found out. She said a thing about it you have not forgotten."

    menu:
        "answer":
            jump a1c2_nim_answer
        "let it go to voicemail":
            jump a1c2_nim_voicemail
        "skip the whole scene":
            jump a1c2_nim_skipped


label a1c2_nim_answer:
    scene black
    mother "Hi."

    e "She uses the form she has used since you were nine. You asked her three times in your twenties to stop using it. The asks are not in the room. The form is."

    e "The 'hi' is the 'hi.' You know how this goes. It takes between twelve and forty seconds for her to deliver the thing she called to deliver."

    mother "So. I was having dinner with Tamara last night. She asked how you're doing."

    e "Tamara is someone Mother sees twice a year. You have met Tamara four times in your life."

    mother "I said — oh, you know. I said that you're still — doing the writing thing? The thing you do?"

    e "The 'thing you do' is a specific construction. The 'thing you do' has always been the opposite of what Tamara's daughter does, which is pediatric neurology."

    $ rr_delta("critic_volume", +8)
    $ rr_delta("threat_scan", +6)

    mother "Tamara's daughter bought her parents an apartment in Moscow, you know. The one on Prechistenka. Two bedrooms. Tamara won't stop showing me pictures."

    ## This is the move. The contempt by implication. The "you haven't
    ## bought me an apartment" payload delivered as a story about
    ## Tamara.
    firefighter_voice "Hang up. Say you're on another call. Hang up."

    $ rr_delta("critic_volume", +6)

    menu:
        "say: that's nice. i have to go.":
            jump a1c2_nim_end_call
        "say: mom. that's not — you know why that's not.":
            jump a1c2_nim_push_back
        "say nothing; let her keep talking":
            jump a1c2_nim_silent
        "say: i'm not buying you an apartment. please stop.":
            jump a1c2_nim_direct


label a1c2_nim_end_call:
    scene black
    e "You say it the way you've said it four hundred times. Polite. Specific. A sentence she cannot object to."

    mother "Oh. Okay. Well. Anyway."

    e "She takes fifteen more seconds to end the call. You hold for the fifteen seconds."

    $ rr_delta("self_trust", +3)
    $ rr_delta("presence", +2)
    $ rr_delta("critic_volume", +4)

    critic_voice "You let her get away with that. Again. You let her do the Tamara thing and you did not even—"

    e "The Critic is speaking. The Critic is using a rhythm that is her rhythm. You hear her in the Critic's sentences."

    $ reco_credit("part_register_identified", "a1c2_nim_critic_uses_mothers_rhythm")

    $ act1c2_nim_outcome = "ended_call"
    jump a1c2_nim_after_call


label a1c2_nim_push_back:
    scene black
    e "You say: \"Mom. That's not — you know why that's not.\""

    pause 1.0

    mother "Why what's not? I'm telling you about my friend."

    e "She is going to do this. You remember she will do this. You forgot for a moment that she will do this."

    mother "It's always something with you. Can I not talk to you about my life?"

    $ rr_delta("critic_volume", +12)
    $ rr_delta("threat_scan", +8)
    $ rr_delta("regulation", -6)
    $ rr_delta("self_trust", -2)

    firefighter_voice "Hang up. Hang up now."

    menu:
        "say: okay. sorry. i misread.":
            e "You say it. She says something that is mostly not about you. The call ends eventually."
            $ rr_delta("self_trust", -4)
            $ rr_delta("critic_volume", +4)
        "say nothing; wait her out":
            e "You say nothing. She fills the silence with her own narration. She loses steam at minute three. The call ends."
            $ rr_delta("self_trust", +2)
            $ rr_delta("social_battery", -6)
        "hang up":
            e "You hang up. Your thumb did it before the rest of you did."
            $ rr_delta("self_trust", +5)
            $ rr_delta("critic_volume", +10)
            firefighter_voice "Good. Good. Good."

    $ act1c2_nim_outcome = "pushed_back"
    jump a1c2_nim_after_call


label a1c2_nim_silent:
    scene black
    e "You say nothing. You let her keep going. She does. She has a prepared list."

    e "Four minutes. Five. The list is a list you have heard before with the names changed."

    $ rr_delta("critic_volume", +10)
    $ rr_delta("social_battery", -8)
    $ rr_delta("regulation", -5)

    e "Eventually she runs out. She says a short sentence that sounds like a goodbye. You say yours back."

    e "You hold for the fifteen seconds."

    $ act1c2_nim_outcome = "silent_through"
    jump a1c2_nim_after_call


label a1c2_nim_direct:
    scene black
    e "You say it. \"I'm not buying you an apartment. Please stop.\""

    pause 2.0

    mother "Wow. I wasn't even talking about you. I was telling you about my friend. This is what I mean. This is what I always mean when I say you are—"

    e "She says a specific word. You have heard the word many times. You are thirty-four and you are eleven and you are thirty-four."

    $ rr_delta("critic_volume", +15)
    $ rr_delta("threat_scan", +10)
    $ rr_delta("regulation", -8)
    $ rr_delta("self_trust", +6)  # you said the true thing
    $ rr_delta("flashback_pressure", +12)

    firefighter_voice "Hang up. Hang up now. Now."

    menu:
        "hang up":
            e "You hang up. You sit in the room with the phone face-down. You shake a little. The shake takes twenty minutes to go."
            $ rr_delta("self_trust", +8)
            $ rr_delta("critic_volume", +6)
        "say: you know that word lands on me. i am ending this call.":
            e "You say it. She says something. You end the call."
            $ rr_delta("self_trust", +12)
            $ rr_delta("critic_volume", +8)
            $ rr_delta("permission", +4)
            $ reco_credit("reflection_completed", "a1c2_nim_named_the_word")

    $ act1c2_nim_outcome = "direct"
    jump a1c2_nim_after_call


label a1c2_nim_voicemail:
    scene black
    e "You decline the call. Your thumb did it before the rest of you did."

    $ rr_delta("self_trust", +4)
    $ rr_delta("critic_volume", +8)

    critic_voice "You could have handled it. You are not a child. She is an old woman."

    e "The Critic is saying something Mother said to you in May of 2019, almost word for word. You hear her in the Critic's sentences."

    $ reco_credit("part_register_identified", "a1c2_nim_critic_uses_mothers_rhythm")

    $ act1c2_nim_outcome = "voicemail"
    jump a1c2_nim_after_call


label a1c2_nim_after_call:
    scene black
    with fade

    ## NIM-specific flashback: a public-humiliation moment rather
    ## than a private kitchen / hallway. Uses verb_tense_torque via
    ## the "public" memory — dinner party with guests. The
    ## non_flashback that precedes it stages the contrast PRD §7.1
    ## anticipates: the first reach lands as a no-landing; the
    ## second as a verbatim childhood room.
    ## Flashback uses verb_tense_torque.public_humiliation_eleven_pale_blue
    e "After. The phone face-down. The apartment is the apartment."

    ## Flashback uses non_flashback.what_she_said_after
    e "You try to remember what she said after you put the phone down."
    e "You know she said something. You know you answered. You know the answer was a sentence with three words in it, maybe four."
    e "The three words are not available to you."

    e "There is a dining room with six adults in it. You are eleven. You are in a pale blue dress that she has dressed you in for the evening."

    e "She is telling the room something about you. The room is laughing, not unkindly, in the way adults laugh when the subject is safely not them."

    e "You are thirty-four. You are in your own apartment. The dining room is not a dining room; the dining room is not there."

    $ rr_delta("flashback_pressure", +6)

    flame "the critic on this path wears her voice on purpose. the critic was a child who memorised her cadences to try to get ahead of the next cutting thing. the memorising worked too well."

    ## Audit P-11 closure (0.1.18-46): NAMED_FLASHBACK source. The
    ## dining-room-with-six-adults at eleven during the call was a
    ## flashback. Same shape as a1c2.rpy (CEN) and a1c2_mi.rpy.
    menu:
        "name what just happened":
            e "You name it. You say to yourself: that was a flashback. The dining room at eleven, the pale blue dress, the six adults laughing. You are at this apartment now. You are not eleven in the dining room."
            $ rr_delta("self_trust", +3)
            $ rr_delta("presence", +2)
            $ reco_credit("named_flashback", "a1c2_nim_dining_room_flashback")
        "let it pass":
            e "You let it pass. The dining room has been the dining room at eleven many times before; it will be again. You do not have to name it every time."
            $ rr_delta("regulation", +2)

    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a1c2_nim_feeling")

    menu:
        "continue to Chapter Three (NIM)":
            jump a1c3_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a1c2_nim_skipped:
    scene black
    centered "Chapter Two (NIM variant) was skipped."
    pause 1.5
    e "The phone rang. You did what you did. The day continued."
    $ rr_delta("critic_volume", +4)

    menu:
        "continue to Chapter Three (NIM)":
            jump a1c3_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
