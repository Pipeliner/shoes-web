## scenes/act1/chapter3_nim.rpy — Act I Ch 3 NIM-branch variant.
##
## CEN Ch 3: afternoon work with fawn-adjacent numb-out.
## MI Ch 3:  afternoon work with dissociative firefighter.
## NIM Ch 3: afternoon work with angry-protector firefighter.
##          Public critical moment from a senior colleague echoes
##          Mother's register; fight/flight impulse activates.
##
## Per PRD §4.3 NIM branch signatures:
##   - Fight/flight firefighter: impulse to leave or confront.
##   - Critic identified-with-aggressor.
##
## Craft discipline (NIM-specific, work setting):
##   - The senior colleague is not Mother. The protagonist knows it
##     isn't Mother. The body is reacting as if.
##   - Verb-tense torque: the senior colleague says a specific
##     phrase and for a half-second the protagonist is eleven.
##   - The firefighter is ANGRY, not numb, not dissociative. It
##     wants to fire back or leave.
##
## Ends with the same Act I exit stressor (aunt's email) so Act II
## routes consistently on all three branches.

label a1c3_nim_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a1c3_nim", False):
        centered "Chapter Three — NIM branch\n\nAn afternoon at work. A senior colleague says something in a meeting that lands harder than it should. Fight/flight firefighter activates. Brief verb-tense-torque moment (written, not visual)."
        $ chapter_notice_shown["a1c3_nim"] = True
        pause 2.0

    menu:
        "continue (NIM Ch 3)":
            pass
        "skip this chapter":
            jump a1c3_nim_skipped

    scene black
    with dissolve

    e "It is the afternoon. You are at the standup. Your camera is on, the way your camera is on now that you've been asked to have your camera on."

    e "Tom is running the standup. Tom has been running the standup since his manager's manager asked him to. Tom is fine."

    e "You share your update. Two sentences. You keep them tight because the tight sentences are the ones that don't invite follow-up."

    ## The senior colleague's contempt moment.
    $ rr_delta("social_battery", -3)
    $ rr_delta("threat_scan", +4)

    e "The senior architect says: \"We're still hearing about the same thing you were blocked on last sprint. Did something actually change, or did you just — I don't know — change the framing?\""

    ## The phrase "change the framing" lands via verb-tense torque.
    ## For a half-second, the protagonist is eleven.
    e "There is a dining room. She is saying something to you about how you never really change the underlying thing, you just change the words."

    e "You are at the standup. Tom is looking at his screen. Two of the others are looking at theirs."

    $ rr_delta("flashback_pressure", +8)
    $ rr_delta("threat_scan", +10)
    $ rr_delta("critic_volume", +10)
    $ rr_delta("regulation", -6)

    firefighter_voice "Say something. Say something now. Or leave the call. Leave. Right now."

    menu:
        "fire back — defend the work, specifically":
            jump a1c3_nim_fire_back
        "leave the call — 'sorry, bad connection'":
            jump a1c3_nim_leave
        "stay, say nothing, take the hit":
            jump a1c3_nim_take_it
        "notice the verb-tense slide; name it internally":
            jump a1c3_nim_notice
        "step away from the screen for a minute — log off, go outside":
            ## Audit P-15 closure (0.1.18-46): gated-with-
            ## explanation choice teaching the visibly-
            ## unavailable mechanic, parallel to CEN's
            ## a1c3_break gate and MI's a1c3_mi_real_break
            ## gate. The NIM angry-protector firefighter is
            ## already pressing for an exit; the gate's
            ## blocking explanation comes from the firefighter
            ## itself — *too tired even to walk this off*. If
            ## blocked, route to take_it (the dissociation that
            ## happens when neither leave nor confront works).
            ## If energy permits, route to a1c3_nim_step_away
            ## (an actual break, distinct from the bad-
            ## connection lie of the leave path).
            if rr_get("energy") < 35:
                firefighter_voice "We don't have the energy to walk this off properly. We don't even have the energy to stand up correctly. Stay. Take it."
                jump a1c3_nim_take_it
            else:
                jump a1c3_nim_step_away


label a1c3_nim_fire_back:
    scene black
    e "You fire back. You name the actual blocker. You name the three specific changes you made to work around it. You name the thing that's still blocking."

    e "Your voice is tight. Not loud. Tight."

    pause 1.0

    architect_voice "...okay. Fair. I'll follow up on that."

    $ rr_delta("self_trust", +8)
    $ rr_delta("critic_volume", +6)  # still — per A7 + A10
    $ rr_delta("social_battery", -6)
    $ rr_delta("energy", -4)

    critic_voice "You escalated. You escalated in front of Tom. You always do this."

    e "The Critic is using a phrase. The phrase is not the architect's. The phrase is hers. You hear her in it."

    $ reco_credit("part_register_identified", "a1c3_nim_escalation_critic_voice")

    $ act1c3_nim_outcome = "fired_back"
    jump a1c3_nim_post


label a1c3_nim_leave:
    scene black
    e "You say, audibly, \"Sorry — bad connection — give me one second.\""

    e "You drop the call. You sit with the laptop closed for a minute. The minute is a minute you have sat with the laptop closed in a version of this room in other calls for other reasons."

    $ rr_delta("social_battery", -4)
    $ rr_delta("self_trust", +2)
    $ rr_delta("critic_volume", +10)
    $ rr_delta("energy", -3)

    critic_voice "You fled. You flew. You always fly. You are a flier."

    e "The Critic has landed on the specific frame that is hers. You notice the frame. The noticing does not stop the frame."

    $ act1c3_nim_outcome = "left"
    jump a1c3_nim_post


label a1c3_nim_take_it:
    scene black
    e "You stay. You say nothing for a moment. Tom fills the silence. The standup continues."

    e "The afternoon continues. The afternoon is not the afternoon you thought you were going to have."

    $ rr_delta("social_battery", -8)
    $ rr_delta("critic_volume", +14)
    $ rr_delta("self_trust", -6)
    $ rr_delta("regulation", -4)

    critic_voice "You took that. You never say anything when someone does that. You are—"

    e "The Critic runs the sentence. The sentence is Mother's sentence with three words swapped out. You know this. Knowing does not make the sentence shorter."

    $ act1c3_nim_outcome = "took_it"
    jump a1c3_nim_post


label a1c3_nim_notice:
    scene black
    e "You notice it. You are not eleven. The architect is not Mother. The word 'framing' is a professional word in this context and is not the word it was in 1999."

    ## The noticing doesn't dissolve the reaction — A10 pattern —
    ## but it does permit a different internal response.
    $ rr_delta("presence", +4)
    $ rr_delta("interoception", +5)
    $ rr_delta("regulation", +3)
    $ rr_delta("self_trust", +4)

    e "Your shoulders are at your ears. You let them drop a centimeter. They do not drop all the way."

    e "You say: \"Yeah — let me follow up in the thread. I think it's a specific thing.\""

    architect_voice "Sure."

    ## This path still costs energy but is the highest-leverage one.
    $ rr_delta("social_battery", -3)
    $ rr_delta("critic_volume", +4)  # still spikes per A10
    $ rr_delta("energy", -2)

    critic_voice "You noticed. Great. Now you're the kind of person who notices her. You want a medal?"

    e "The Critic doubles back. Noticing did not retire it. It is the Critic's job to keep speaking."

    $ reco_credit("reflection_completed", "a1c3_nim_noticed_verb_tense_slide")

    $ act1c3_nim_outcome = "noticed"
    jump a1c3_nim_post


label a1c3_nim_step_away:
    ## Audit P-15 closure (0.1.18-46): the unblocked break path
    ## on NIM. Parallel to CEN a1c3_break and MI
    ## a1c3_mi_real_break — protagonist actually goes outside
    ## for a few minutes. NIM-specific register: this is the
    ## angry-protector firefighter consenting to a controlled
    ## leave (rather than the seizing fight/flight exit it
    ## defaults to in a2c1_nim) — a small first instance of
    ## the protagonist *negotiating* with the angry-protector
    ## rather than being moved by it.
    scene black
    e "You log off. You say what people say when they log off mid-call: connection's bad. Try later."

    e "You put your shoes on. The shoes have a heel that wears down on the outside; you have noticed this before. You go outside without the phone."

    e "Your feet feel the pavement. The pavement is uneven where the tree root has come up under it."

    $ rr_delta("presence", +12)
    $ rr_delta("interoception", +10)
    $ rr_delta("energy", +4)
    $ rr_delta("regulation", +8)

    e "You walk to the corner. You walk back."

    e "The angry-protector part of you is along for the walk. It is keeping pace. It does not need to be moving you out of a room because you are already moving."

    e "Nothing is fixed. The architect is still on a meeting. The work is still on a tab. The room you walked out of is still there."

    e "Something that has been pressing at the back of your jaw has stepped a half-step back."

    ## Recognition: the protagonist negotiated with the
    ## firefighter's leave-impulse rather than being seized
    ## by it. Per parts-language.md: noticing the part is the
    ## work.
    $ reco_credit("part_register_identified", "a1c3_nim_angry_protector_walked_with")

    $ act1c3_nim_outcome = "stepped_away"
    jump a1c3_nim_post


label a1c3_nim_post:
    scene black
    with fade

    e "Eventually the afternoon continues. The standup is over. The task is still the task."

    e "At 5:47 PM the email arrives."

    e "The subject line contains your mother's name."

    $ rr_delta("flashback_pressure", +16)
    $ rr_delta("threat_scan", +14)
    $ rr_delta("regulation", -8)

    e "Your mother does not send you email. The email is not from her."

    e "The email is from your mother's sister. You have not spoken to your mother's sister in eleven years."

    e "The subject line is 'Your mother.'"

    firefighter_voice "Read it now. Read it now and get it over with. Or don't. But decide."

    e "The firefighter is impatient in a specific way. It is fight/flight's way."

    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a1c3_nim_feeling")
    e "Chapter four — Act II — begins with the email, on all three branches."

    menu:
        "continue to Chapter Four (NIM)":
            jump a2c1_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a1c3_nim_skipped:
    scene black
    centered "Chapter Three (NIM variant) was skipped."
    pause 1.5
    e "The afternoon passed. The email arrived. what follows picks it up."
    $ rr_delta("flashback_pressure", +10)
    $ rr_delta("threat_scan", +8)

    menu:
        "continue to Chapter Four (NIM)":
            jump a2c1_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
