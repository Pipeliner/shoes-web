## scenes/act3/cancel_the_call_nim.rpy — Act III structural-change scene
## (NIM variant).
##
## Per PRD §4.7 + S1 design reversal (0.1.18-46): Act III now
## supports per-branch variants. CEN equivalent:
## scenes/act3/cancel_the_call.rpy. Same gated-menu shape and
## Recognition gate threshold — but the prose lands on
## NIM-specific texture.
##
## Branch differences vs. CEN:
##   - The Wednesday call is, at some level, a preview of what
##     Mother might say about you elsewhere. The threat-scanner
##     listens for what's been told to whom — Tamara, the
##     aunt, the dinner-circuit. Cancelling means losing a
##     scheduled survey of the discourse.
##   - Mother's reply is performative-hostile — sharper than
##     CEN's flat "ok. wednesday." A short message designed
##     to be screenshot-ed, in case the protagonist ever needs
##     to defend this decision to anyone in the family.
##   - The Critic on landed-cancellation activates the
##     threat-scanner's worst-case: she'll have something to
##     say about this at her next dinner. Tamara will be there.
##   - The not_sent path's 38-minute call is preview-of-what-
##     Tamara-will-hear texture: scanning for what's been said
##     about you, what's about to be quoted.
##
## Reuses the gated-choice screen `a3_cancel_the_call_menu`
## from cancel_the_call.rpy (branch-agnostic UI).

label a3_cancel_the_call_nim:
    scene black
    show screen tooltip_overlay

    e "Wednesday again. The calendar says seven PM. Your mother's name."

    ## NIM-specific opening: discourse-survey framing.
    e "You have not cancelled a call with your mother in fifteen years. The threat-scanner has not let you. Cancelling means losing a scheduled survey of what she has been saying — and to whom."

    e "You have said you had to go partway through; once, twice, five times — usually after she let slip whatever she had been holding to tell you. You have not cancelled one. Cancelling is not the same as walking away from the dinner that has already started."

    pause 1.0

    e "Your phone is on the table. The call is in ninety minutes."

    ## The attempt — gated menu, reuses the CEN screen.
    call screen a3_cancel_the_call_menu

    if _return == "send_now":
        jump a3_cancel_the_call_nim_sent
    elif _return == "send_now_refused":
        ## refuse_on_block path — the fawn part speaks.
        ## NIM-specific: the Caretaker frames the refusal as
        ## losing-discourse-data.
        caretaker_voice "Not now. Not over a text. She will tell people you cancelled by text. The cancelling-by-text becomes a thing she has on you."
        e "You set the phone down. The call is in eighty-seven minutes now."
        jump a3_cancel_the_call_nim_not_sent
    elif _return == "draft":
        jump a3_cancel_the_call_nim_draft
    else:
        jump a3_cancel_the_call_nim_not_sent


label a3_cancel_the_call_nim_sent:
    scene black
    with fade
    e "You press send. The message sits in the chat in that particular way a message sits when you are the one who just sent it."

    e "Your mother is typing."

    pause 1.0

    e "Your mother has stopped typing."

    pause 1.0

    e "Your mother is typing again."

    pause 1.0

    ## NIM-specific reply: short, performative, screenshot-ready.
    ## The kind of reply that can be quoted later.
    mother "If that's what works for you."

    e "That is all she writes. The threat-scanner reads the seven words: short enough to be quotable. Punctuated enough to be screen-shotted. *If that's what works for you* is the kind of sentence that can be retold at a dinner with one slight inflection that turns it into you being difficult."

    ## State effects mirror CEN.
    $ rr_delta("self_trust", +8)
    $ rr_delta("permission", +4)
    $ rr_npc_delta("mother", -3, safe=False)

    ## NIM-specific Critic activation — borrowed Mother cadence.
    critic_voice "She will tell Tamara on Friday. The way you cancelled is going to be the next thing the dinner has on you. This is what I always mean when I say—"

    $ rr_delta("critic_volume", +6)

    e "The Critic is saying something the threat-scanner is partially agreeing with. The cadence the Critic is wearing is not the Critic's. Both of them are working from the seven-word reply. Neither of them has the data on what Mother actually intends to say to whom."

    ## Credit Recognition — same as CEN.
    $ reco_credit("reflection_completed", "a3_cancel_the_call_nim_succeeded")

    flame "you cancelled a call with your mother. that is a specific thing that has now happened. what she does with it elsewhere is her business and not yours."

    $ act3_outcomes["cancel_the_call"] = "sent"
    $ renpy.fix_rollback()
    jump a3_cancel_the_call_nim_close


label a3_cancel_the_call_nim_draft:
    scene black
    e "You write the text. You read it three times. You read it for what could be quoted out of it. You revise. You re-read for the same thing. You do not press send."

    e "It sits in the message composer for forty minutes. The threat-scanner is, the whole forty minutes, running its forecast of which version of the message would be hardest to weaponise at her next dinner."

    e "At six PM you delete the draft, unsent. None of the versions felt safe enough."

    $ rr_delta("self_trust", -3)
    $ rr_delta("critic_volume", +4)
    $ rr_delta("presence", +3)

    critic_voice "You never send them. You always draft and delete. You always need the version that cannot be quoted, and there is no version that cannot be quoted."

    e "The Critic is not wrong. The noticing of this is new, even if the drafting-and-deleting is old."

    $ reco_credit("part_register_identified", "a3_cancel_draft_and_delete_pattern_nim")

    $ act3_outcomes["cancel_the_call"] = "drafted"
    $ renpy.fix_rollback()
    jump a3_cancel_the_call_nim_not_sent


label a3_cancel_the_call_nim_not_sent:
    scene black
    with fade

    ## NIM-specific not_sent: discourse-survey texture for the
    ## 38-minute call.
    e "The call happens at seven. It lasts thirty-eight minutes. The threat-scanner is on the call too — listening for which names she drops, which dinners are coming up, which versions of the family-narrative she is currently running. You are not really on the call. The threat-scanner is."

    $ rr_delta("presence", -8)
    $ rr_delta("flashback_pressure", +6)
    $ rr_delta("regulation", -4)

    e "After, you put the phone face-down. You sit for a while. The threat-scanner delivers its summary: Tamara at the Saturday dinner; the Cousin H. version of your job is now subtly worse than last week's version; Aunt likely heard the Saturday-dinner version on the Sunday call."

    flame "you did not cancel this week. that is information, not a verdict. the threat-scanner has been on for thirty-eight minutes and has, in its way, done the survey it needed to do."

    if act3_outcomes.get("cancel_the_call") != "drafted":
        $ act3_outcomes["cancel_the_call"] = "not_sent"
        $ renpy.fix_rollback()
    jump a3_cancel_the_call_nim_close


label a3_cancel_the_call_nim_close:
    scene black
    with fade
    e "The phone goes back on the counter. The week continues. The threat-scanner's summary is the map of the discourse you are moving through this week."
    return
