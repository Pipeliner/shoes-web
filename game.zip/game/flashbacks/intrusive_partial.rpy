# GEN-CHECKSUM: db0151248b6a9487
## Flashback snippets — technique: intrusive_partial
## One or two sentences of child-scene surface mid-paragraph. No follow-up.
##
## Generated from intrusive_partial.yaml. Hand-edit below the
## GEN-CHECKSUM line preserved by --force only.
##
## This file is a reference catalog, not live scene code.
## Scene authors grep for snippet IDs, then hand-adapt
## the prose into the target scene's voice. Do not
## import this file or reference its contents at runtime.

## --- snippet: wallpaper_line ---
## surfacing_line:
##   'the kitchen had yellow wallpaper and i was on the floor.'
## placement:
##   'mid-paragraph, lowercase, as the content of a text message the player composes'

## --- snippet: hallway_table_glass ---
## surfacing_line:
##   'The glass on the hallway table was always cold when you picked it up, even when nobody had been near it for hours.'
## placement:
##   'embedded in a present-tense narration about an unrelated object feeling cold'

## --- snippet: closed_door_ninety_seconds ---
## surfacing_line:
##   'You stood outside her door for ninety seconds before you knocked. You had counted to ninety before knocking. You had chosen ninety because it was the longest you had ever managed.'
## placement:
##   'mid-paragraph during a present-day scene where the protagonist hesitates before doing a small thing'

## --- snippet: what_mother_did_not_say ---
## surfacing_line:
##   'You remember her looking at you and then not saying anything.'
## placement:
##   "one sentence only, mid-paragraph, in any scene where the protagonist is waiting for someone's answer"

