## screens/reflection.rpy — chapter-end reflection prompts.
##
## Per PRD §4.7 and §7.4: reflection prompts are short, open, unscored.
## Examples: "What part spoke loudest this chapter?" with a part-icon
## picker; "Write one sentence you wish you had said."
## These are Recognition sources, not quizzes.

init python:
    def reco_credit(source_key, event_id):
        """Credit a RecognitionSource to the ledger. No-op if event_id
        has already been credited."""
        from logic.recognition import RecognitionLedger, RecognitionSource
        global recognition_ledger
        source = RecognitionSource(source_key)
        renpy.store.recognition_ledger = recognition_ledger.credit(source, event_id)


## Reflection screens — the protagonist's journal entries.
##
## Per playtest 2026-04-26: the previous prompts ("Before you set
## this chapter down" / "Who spoke loudest this chapter?") read as
## meta-game prompts rather than journal entries. They didn't
## clarify whose journal it was, who was writing, or what the player
## was doing.
##
## Redesigned to:
##   1. Frame the screen as a journal page (small "from your journal"
##      banner, italic prompt in the protagonist's first-person voice).
##   2. Use first-person prompts ("I was…", "today the loudest part
##      of me was…") so picking an option clearly = the protagonist
##      writing that sentence in her journal.
##   3. Use italic styling throughout to visually distinguish the
##      journal layer from the rest of the game (which uses
##      second-person narrator voice).
##   4. Make the skip option name what skipping means
##      ("nothing to write today") rather than the generic "skip".

screen reflection_feeling_wheel(event_id):
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        xpadding 40
        ypadding 40
        xmaximum 700
        background gui.modal_frame_background

        vbox:
            spacing 14

            text _("{i}from your journal{/i}") size 14 color "#666"

            null height 6

            text _("{i}I was…{/i}") size 28 color gui.accent_color

            null height 12

            hbox:
                spacing 14
                textbutton _("{i}tired{/i}") action [Return("tired"), Function(reco_credit, "reflection_completed", event_id)]
                textbutton _("{i}careful{/i}") action [Return("careful"), Function(reco_credit, "reflection_completed", event_id)]
                textbutton _("{i}numb{/i}") action [Return("numb"), Function(reco_credit, "reflection_completed", event_id)]
                textbutton _("{i}alert{/i}") action [Return("alert"), Function(reco_credit, "reflection_completed", event_id)]
                textbutton _("{i}small{/i}") action [Return("small"), Function(reco_credit, "reflection_completed", event_id)]

            null height 8

            textbutton _("{size=14}skip — nothing to write today{/size}") action Return(None)


screen reflection_part_picker(event_id):
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        xpadding 40
        ypadding 40
        xmaximum 700
        background gui.modal_frame_background

        vbox:
            spacing 14

            text _("{i}from your journal{/i}") size 14 color "#666"

            null height 6

            text _("{i}today the loudest part of me was…{/i}") size 24 color gui.accent_color

            null height 12

            vbox:
                spacing 8
                textbutton _("{i}the part that takes care of others first{/i}") action [
                    Return("caretaker"),
                    Function(reco_credit, "part_register_identified", event_id + ":caretaker"),
                ]
                textbutton _("{i}the part that goes numb and scrolls{/i}") action [
                    Return("numb-out"),
                    Function(reco_credit, "part_register_identified", event_id + ":numb"),
                ]
                textbutton _("{i}the voice that says \"you always\" and \"you never\"{/i}") action [
                    Return("critic"),
                    Function(reco_credit, "part_register_identified", event_id + ":critic"),
                ]
                textbutton _("{i}something smaller — I could barely hear it{/i}") action [
                    Return("small-one"),
                    Function(reco_credit, "sat_with_exile", event_id + ":small"),
                ]

            null height 8

            textbutton _("{size=14}skip — nothing to name today{/size}") action Return(None)
