## scenes/act3/mention_the_childhood_thing_mi.rpy — Act III
## structural-change scene (MI variant).
##
## Per S1+S3 (0.1.18-46): Act III per-branch variants. CEN
## equivalent: scenes/act3/mention_the_childhood_thing.rpy.
## Same gated-menu shape (send_short / send_long / delete /
## put_down) and Recognition gate threshold (20 — highest
## tier).
##
## Branch differences vs. CEN:
##   - 2am as the stretch-watcher's *off-shift hour* — the
##     only hour the protagonist gets without active
##     listening for Mother. Ben as the night-friend aligns.
##   - The opening texture: the protagonist has been holding
##     the half-channel open all day; only at 2am is the
##     half-channel quiet enough to type a sentence that is
##     not for Mother.
##   - Exile-voice surfaced fragment is the
##     hallway-at-eight signature.
##   - Critic on send: stretch-watcher's rationalisation for
##     not having told.

label a3_mention_the_childhood_thing_mi:
    scene black
    show screen tooltip_overlay

    e "Two in the morning. You are on the couch. You cannot sleep."

    e "The laptop is closed. The phone is in your hand."

    e "Ben is awake. He is always awake at this hour; he has been a night person since you were twelve. You know this from twenty years of being his friend."

    ## MI-specific: 2am as the stretch-watcher's off-shift hour.
    e "Two in the morning is the only hour the stretch-watcher reliably is not running. She is asleep. The aunt is asleep. Tamara is asleep — Tamara is in a different time zone but the rule holds. There are no calls in this hour. The stretch-watcher has nothing to scan for. The half-channel is, for the first time today, quiet."

    e "You have not told him."

    e "You have meant to tell him. You have drafted telling him in your head on and off for fifteen years — usually during stretches she was in, when the watching was loudest and you most wanted someone outside the watching to know."

    e "He has been in your life longer than you have known there was a thing to tell, which is why he is the one you are typing at."

    pause 1.0

    e "Tonight is not different in most ways. In one way it is. The stretch-watcher is off-shift and the typing might land before it comes back on."

    e "You are composing a text. You have not typed anything yet."

    pause 1.0

    call screen a3_mention_menu

    if _return == "send_short":
        jump a3_mention_mi_send
    elif _return == "send_short_refused":
        ## MI Caretaker register on the refusal.
        caretaker_voice "Not at two in the morning. He will think something is wrong. He will worry. He has worried about you in stretches before."
        e "You put the phone down. The keyboard fades. You sit on the couch for a while. The stretch-watcher, off-shift, does not have an opinion."
        jump a3_mention_mi_not_sent
    elif _return == "send_long":
        jump a3_mention_mi_long_sent
    else:
        jump a3_mention_mi_not_sent


label a3_mention_mi_send:
    scene black
    with fade

    ## Intrusive-partial per PRD §7.1: only the MI hallway
    ## fragment surfaces.
    e "You type one sentence."

    e "You type: "

    exile_voice "i was eight and i was outside her bedroom door and i could hear her not moving."

    pause 2.0

    e "You delete the beginning of the sentence. 'there is something i want to tell you' is not what you type. The sentence is the sentence."

    e "You press send."

    pause 1.0

    e "The message sends at 02:14 local."

    e "Ben's typing indicator appears at 02:14 and a half."

    pause 1.0

    e "You close your eyes."

    ## State effects mirror CEN.
    $ rr_delta("self_trust", +12)
    $ rr_delta("permission", +6)
    $ rr_npc_delta("ben", +10, safe=True)
    $ rr_delta("flashback_pressure", +10)
    $ rr_delta("presence", -4)

    ## MI-specific Critic line: stretch-watcher's
    ## rationalisation for not having told.
    critic_voice "You did not have to do that. The stretch-watcher would have kept it for fifteen more years. Fifteen more years was not so long. You could have done fifteen more years."

    $ rr_delta("critic_volume", +5)

    e "The Critic is reading from the Caretaker's script. You notice the cadence is the Caretaker's, not the Critic's."

    ## This is the scene the witnessed ending references. Flag it.
    $ act3_outcomes["mention_the_childhood_thing"] = "sent"
    $ renpy.fix_rollback()

    ## Highest-tier Recognition credits — distinct event_ids.
    $ reco_credit("sat_with_exile", "a3_mention_mi_short_version_sent")
    $ reco_credit("named_flashback", "a3_mention_mi_hallway_line")

    flame "you sent the short version. that sentence did not exist in a message from you before tonight. now it does. the stretch-watcher is going to wake up to it being said."

    jump a3_mention_mi_close


label a3_mention_mi_long_sent:
    scene black
    with fade
    e "You type a wall of text. You re-read the wall of text. The wall of text is fifteen years."

    e "You send it anyway."

    pause 1.0

    e "Ben does not respond for forty minutes."

    e "When Ben responds, he says: that is a lot. can we talk on saturday."

    pause 1.0

    e "You say yes. You put the phone face-down. You do not sleep."

    $ rr_delta("self_trust", +6)
    $ rr_delta("flashback_pressure", +18)
    $ rr_delta("presence", -10)
    $ rr_npc_delta("ben", +6, safe=True)

    e "The long version cost more than the short would have. You notice the cost. You notice also that Ben said 'saturday.'"

    $ act3_outcomes["mention_the_childhood_thing"] = "long_sent"
    $ renpy.fix_rollback()
    $ reco_credit("named_flashback", "a3_mention_mi_long_version_sent")

    flame "sending the long version is a thing that happens. sending the short version would have been a different thing. both are real."

    jump a3_mention_mi_close


label a3_mention_mi_not_sent:
    scene black
    with fade

    e "Tomorrow comes. You did not send."

    e "You do not send on tuesday either. Or wednesday. By thursday the stretch-watcher is back on duty and the half-channel is loud again."

    $ rr_delta("self_trust", -3)
    $ rr_delta("critic_volume", +4)
    $ rr_delta("presence", +3)

    critic_voice "You always think about it. You never do it. You always need the stretch-watcher off-shift, and the stretch-watcher is, as a feature, almost never off-shift."

    e "The drafting-and-not-sending is old. Noticing how old it is, and what it is bound to, is not."

    $ reco_credit("part_register_identified", "a3_mention_mi_draft_delete_pattern")

    $ act3_outcomes["mention_the_childhood_thing"] = "not_sent"
    $ renpy.fix_rollback()
    jump a3_mention_mi_close


label a3_mention_mi_close:
    scene black
    with fade
    e "The phone is face-down on the couch beside you. The night closes."
    return
