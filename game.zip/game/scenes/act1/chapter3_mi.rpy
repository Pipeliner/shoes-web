## scenes/act1/chapter3_mi.rpy — Act I Ch 3 MI-branch variant.
##
## CEN Ch 3 features the fawn-adjacent numb-out during standup
## (dissociation as texture). MI Ch 3 features outright dissociation
## in the foreground — the dissociative firefighter described in
## PRD §4.3 MI-branch part cast is the scene's co-protagonist.
##
## Prose craft per PRD §7.1 dissociation markers:
##   - Hyper-specific irrelevant detail (the grain of a tabletop)
##   - Loss of pronoun ownership ("her hand picked up the phone")
##   - Temporal smearing
##   - Flat affect on high-stakes content
##   - Observer position ("she watched herself")
##
## These craft markers are used *more aggressively* here than in
## CEN Ch 3 because the MI branch prose voice is higher-dissociation
## by default.
##
## Ends with the same Act I exit stressor (email from aunt, subject
## line "Your mother") so the Act II phone-email chain continues to
## work on both branches.

label a1c3_mi_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a1c3_mi", False):
        centered "Chapter Three — MI branch\n\nAn afternoon at work. The dissociative firefighter is foregrounded. No sensitive content beyond the dissociative prose itself."
        $ chapter_notice_shown["a1c3_mi"] = True
        pause 2.0

    menu:
        "begin chapter three (MI)":
            pass
        "skip this chapter":
            jump a1c3_mi_skipped

    scene black
    with dissolve

    e "It is the afternoon. The laptop is open. The cursor is in the field."

    e "The field has a name. The name is on the tab of the task tracker."

    e "She is looking at the name of the task. She has been looking at the name of the task for either nine minutes or forty."

    ## Pronoun drift — the observer position. Not "you" any more.
    $ rr_delta("presence", -10)
    $ rr_delta("interoception", -8)
    $ rr_delta("energy", -4)
    $ rr_delta("flashback_pressure", +4)

    menu:
        "try to start — click the cursor into the body":
            jump a1c3_mi_try_to_start
        "stay with the dissociation for a few minutes; do not fight it":
            jump a1c3_mi_stay_with_it
        "stand up; get water; break the pattern":
            jump a1c3_mi_break_pattern
        "take a real break — go outside, no phone":
            ## Audit P-15 closure (0.1.18-46): gated-with-
            ## explanation choice teaching the visibly-
            ## unavailable mechanic, parallel to CEN's
            ## chapter3.rpy:48-58 take_a_real_break gate. The
            ## MI Caretaker is the stretch-watcher / ring-
            ## counter — its blocking explanation is in that
            ## register.
            if rr_get("energy") < 35:
                caretaker_voice "You don't have the energy to actually do that. You would end up scrolling on a bench for forty minutes and come back more tired."
                jump a1c3_mi_try_to_start
            else:
                jump a1c3_mi_real_break


label a1c3_mi_try_to_start:
    scene black
    e "Her hand moves to the keyboard. The keyboard is under her hand. The letters on the keyboard are worn at the letters she uses most."

    e "The letter E is nearly blank. The letter A is nearly blank. The space bar has a specific curve in the middle."

    e "Nine minutes pass. Or forty. The field is empty."

    firefighter_voice "Don't worry about the task. I have you."

    e "The part of her that takes her out of rooms she cannot stay in has taken her out of this room. She is aware of the keyboard. She is aware of the letters. She is not aware of what she was supposed to be writing."

    $ rr_delta("presence", -6)
    $ rr_delta("flashback_pressure", +4)

    $ act1c3_mi_outcome = "tried_and_drifted"
    jump a1c3_mi_post


label a1c3_mi_stay_with_it:
    scene black
    e "She does not fight it. She notices that she is in the not-quite-here place. She notices that there is a specific texture to the not-quite-here place that has been there since she was small."

    ## Presence and interoception rise slightly — naming the state
    ## without fighting it is a form of noticing.
    $ rr_delta("presence", +3)
    $ rr_delta("interoception", +4)
    $ rr_delta("regulation", +3)

    e "Her hands are her hands. The laptop is a laptop. The chair is a chair. The light on the ceiling is the light on the ceiling."

    e "The Firefighter does not leave; it ebbs."

    ## Recognition: sat with a dissociative state instead of forcing
    ## productivity.
    $ reco_credit("part_register_identified", "a1c3_mi_dissociative_firefighter_sat_with")

    $ act1c3_mi_outcome = "stayed_with_it"
    jump a1c3_mi_post


label a1c3_mi_break_pattern:
    scene black
    e "She stands. The standing is less a decision than a muscle memory. The muscle memory has been with her a long time."

    e "The kitchen is eight steps from the desk. She knows. She has counted. Not on purpose."

    e "The tap water is cold. The glass is cold. The sensation of the cold glass is the first specific thing she has felt in the afternoon."

    $ rr_delta("presence", +5)
    $ rr_delta("interoception", +8)
    $ rr_delta("regulation", +4)
    $ rr_delta("energy", +2)

    e "The kitchen light is the light of 3:30 PM. The kitchen at 3:30 PM is a specific kind of quiet."

    e "She stays in the kitchen for longer than she needs to."

    $ reco_credit("reflection_completed", "a1c3_mi_kitchen_interrupt")

    $ act1c3_mi_outcome = "broke_pattern"
    jump a1c3_mi_post


label a1c3_mi_real_break:
    ## Audit P-15 closure (0.1.18-46): the unblocked break path —
    ## the protagonist actually goes outside, without the phone,
    ## for a few minutes. Mirrors CEN a1c3_break's structural
    ## arc: shoes on, outside, pavement, walk to corner, walk
    ## back, return without resolution. MI register: the
    ## stretch-watcher manager is quieter outdoors; a single
    ## line acknowledges it ebbs.
    scene black
    e "She closes the laptop. She puts on her shoes — the ones with the heel wearing down on the outside."

    e "She goes outside without the phone."

    e "Her feet feel the pavement. The pavement is uneven where the tree root has come up under it."

    $ rr_delta("presence", +12)
    $ rr_delta("interoception", +10)
    $ rr_delta("energy", +4)
    $ rr_delta("regulation", +8)

    e "She walks to the corner. She walks back."

    e "Nothing is fixed. The task is still there. The screen is still blue."

    e "The part of her that has been counting steps and rings under the surface ebbs a little. She does not notice the ebbing. She notices the pavement."

    ## Recognition for noticing — same shape as CEN a1c3_break.
    $ reco_credit("part_register_identified", "a1c3_mi_small_one_noticed")

    $ act1c3_mi_outcome = "real_break"
    jump a1c3_mi_post


label a1c3_mi_post:
    scene black
    with fade
    e "Eventually the afternoon continues. Whether the task was done is a question she will answer tomorrow morning."

    e "At 5:47 PM the email arrives."

    e "The subject line contains her mother's name."

    $ rr_delta("flashback_pressure", +16)
    $ rr_delta("threat_scan", +14)
    $ rr_delta("regulation", -8)

    e "Her mother does not send her email. The email is not from her mother."

    e "The email is from her mother's sister. She has not spoken to her mother's sister in eleven years."

    e "The subject line is 'Your mother.'"

    firefighter_voice "Not now. Tomorrow. Maybe tomorrow."

    e "The part of her that takes her out of rooms has a strong opinion about this particular email."

    ## Reflection close.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a1c3_mi_feeling")
    e "Chapter four — Act II — begins with the email, on either path."

    menu:
        "continue to Chapter Four (MI)":
            jump a2c1_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a1c3_mi_skipped:
    scene black
    centered "Chapter Three (MI variant) was skipped."
    pause 1.5
    e "The afternoon passed. The email arrived. what follows picks it up."
    $ rr_delta("flashback_pressure", +10)
    $ rr_delta("threat_scan", +8)

    menu:
        "continue to Chapter Four (MI)":
            jump a2c1_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
