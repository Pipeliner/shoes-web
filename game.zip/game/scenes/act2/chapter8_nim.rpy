## scenes/act2/chapter8_nim.rpy — Sunday accounting (NIM variant).
##
## Mirrors the structural arc of `game/scenes/act2/chapter8.rpy`
## (CEN) and `chapter8_mi.rpy` (MI) — same five-beat shape:
## chapter notice + skip; opening on the kitchen table; three-
## option menu (ask the Caretaker / notice the cold / skip the
## noticing); after-negotiate close; skipped path.
##
## Branch differences vs. CEN/MI:
##   - The Caretaker's calibration target is *what gets said*.
##     CEN's Caretaker pre-empts Mother's anger; MI's monitors
##     the stretch-cycle; NIM's monitors public-discussability —
##     who is at the dinner this week, what story Mother has
##     prepared, whether Tamara will be there, whether the aunt
##     will hear. Anchored in the established NIM Caretaker
##     register (a1c1_nim threat-scan: clocking the room for
##     what is about to be said about you) and the public-
##     humiliation childhood signature (a1c2_nim:177; a2c1_nim
##     :109).
##   - The Critic-half-right line (skip-noticing path) carries
##     the NIM Critic's borrowed-from-Mother register
##     (docs/continuity.md:556-559). The "you should have looked
##     at the cold" line lands in NIM with a Mother-cadenced
##     extension that the CEN/MI versions do not carry.
##   - The cold-feet beat itself, the kettle, the dishwasher,
##     the laundry, the calendar — all branch-neutral. Sunday-
##     evening interior is the same room across all three
##     Mothers.
##
## Why here in the arc:
##   - NIM Ch 3 (L1) was the therapist; Ch 4 (L2) was the
##     journal. None of those is the protagonist alone with
##     the Caretaker on a Sunday with nothing to do. Per parity
##     audit P-1 + P-4, this chapter lets a late-Act-II NIM
##     player nudge `permission` toward the exile gate and
##     provides the Caretaker re-ASK that A2 names as the
##     canonical permission-accumulation move.
##   - Primes Act III's `cancel_the_call` (Sunday → the
##     Wednesday call).
##
## Craft discipline:
##   - No new NPCs. No new flashbacks. (A8.3 contract.)
##   - Body sensations specific, not generic.
##   - The Caretaker's NIM register: scanning, anticipating,
##     pre-empting public discourse. Match the threat-scanner
##     established in a1c1_nim and a1c2_nim.
##   - "the cold" is family-lexicon; gloss before the first
##     weighted use per clarity.md rule 1. Same gloss as
##     CEN/MI.
##   - Length budget: ~150 lines.
##
## State contract (matches the a2c8_nim_* beats in
## tests/e2e/beats.py):
##   Caretaker re-ASK path: +permission, +self_trust,
##     -critic_volume; part trust_in_self up; part intensity
##     down; consented_for_exile becomes True (A2: ASK on a
##     Manager sets consent).
##   Body-cold path: +interoception, small +presence, no
##     critic spike.
##   Skip-the-noticing path: +critic_volume, -self_trust, no
##     permission.
##
## Recognition: at most one PART_REGISTER_IDENTIFIED on the
## ASK path; one REFLECTION_COMPLETED at chapter close via
## the feeling wheel. Per A8.3, no SAT_WITH_EXILE here — that
## is reserved for the exile-approach scene (a2c2_nim).

label a2c8_nim_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c8_nim", False):
        centered "Chapter Eleven — Act II (continued, NIM branch)\n\nA quiet Sunday-evening interior scene. No sensitive content beyond a small body-cold beat and a negotiation with a part of you."
        $ chapter_notice_shown["a2c8_nim"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c8_nim_skipped

    scene black
    with dissolve

    e "Sunday. The kind of Sunday that happens after a Saturday that went well."

    e "The flat is quiet. The dishwasher is on its second cycle of the weekend. The laundry on the chair is folded; the laundry in the basket is not, but it is the basket-laundry's turn next weekend, and you have made peace with that."

    e "You sit at the kitchen table. The week ahead is on the laptop, in calendar form. Tuesday has a deadline. Wednesday has the call with your mother that you have not yet decided to make or to not make."

    ## A small competency beat. The inbox is zero. The Caretaker is
    ## satisfied, in its way. The body is not.
    e "You answered the last unread email twenty minutes ago. The inbox is at zero. You closed the laptop and then opened it again, because the closing did not produce the thing the closing was supposed to produce."

    ## NIM Caretaker register: threat-scanner / discourse-monitor.
    ## The NIM Caretaker tracks not Mother's mood (MI) or her
    ## anger (CEN) but what gets *said* about the protagonist —
    ## who heard it, who else might hear it, what room is next.
    caretaker_voice "We are ahead. We are, for the first time this month, ahead. There has not been an aunt-email this week. No one has called to tell you what was said."

    e "The Caretaker is not lying. You are ahead. The week is set. Tuesday is doable. The grocery list is on the fridge. There has not been an aunt-email."

    pause 1.0

    ## In-character gloss for "the cold" before its weighted use,
    ## per clarity.md rule 1. Branch-neutral — Sunday-evening
    ## body-temperature signal works the same across all three
    ## branches; the cold is in the body, not in the branch.
    e "There is a thing your feet do, on Sunday evenings, that you have, at various points in your life, called several different things. The body version of it is: cold. The feeling version of it is: a kind of small dread that has nothing in particular to be about."

    e "The cold is here. The cold has been here, low and even, since about three in the afternoon."

    menu:
        "ask the Caretaker what the rush is for":
            jump a2c8_nim_ask_caretaker
        "notice the cold; just notice":
            jump a2c8_nim_notice_cold
        "open the laptop again; there is always one more thing":
            jump a2c8_nim_skip_noticing


label a2c8_nim_ask_caretaker:
    scene black

    e "You sit with the Caretaker for a moment. You ask the question you have been learning to ask."

    ## The full negotiation screen. Caretaker is a Manager, so an
    ## ASK here sets `consented_for_exile = True` (per
    ## parts.py::_ask) and raises permission +5 pre-amplification.
    ## Same canonical Sunday-evening interior-work move as CEN/MI.
    caretaker_voice "We are ahead. We should be making sure we stay ahead. We should be thinking about which dinners are this week. Whose table she sits at. Who would call you if she said something."

    $ intervention = renpy.call_screen(
        "negotiate",
        part_name="caretaker",
        opening_line="We should be thinking about which dinners are this week. Whose table she sits at. Who would call you if she said something.",
    )
    if intervention is None:
        $ intervention = ("ask", "caretaker")
    $ response_key = pp_intervene(intervention[0], intervention[1])

    if response_key == "caretaker_asked_intent":
        ## NIM Caretaker's deepest stated intent: pre-empting
        ## public discourse. The NIM Caretaker has been doing
        ## this since the dining room with six adults at age
        ## eleven, when laughter was the texture of the
        ## protagonist being talked about while sitting at the
        ## table.
        caretaker_voice "I am trying to make sure no one is hearing it about you when you do not yet know they are. I am trying to make sure you do not walk into a room where the room already has a story."
        e "The Caretaker says it the way the Caretaker says these things — without self-pity, the way a part of you describes work it has been doing since before you had words for it."
        e "You notice that the sentence is older than this Sunday. The sentence is older than your job. The sentence is older than Sam."
        $ reco_credit("part_register_identified", "a2c8_nim_caretaker_register")
    elif response_key == "caretaker_listened_to":
        caretaker_voice "Yeah. Yeah."
        e "The Caretaker shifts weight, in the way a part of you shifts weight when it has not been asked to leave but has been asked to sit down."
    elif response_key == "caretaker_deferred_to":
        caretaker_voice "Good. Who hears matters."
        e "You let the Caretaker keep the wheel. Who hears will, in fact, matter; the Caretaker is not wrong about that."
    elif response_key == "caretaker_disagreed_with":
        caretaker_voice "Fine. We will see."
        e "The Caretaker is sceptical, in the way of a part of you that has been right before."
    elif response_key == "caretaker_overridden":
        caretaker_voice "…"
        e "You closed the calendar over the Caretaker's small objection. The Caretaker has its arms crossed now. It will be back."
    else:
        caretaker_voice "Hm."

    jump a2c8_nim_after_negotiate


label a2c8_nim_notice_cold:
    scene black

    e "You do not move. You let your attention go to your feet, which are, indeed, cold."

    e "The cold is in the soles, mostly. The arches are warmer than the soles, which is information you did not expect to have."

    e "Your hands are the temperature of your hands. Your face is the temperature of your face. The cold is foot-shaped tonight."

    $ rr_delta("interoception", +6)
    $ rr_delta("presence", +4)
    $ rr_delta("regulation", +3)

    pause 1.0

    e "You do not name what the cold is for. You note that it is here."

    flame "noticing where the cold is, on a sunday, is not nothing. it is a specific noticing."

    jump a2c8_nim_after_negotiate


label a2c8_nim_skip_noticing:
    scene black

    e "You open the laptop. You re-open the calendar. You add a note to Tuesday that does not need to be added."

    e "The cold goes on being cold under the table. You go on not-noticing it. The not-noticing takes a small, ongoing amount of attention you do not register as attention."

    $ rr_delta("critic_volume", +5)
    $ rr_delta("self_trust", -3)
    $ rr_delta("energy", -3)

    ## NIM Critic register: borrows Mother's specific cadences
    ## per docs/continuity.md:556-559. The base accusation
    ## ("you should have looked at the cold") gets a Mother-
    ## cadenced extension, in the shape of a1c2_nim:177 broken-
    ## off slur and a2c1_nim:219 flat-affect "you always."
    critic_voice "You should have looked at the cold. You always do this. This is what I always mean when I say you are—"

    e "The Critic is half-right. The Critic is also doing what the Critic does, which is arrive late to a moment you could have had with less of it. The cadence the Critic is wearing is not the Critic's."

    jump a2c8_nim_after_negotiate


label a2c8_nim_after_negotiate:
    scene black
    with fade

    ## Whichever path was taken, the chapter closes the same way:
    ## the week is still queued; the body is still the body;
    ## nothing "resolves." The protagonist has had a small
    ## Sunday. That is the whole shape.
    e "You stand up. You put the kettle on. The kettle takes the time the kettle always takes."

    e "Wednesday is still on the calendar. Tuesday is still on the calendar. The cold is still in your feet, or it isn't, depending on what you did."

    e "It is the kind of evening you used to walk through without registering, on the way to a Monday that would also not register."

    flame "sundays are the days the noticing is hardest, because nothing in particular is asking for it. you noticed something, or you didn't. either way, the noticing is the thing."

    ## Chapter-end reflection. Recognition source.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c8_nim_feeling")

    menu:
        "continue to Act III":
            jump act3_dispatcher
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c8_nim_skipped:
    scene black
    centered "Chapter Eleven (NIM variant) was skipped."
    pause 1.5
    e "It was a Sunday. You did or did not notice the cold in your feet. The week stayed queued either way."
    ## Modest equivalent gain so a skipper does not arrive at
    ## Act III in an inconsistent state. Mirrors a2c8.rpy and
    ## a2c8_mi.rpy skipped paths.
    $ rr_delta("regulation", +3)
    $ rr_delta("interoception", +2)

    menu:
        "continue to Act III":
            jump act3_dispatcher
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
