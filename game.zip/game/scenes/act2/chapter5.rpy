## scenes/act2/chapter5.rpy — the dinner with Sam
##
## Scene type: Ordinary-week / Relationship (PRD §4.8). Sam is the
## named partner (see characters.rpy). This is Sam's first direct
## scene; Act III's `tell_r_no` is a second Sam scene that references
## the history this one establishes.
##
## Exercises the full gated-menu pattern with four distinct outcome
## branches: i_missed_you, stay_quiet, ask_about_day, confront,
## fight_the_ache. The last two use refuse_on_block=True so the
## fawn/numb-out parts can speak instead of the action firing.
##
## Source: the authoring-time YAML spec at sam_dinner_choices.yaml.
## Scene-authored directly (YAML lives as human-readable source of
## truth for the choice inventory).
##
## Writing discipline:
##   - Sam is a person the protagonist has been with long enough that
##     small talk has specific shapes. Write the familiar tempo.
##   - The "ache" fight_the_ache references is low-grade dissociation,
##     not a flashback. Don't stage-manage it.
##   - Per A7: successful confront still ends with a critic spike.
##     Don't soften.

label a2c5_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c5", False):
        centered "Chapter Eight — Act II (continued)\n\nA quiet dinner scene with Sam, the partner. No sensitive content beyond adult dialogue about intimacy, routine, and one archived email."
        $ chapter_notice_shown["a2c5"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c5_skipped

    scene black
    with dissolve

    e "It is Thursday. Sam is the person you have been with for years and have not lived with for any of them — that arrangement is one of the deliberate things between you, and you are not, mostly, planning to talk about it tonight."

    e "The arrangement is the one you both call {i}how we do this{/i}. Not a stage. Sam likes their own apartment; you like the one space in your life that is not asking anything of you."

    e "Sam picked the restaurant. Sam always picks the restaurant, a fact you both find mildly amusing and mildly revealing."

    e "The restaurant is small. The table is small. The menu is on a clipboard. You have ordered the thing you always order here; so has Sam"

    sam "You look a little far away tonight."

    e "Sam is not wrong. Sam is rarely wrong about this."

    e "The archived email from your aunt is still archived. You have not mentioned it. You are not sure whether Sam knows and is waiting, or does not know and should."

    call screen a2c5_dinner_menu

    if _return == "i_missed_you":
        jump a2c5_i_missed_you
    elif _return == "stay_quiet":
        jump a2c5_stay_quiet
    elif _return == "ask_about_day":
        jump a2c5_ask_about_day
    elif _return == "confront":
        jump a2c5_confront
    elif _return == "confront_refused":
        caretaker_voice "Not over dinner. Not in a restaurant. Not while the waiter is three tables away."
        e "You do not confront. You reach for the bread basket, which does not need reaching for."
        jump a2c5_stay_quiet
    elif _return == "fight_the_ache":
        jump a2c5_fight_the_ache
    elif _return == "fight_the_ache_refused":
        firefighter_voice "Don't. There is nothing there. Look — there is nothing there."
        e "You look. You agree with the part of you that keeps agreeing. There is nothing there."
        jump a2c5_stay_quiet
    else:
        jump a2c5_stay_quiet


screen a2c5_dinner_menu():
    tag menu

    $ c_missed = cc_eval(
        "i_missed_you",
        "I missed you",
        guard_keys=("connection",),
        npc="sam",
    )
    $ c_quiet = cc_eval(
        "stay_quiet",
        "stay quiet and finish the plate",
        guard_keys=(),
    )
    $ c_ask = cc_eval(
        "ask_about_day",
        "ask about their day",
        guard_keys=(),
    )
    $ c_confront = cc_eval(
        "confront",
        "say what happened with the email",
        guard_keys=("permission", "connection"),
        npc="sam",
        refuse_on_block=True,
    )
    $ c_fight = cc_eval(
        "fight_the_ache",
        "push through the ache; there's nothing there",
        guard_keys=("not_dissociative",),
        refuse_on_block=True,
    )

    frame:
        xalign 0.5
        yalign 0.5
        xpadding 28
        ypadding 28
        xmaximum 780

        vbox:
            spacing 10
            text "What do you say?" size 22
            use gated_choice_row(c_missed, Return("i_missed_you"))
            use gated_choice_row(c_quiet, Return("stay_quiet"))
            use gated_choice_row(c_ask, Return("ask_about_day"))
            use gated_choice_row(c_confront, Return("confront"))
            use gated_choice_row(c_fight, Return("fight_the_ache"))
            use tooltip_footer


label a2c5_i_missed_you:
    scene black
    with fade
    e "You say it without preface. \"I missed you.\""

    sam "I'm here."

    e "Sam is here. The sentence does not fix what you were missing — the thing you were missing is not Sam, exactly — but it lands."

    ## Per-NPC connection rise; safe scene.
    $ rr_npc_delta("sam", +7, safe=True)
    $ rr_delta("self_trust", +3)
    $ rr_delta("presence", +3)

    sam "You want to tell me what's been off?"

    menu:
        "say: not tonight. thank you for asking.":
            e "You say what you said."
            $ rr_delta("self_trust", +4)
            $ rr_npc_delta("sam", +3, safe=True)
            sam "Okay. I'm around."

        "say: I don't know what's been off.":
            e "You say it and you notice, as you say it, that you do know. You say it anyway."
            $ rr_delta("critic_volume", +3)
            $ rr_delta("presence", +2)

        "say: there is a thing. I'm not ready.":
            e "You say it. It is a specific sentence. It is the first time you have been ahead of the sentence on a Thursday at this restaurant."
            $ rr_delta("self_trust", +6)
            $ rr_delta("permission", +3)
            $ reco_credit("part_register_identified", "a2c5_naming_the_thing_before_telling_it")
            sam "Okay."

    $ act2c5_outcome = "i_missed_you"
    jump a2c5_close


label a2c5_stay_quiet:
    scene black
    with fade
    e "You stay quiet. You finish the plate. The plate is fine."

    e "Sam lets the quiet hold. Sam is good at this, has been for years, a specific kind of good-at-this that means Sam will not press."

    $ rr_npc_delta("sam", +1, safe=True)  # still a safe scene
    $ rr_delta("social_battery", -4)
    $ rr_delta("critic_volume", +3)

    critic_voice "You should have said something. The space is right there."

    e "The Critic is saying something that is half-right. The space is right there. You have not used it."

    $ act2c5_outcome = "stay_quiet"
    jump a2c5_close


label a2c5_ask_about_day:
    scene black
    e "\"How was the meeting this morning?\""

    sam "Fine. The new PM is still mostly nodding. Wait til week three."

    e "Sam tells you about the week. You follow most of it. You miss a beat halfway through and Sam notices and goes back."

    $ rr_npc_delta("sam", +3, safe=True)
    $ rr_delta("social_battery", -2)
    $ rr_delta("presence", -2)

    sam "Where did you go just then?"

    menu:
        "say: sorry — here now":
            e "You say sorry. You say here now. Sam does not push."
            $ rr_delta("self_trust", -2)
            $ rr_delta("critic_volume", +4)
        "say: I was thinking about the email from my aunt":
            e "Sam puts the fork down. The restaurant gets slightly louder around the specific quiet at your table."
            $ rr_delta("self_trust", +6)
            $ rr_delta("permission", +3)
            $ rr_npc_delta("sam", +5, safe=True)
            $ reco_credit("reflection_completed", "a2c5_mentioned_the_email")

    $ act2c5_outcome = "ask_about_day"
    jump a2c5_close


label a2c5_confront:
    scene black
    with fade
    e "You push the plate an inch forward. You do not look up from the plate."

    e "\"There was an email from my aunt. About my mother. I archived it on Tuesday.\""

    e "Your aunt knew Mother as a younger woman than you have ever known her. The aunt's emails come from someone who has been watching the same person for longer than you have been alive. You do not, mostly, know what to do with that kind of long view."

    pause 1.0

    sam "Oh."

    pause 1.0

    e "Sam is not a person who reflexively says the right thing in restaurants. Sam is, however, a person who waits for the second sentence."

    menu:
        "say: I don't know what to do with it.":
            e "You say it. It is the truest sentence you have said out loud this week."
            sam "We can look at it at home, if you want. Or not. Whatever you need."
            $ rr_delta("self_trust", +8)
            $ rr_delta("permission", +4)
            $ rr_npc_delta("sam", +8, safe=True)

        "say: I don't know if I want to do anything with it.":
            sam "Okay."
            $ rr_delta("self_trust", +5)
            $ rr_npc_delta("sam", +5, safe=True)

    ## ACoA per A7: the critic arrives even when the confront lands.
    critic_voice "You shouldn't have made this Sam's problem. The restaurant. The plate. You picked the wrong moment."

    $ rr_delta("critic_volume", +6)

    e "The Critic is saying a thing that is not wholly true and not wholly false. You notice it arriving on schedule."

    $ reco_credit("part_register_identified", "a2c5_confront_critic_timing")
    $ reco_credit("reflection_completed", "a2c5_named_email_to_r")

    $ act2c5_outcome = "confronted"
    jump a2c5_close


label a2c5_fight_the_ache:
    scene black

    ## First in-game use of "the ache" as a family idiom for the
    ## low-grade dissociative pull. Per .claude/rules/clarity.md
    ## rule 1 (define in-family idioms on first use, in-character),
    ## a one-line gloss before the choice consequence so a reader
    ## who doesn't share the pattern lands the term.
    e "There is an ache in the centre of you. Not pain, exactly. More like a missing — the kind that has been there long enough you stopped naming it."

    e "You push through. \"No, I'm fine. Tell me about the thing with the PM.\""

    e "Sam picks it up. You listen. You keep listening. You keep hearing words, but somewhere after the second sentence you are not really in the restaurant anymore."

    e "Your hand cuts into the food on the plate. The cutting is a thing your hand is doing."

    $ rr_delta("presence", -6)
    $ rr_delta("flashback_pressure", +8)
    $ rr_delta("interoception", -5)
    $ rr_delta("social_battery", -6)

    firefighter_voice "Nothing here. Nothing here. Keep going."

    e "You keep going. The Firefighter keeps the script running. Sam finishes the PM story. Sam eats. You nod at the right places."

    $ act2c5_outcome = "fought_the_ache"
    jump a2c5_close


label a2c5_close:
    scene black
    with fade

    e "After the restaurant, there is the walk home. Sam does not say much. You do not either."

    e "Sam reaches for your hand on the corner where you always cross. You take it."

    $ rr_npc_delta("sam", +2, safe=True)

    ## Chapter-end reflection.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c5_feeling")

    menu:
        "continue to Chapter Nine":
            jump a2c6_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c5_skipped:
    scene black
    centered "Chapter Eight was skipped."
    pause 1.5
    e "A Thursday passed. There was a restaurant. There was a walk home. Sam held your hand."
    $ rr_npc_delta("sam", +1, safe=True)

    menu:
        "continue to Chapter Nine":
            jump a2c6_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
