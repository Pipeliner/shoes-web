## screens/choice.rpy — choice-screen override for visibly-unavailable
## options with tooltips.
##
## Per .claude/rules/renpy-screens.md and PRD §6.4:
##   - `sensitive=False` blocks focus, which breaks tooltips (issue #1591).
##   - Override `screen choice` so unavailable options render as `textbutton`
##     with `action NullAction()`, `sensitive True`, `hovered`/`unhovered`
##     that set `current_tooltip` to the reason-token long string.
##
## Reason strings come from ReasonToken via logic/gates.py. Do not
## hand-author them here.
##
## Usage in scenes:
##   menu:
##       set gated_menu  # see below
##       "stay with it" (choice_id="stay"):
##           ...
##       "push through" (choice_id="push", guards=("not_enough_rest",), refuse_on_block=True):
##           ...
##
## The `gated_menu` init block hooks into Ren'Py's `menu` mechanics. In
## practice we write scene-specific choice screens (e.g., `screen a1c1_menu`)
## using the helper below, because Ren'Py's built-in menu doesn't natively
## accept per-item kwargs. The `a1c1_menu` example is in scenes/act1/chapter1.rpy.

init python:
    from logic.gates import (
        Choice,
        ChoiceAvailability,
        evaluate_choice,
        reason_short,
        reason_long,
    )

    def cc_eval(choice_id, label, guard_keys=(), npc=None,
                refuse_on_block=False, tags=()):
        """Convenience: build a Choice and evaluate it in one call.

        `tags` are carried into `GuardContext.tags` for guards that
        consult them (e.g. `recognition_for_scene` and
        `not_already_attempted` both read
        `requires_recognition:<scene_id>` tags).

        The live `recognition_ledger` is passed through automatically
        so Act III structural-change scenes gate on Recognition via
        the standard visibly-unavailable mechanic. The live
        `act3_outcomes` keyset is passed as `attempted_scenes` so the
        `not_already_attempted` guard surfaces SCENE_ALREADY_DONE for
        one-shot scenes that have already run this playthrough.
        """
        c = Choice(
            id=choice_id,
            label=label,
            guard_keys=tuple(guard_keys),
            npc=npc,
            refuse_on_block=refuse_on_block,
            tags=tuple(tags),
        )
        return evaluate_choice(
            c,
            resource_snapshot,
            recognition_ledger,
            attempted_scenes=frozenset(act3_outcomes.keys()),
        )


## Shared choice-row screen. Use this inside a scene-specific menu screen
## to render a single gated choice row. Caller supplies:
##   gated: the GatedChoice
##   on_click: a Return() or similar action for AVAILABLE / VISIBLE_AND_REFUSED
screen gated_choice_row(gated, on_click):
    $ avail = gated.availability
    if avail == ChoiceAvailability.AVAILABLE:
        textbutton gated.choice.label:
            action on_click
            xmaximum 800
    elif avail == ChoiceAvailability.VISIBLE_AND_REFUSED:
        textbutton gated.choice.label:
            action on_click
            sensitive True
            hovered SetVariable("current_tooltip", gated.long or "")
            unhovered SetVariable("current_tooltip", "")
            text_color "#888"
            xmaximum 800
    else:  # VISIBLY_UNAVAILABLE
        textbutton gated.choice.label:
            action NullAction()
            sensitive True
            hovered SetVariable("current_tooltip", gated.long or "")
            unhovered SetVariable("current_tooltip", "")
            text_color "#555"
            xmaximum 800


## Deprecated as of 0.1.18-13. Kept as a no-op so existing
## `use tooltip_footer` callsites in scene-specific menus continue to
## compile; new code should not call it.
##
## Why: when the inner `if current_tooltip:` toggled, the conditional
## frame appeared/disappeared inside the caller's vbox, which reflowed
## the vbox, which moved the button under the cursor, which fired
## `unhovered` → `current_tooltip = ""`, which removed the frame, which
## moved the button back, which fired `hovered` again — a feedback loop
## that produced violent blinking on hover. The global `tooltip_overlay`
## (screens/tooltip.rpy) renders the same string at absolute screen
## position with zorder 100, so it never reflows the menu. Every scene
## that uses gated choices already calls `show screen tooltip_overlay`,
## so the inline footer is now redundant.
screen tooltip_footer():
    pass


## screen choice(items) — override Ren'Py's default for `menu:` blocks.
## We add number-key shortcuts 1-9 (top row + numpad) so VN-keyboard
## players can pick options directly. Tab / Shift+Tab / arrow keys
## cycle (Ren'Py default for textbutton screens). Enter activates.
##
## Layout: positioning lives in `style choice_vbox`, not inline. The
## vbox is bottom-anchored so it grows upward as the menu lengthens —
## short menus hug the bottom of the screen, long menus (e.g.
## `branch_select` with four wrapping captions) extend up the screen
## without overflowing the bottom edge. An earlier inline `ypos 540`
## hard-anchored the top of the vbox, which clipped any menu whose
## rendered height exceeded ~180 px (playtest 2026-04-26).
##
## Scene-specific choice screens (e.g. `screen a1c1_first_choice`,
## the negotiate screen, the reflection screens) are unrelated —
## they render via `gated_choice_row` and have their own focus model.
screen choice(items):
    style_prefix "choice"

    vbox:
        for i in items:
            textbutton i.caption action i.action

    ## Number-key shortcuts: 1-9 (top row + numpad) select directly.
    ## Skipped past nine items — no menu in the game has more than ~7.
    for index, entry in enumerate(items):
        if index < 9:
            key "K_%d" % (index + 1) action entry.action
            key "K_KP%d" % (index + 1) action entry.action

## Choice menu positioning (1280×720 design space).
##
##   ypos 1.0 yanchor 1.0 yoffset -gui.scale(20)
##     → vbox bottom = canvas bottom − 20 px gutter; vbox grows upward
##       as the menu lengthens. Screen-size-agnostic via the fractional
##       ypos and the gui.scale offset.
##   xpos gui.scale(80)
##     → 80 px left margin in the design space (~ 6 % of 1280).
##   xmaximum on the button forces wrap on long captions (branch_select
##     items run ~110 chars).
##
## Earlier `ypos 690 yanchor 1.0` was authored under a 720 px assumption
## but the project ran at 800×600 so the bottom 90 px sat offscreen —
## branch_select's 4 items wrapped to ~200 px and only the top 2 (CEN,
## MI) were visible (2026-04-30 playtest). The fix above is fractional
## and works at any screen size.
## Layout (bottom-left, screen-size-agnostic) is project-specific and
## stays inline. Colors and font / text-xalign / text-size flow
## through `gui.text_properties("choice_button")` so changing
## `gui.accent_color` (or any of the gui.choice_button_* defines) in
## game/gui.rpy propagates into the menu without touching this file.
style choice_vbox is vbox:
    xpos gui.scale(80)
    yanchor 1.0
    ypos 1.0
    yoffset -gui.scale(20)
    spacing gui.scale(8)
style choice_button is button:
    properties gui.button_properties("choice_button")
    xmaximum gui.scale(900)
style choice_button_text is button_text:
    properties gui.text_properties("choice_button")
