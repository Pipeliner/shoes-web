"""Option gating.

The central mechanic (PRD §4.4): choices render in four states — available,
visibly-unavailable-with-reason, visible-and-refused, hidden. Hidden is
reserved for untriggered content; we do not hide the sensible thing.

This module exports:
  - `ReasonToken` enum + short/long UI strings
  - `Choice` dataclass with guards
  - `evaluate_choice` returning a `GatedChoice` the screen layer renders

Everything is pure and pickle-safe. Guards are predicates resolved by name
from `GUARD_DISPATCH` so they serialise (no lambdas on `Choice`).
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Callable, Optional

from game.logic.recognition import RecognitionLedger
from game.logic.resources import Resource, ResourceSnapshot
from game.logic.states import (
    ComputedState,
    dissociative_spell,
    fawn_active_for,
    flooded,
    grounded,
)


# ---------------------------------------------------------------------------
# Reason-token enum + UI strings
# ---------------------------------------------------------------------------


class ReasonToken(str, enum.Enum):
    NOT_ENOUGH_REST = "not_enough_rest"
    PART_VETO_CARETAKER = "part_veto_caretaker"
    PART_VETO_CRITIC = "part_veto_critic"
    PART_VETO_FIREFIGHTER = "part_veto_firefighter"
    PERMISSION_TOO_LOW = "permission_too_low"
    TRUST_TOO_LOW = "trust_too_low"
    CONNECTION_TOO_LOW = "connection_too_low"
    STATE_FLOODED = "state_flooded"
    STATE_DISSOCIATIVE = "state_dissociative"
    FAWN_ACTIVE = "fawn_active"
    CRITIC_UNRESPONSIVE_TO_FORCE = "critic_unresponsive_to_force"
    # Added in 0.1.7 for Act III structural-change scenes per PRD §4.7.
    # The scene is visible; the protagonist has not yet noticed enough
    # inside to attempt it. See docs/prd-amendments.md §A9.
    RECOGNITION_TOO_LOW = "recognition_too_low"
    # Added 0.1.18-15 for one-shot scenes (Act III structural-change
    # trio): once attempted the scene records an outcome and the
    # menu surface marks it visibly-unavailable rather than re-offering.
    # The in-fiction read is "you have already done this thing;
    # doing it twice would not be the same thing."
    SCENE_ALREADY_DONE = "scene_already_done"
    # Added 0.1.18-21 for the negotiate screen's override option.
    # Override is conditional on `override_available()` (parts.py),
    # which requires permission AND self_trust both above thresholds.
    # Closes F4 from docs/prd-compliance-audit-0.1.18-17 — the
    # tooltip string at parts.rpy:88-90 was hand-authored, violating
    # CLAUDE.md non-negotiable rule 3 (reason tokens come from the
    # enum). The string now lives here; parts.rpy reads it via
    # reason_long(ReasonToken.OVERRIDE_NOT_READY).
    OVERRIDE_NOT_READY = "override_not_ready"


# Short form goes on the hover chip. Long form goes in the Discussion Guide
# and on an expanded hover (e.g., shift-held) per PRD §7.4.
# The long strings are the clinician-reviewed copy (§10 budget).
_REASON_STRINGS: dict[ReasonToken, tuple[str, str]] = {
    ReasonToken.NOT_ENOUGH_REST: (
        "too tired",
        "you are too tired; this choice needs more rest than you have right now.",
    ),
    ReasonToken.PART_VETO_CARETAKER: (
        "a part of you won't let you",
        "a part of you — the one that has kept you safe by taking care of "
        "others first — is not ready to let you do this.",
    ),
    ReasonToken.PART_VETO_CRITIC: (
        "a voice gets in the way",
        "a voice in your head will not let this be simple right now. It is "
        "trying to protect you in the only way it knows.",
    ),
    ReasonToken.PART_VETO_FIREFIGHTER: (
        "something flinches",
        "something inside you flinches before the thought lands. A part of "
        "you is already reaching for a way out.",
    ),
    ReasonToken.PERMISSION_TOO_LOW: (
        "not yet",
        "something inside has not given permission. It might, later.",
    ),
    ReasonToken.TRUST_TOO_LOW: (
        "you don't trust yourself with this",
        "you do not trust yourself with this yet. That is information, not a "
        "judgment.",
    ),
    ReasonToken.CONNECTION_TOO_LOW: (
        "not close enough",
        "the relationship isn't at a place where this lands. You can feel it.",
    ),
    ReasonToken.STATE_FLOODED: (
        "too much at once",
        "there is too much coming in to think clearly. This choice requires "
        "a clarity you do not have right now.",
    ),
    ReasonToken.STATE_DISSOCIATIVE: (
        "you're not all the way here",
        "you are not all the way here right now. This choice requires being "
        "in the room.",
    ),
    ReasonToken.FAWN_ACTIVE: (
        "a part of you will not risk the relationship right now",
        "a part of you will not risk the relationship right now. It has kept "
        "you safe by not risking relationships.",
    ),
    ReasonToken.CRITIC_UNRESPONSIVE_TO_FORCE: (
        "the critic does not respond to force",
        "the critic does not respond to force. Naming it, thanking it for "
        "trying to protect you, or fact-checking it will reach it. Fighting "
        "it will not.",
    ),
    ReasonToken.RECOGNITION_TOO_LOW: (
        "not yet ready",
        "you have not yet noticed enough, inside, to attempt this. Stay "
        "with what you have been seeing. It grows.",
    ),
    ReasonToken.SCENE_ALREADY_DONE: (
        "already done",
        "you have already done this thing once. Doing it again would not "
        "be the same thing; some moments only happen once.",
    ),
    ReasonToken.OVERRIDE_NOT_READY: (
        "override not yet available",
        "overriding a part of you requires high permission and high "
        "self-trust. Both grow as you listen, ask, and notice.",
    ),
}


def reason_short(token: ReasonToken) -> str:
    return _REASON_STRINGS[token][0]


def reason_long(token: ReasonToken) -> str:
    return _REASON_STRINGS[token][1]


def reason_strings(token: ReasonToken) -> tuple[str, str]:
    return _REASON_STRINGS[token]


# ---------------------------------------------------------------------------
# Guards — module-level predicates resolved by name (pickle-safe)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class GuardContext:
    """Everything a guard needs to evaluate.

    `npc` is the NPC this choice targets (for Connection gates and FAWN_ACTIVE).
    `tags` is the choice's requirement tags (e.g., "requires_regulation" or
    "requires_recognition:scene_id").
    `recognition_ledger` is optional; only the `recognition_for_scene`
    guard reads it. Defaulting to None means guards that predate this
    field (all of them) remain unaffected.
    """

    snapshot: ResourceSnapshot
    npc: Optional[str] = None
    tags: frozenset[str] = field(default_factory=frozenset)
    recognition_ledger: Optional[RecognitionLedger] = None
    # Set of scene_ids that have already been attempted in this
    # playthrough. Used by `_guard_not_already_attempted` to mark
    # one-shot Act III structural-change scenes visibly-unavailable
    # after their first run. Default empty — guards that don't read
    # this field remain unaffected.
    attempted_scenes: frozenset[str] = field(default_factory=frozenset)


# A guard returns None if the choice is allowed, or a ReasonToken if blocked.
Guard = Callable[[GuardContext], Optional[ReasonToken]]


# Thresholds for named guards.
REST_MIN = 35  # energy below this blocks rest-sensitive choices
PERMISSION_MIN_DEFAULT = 50
# Exile-approach threshold. Originally 70; dropped to 65 after E2E
# playthroughs showed the reactive-pair cascade (critic -> permission
# inverse) eats enough gain that 70 requires more interior-work beats
# than the authored scenes support. 65 still feels earned (mid-Stretched
# band) while being reachable via realistic Act I + Act II + between-
# scene interior work. See tests/e2e/paths.py::PATH_CYCLE_WITNESSED for
# the canonical reaching path.
PERMISSION_MIN_EXILE = 65
TRUST_MIN = 40
CONNECTION_MIN = 35


def _guard_not_enough_rest(ctx: GuardContext) -> Optional[ReasonToken]:
    if ctx.snapshot.get(Resource.ENERGY) < REST_MIN:
        return ReasonToken.NOT_ENOUGH_REST
    return None


def _guard_permission(ctx: GuardContext) -> Optional[ReasonToken]:
    if ctx.snapshot.get(Resource.PERMISSION) < PERMISSION_MIN_DEFAULT:
        return ReasonToken.PERMISSION_TOO_LOW
    return None


def _guard_permission_exile(ctx: GuardContext) -> Optional[ReasonToken]:
    if ctx.snapshot.get(Resource.PERMISSION) < PERMISSION_MIN_EXILE:
        return ReasonToken.PERMISSION_TOO_LOW
    return None


def _guard_trust(ctx: GuardContext) -> Optional[ReasonToken]:
    if ctx.snapshot.get(Resource.SELF_TRUST) < TRUST_MIN:
        return ReasonToken.TRUST_TOO_LOW
    return None


def _guard_connection(ctx: GuardContext) -> Optional[ReasonToken]:
    if ctx.npc is None:
        return None
    if ctx.snapshot.connection_with(ctx.npc) < CONNECTION_MIN:
        return ReasonToken.CONNECTION_TOO_LOW
    return None


def _guard_not_flooded(ctx: GuardContext) -> Optional[ReasonToken]:
    if flooded(ctx.snapshot):
        return ReasonToken.STATE_FLOODED
    return None


def _guard_not_dissociative(ctx: GuardContext) -> Optional[ReasonToken]:
    if dissociative_spell(ctx.snapshot):
        return ReasonToken.STATE_DISSOCIATIVE
    return None


def _guard_not_fawn_active(ctx: GuardContext) -> Optional[ReasonToken]:
    if ctx.npc is None:
        return None
    # Require that the NPC has an established connection in the
    # snapshot. fawn_active_for() defaults missing NPCs to connection
    # 30, which trips the < MODERATE_LOW (40) check — but a player who
    # has not yet been seeded with this NPC's connection (true on MI
    # and NIM Act II for Lena / Sam / Ben / Mother) cannot meaningfully
    # be fawning over a relationship that has not been established.
    # Without this check, the dispatcher's structural-change scenes
    # (tell_r_no, mention_the_childhood_thing, cancel_the_call) become
    # visibly-unavailable with FAWN_ACTIVE on MI/NIM whenever the
    # critic is elevated — which structurally locks the witnessed
    # ending on those branches. Surfaced by
    # docs/state-machine-audit-0.1.18-15.md C1.
    if ctx.npc not in ctx.snapshot.connection_per_npc:
        return None
    if fawn_active_for(ctx.snapshot, ctx.npc):
        return ReasonToken.FAWN_ACTIVE
    return None


def _guard_requires_grounded(ctx: GuardContext) -> Optional[ReasonToken]:
    if not grounded(ctx.snapshot):
        # Grounded failure could be flooded, dissociative, or just not-grounded.
        # Prefer the most specific reason token for UI.
        if flooded(ctx.snapshot):
            return ReasonToken.STATE_FLOODED
        if dissociative_spell(ctx.snapshot):
            return ReasonToken.STATE_DISSOCIATIVE
        return ReasonToken.PERMISSION_TOO_LOW
    return None


def _guard_force_on_critic(ctx: GuardContext) -> Optional[ReasonToken]:
    """Special guard for 'fight / silence the critic' pseudo-options. Always
    returns CRITIC_UNRESPONSIVE_TO_FORCE because negotiation, not defeat, is
    the rule (PRD §4.6)."""
    return ReasonToken.CRITIC_UNRESPONSIVE_TO_FORCE


# Tag prefix for scene-id-carrying tags read by recognition_for_scene.
RECOGNITION_TAG_PREFIX = "requires_recognition:"


def _guard_not_already_attempted(ctx: GuardContext) -> Optional[ReasonToken]:
    """Gate a choice on whether its scene has already been attempted.

    Reuses the `requires_recognition:<scene_id>` tag to identify the
    scene id (the tag is already on every Act III structural-change
    Choice for the Recognition gate). If the scene id appears in
    `ctx.attempted_scenes`, returns SCENE_ALREADY_DONE so the menu
    surface shows the option as visibly-unavailable.

    For one-shot Act III scenes (PRD §4.7); the menu loops back to
    the dispatcher after each attempt.
    """
    for tag in ctx.tags:
        if tag.startswith(RECOGNITION_TAG_PREFIX):
            scene_id = tag[len(RECOGNITION_TAG_PREFIX):]
            if scene_id in ctx.attempted_scenes:
                return ReasonToken.SCENE_ALREADY_DONE
    return None


def _guard_recognition_for_scene(ctx: GuardContext) -> Optional[ReasonToken]:
    """Gate a choice on Recognition ledger's `can_attempt(scene_id)`.

    Expects a tag of the form `requires_recognition:<scene_id>` in the
    Choice's tags. If the ledger is not supplied in the context, treat
    the choice as available (no gating) — keeps ledger-unaware scenes
    working.

    Used for Act III structural-change scenes (PRD §4.7, amendment A9).
    Multiple such tags on one Choice are allowed — any one failing
    returns RECOGNITION_TOO_LOW.
    """
    if ctx.recognition_ledger is None:
        return None
    for tag in ctx.tags:
        if tag.startswith(RECOGNITION_TAG_PREFIX):
            scene_id = tag[len(RECOGNITION_TAG_PREFIX):]
            if not ctx.recognition_ledger.can_attempt(scene_id):
                return ReasonToken.RECOGNITION_TOO_LOW
    return None


# Dispatch table — named guards, pickled by string key on `Choice`.
GUARD_DISPATCH: dict[str, Guard] = {
    "not_enough_rest": _guard_not_enough_rest,
    "permission": _guard_permission,
    "permission_exile": _guard_permission_exile,
    "trust": _guard_trust,
    "connection": _guard_connection,
    "not_flooded": _guard_not_flooded,
    "not_dissociative": _guard_not_dissociative,
    "not_fawn_active": _guard_not_fawn_active,
    "requires_grounded": _guard_requires_grounded,
    "force_on_critic": _guard_force_on_critic,
    "recognition_for_scene": _guard_recognition_for_scene,
    "not_already_attempted": _guard_not_already_attempted,
}


# ---------------------------------------------------------------------------
# Choice model and evaluator
# ---------------------------------------------------------------------------


class ChoiceAvailability(str, enum.Enum):
    """Four states of a choice (PRD §4.4). HIDDEN is untriggered content, not
    blocked — we never hide the sensible thing."""

    AVAILABLE = "available"
    VISIBLY_UNAVAILABLE = "visibly_unavailable"
    VISIBLE_AND_REFUSED = "visible_and_refused"
    HIDDEN = "hidden"


@dataclass(frozen=True)
class Choice:
    """Authoring-time choice. Pickle-safe: no lambdas; guards by name."""

    id: str
    label: str
    # Ordered list of guard keys. First guard that blocks wins (its reason
    # token is what the player sees).
    guard_keys: tuple[str, ...] = ()
    # If True, blocking fails to VISIBLE_AND_REFUSED rather than
    # VISIBLY_UNAVAILABLE. For scenes where the player can click the choice
    # and the part speaks instead.
    refuse_on_block: bool = False
    # NPC this choice targets (feeds GuardContext).
    npc: Optional[str] = None
    # Requirement tags. Carried into GuardContext.tags for guards that want them.
    tags: tuple[str, ...] = ()


@dataclass(frozen=True)
class GatedChoice:
    """Evaluation result. `reason` is None when availability is AVAILABLE."""

    choice: Choice
    availability: ChoiceAvailability
    reason: Optional[ReasonToken] = None

    @property
    def short(self) -> Optional[str]:
        return reason_short(self.reason) if self.reason else None

    @property
    def long(self) -> Optional[str]:
        return reason_long(self.reason) if self.reason else None


def evaluate_choice(
    choice: Choice,
    snapshot: ResourceSnapshot,
    recognition_ledger: Optional[RecognitionLedger] = None,
    attempted_scenes: Optional[frozenset[str]] = None,
) -> GatedChoice:
    """Apply each guard in order. First blocker wins.

    If a choice has `refuse_on_block=True`, a blocked result becomes
    VISIBLE_AND_REFUSED — the player can click it; the part speaks.

    `recognition_ledger` is optional; supply it for Act III
    structural-change scenes that gate on Recognition. Omitting it
    leaves the `recognition_for_scene` guard inert (per its docstring).

    `attempted_scenes` is optional; supply it for the Act III dispatcher
    so scenes already attempted this playthrough surface as visibly-
    unavailable with SCENE_ALREADY_DONE. Omitting it leaves the
    `not_already_attempted` guard inert.
    """
    ctx = GuardContext(
        snapshot=snapshot,
        npc=choice.npc,
        tags=frozenset(choice.tags),
        recognition_ledger=recognition_ledger,
        attempted_scenes=(
            attempted_scenes if attempted_scenes is not None
            else frozenset()
        ),
    )
    for key in choice.guard_keys:
        guard = GUARD_DISPATCH[key]
        reason = guard(ctx)
        if reason is not None:
            availability = (
                ChoiceAvailability.VISIBLE_AND_REFUSED
                if choice.refuse_on_block
                else ChoiceAvailability.VISIBLY_UNAVAILABLE
            )
            return GatedChoice(choice=choice, availability=availability, reason=reason)
    return GatedChoice(choice=choice, availability=ChoiceAvailability.AVAILABLE)


def evaluate_set(
    choices: tuple[Choice, ...],
    snapshot: ResourceSnapshot,
    recognition_ledger: Optional[RecognitionLedger] = None,
    attempted_scenes: Optional[frozenset[str]] = None,
) -> tuple[GatedChoice, ...]:
    """Evaluate a whole choice set at once."""
    return tuple(
        evaluate_choice(c, snapshot, recognition_ledger, attempted_scenes)
        for c in choices
    )


__all__ = [
    "CONNECTION_MIN",
    "Choice",
    "ChoiceAvailability",
    "GatedChoice",
    "GUARD_DISPATCH",
    "GuardContext",
    "PERMISSION_MIN_DEFAULT",
    "PERMISSION_MIN_EXILE",
    "RECOGNITION_TAG_PREFIX",
    "REST_MIN",
    "ReasonToken",
    "TRUST_MIN",
    "evaluate_choice",
    "evaluate_set",
    "reason_long",
    "reason_short",
    "reason_strings",
]
