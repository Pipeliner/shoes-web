## scenes/act3/cancel_the_call.rpy — Act III structural-change scene.
##
## Per PRD §4.7: Recognition-gated structural-change scene that tests
## whether a resource change holds in the present. Scene id
## "cancel_the_call" has threshold 8 in ACT_III_STRUCTURAL_GATES —
## the lowest. A scene about cancelling a scheduled call with Mother.
##
## Craft discipline:
##   - Structural-change = *testing* whether it holds. Outcome is not
##     automatic. The protagonist tries.
##   - Both outcomes (cancelled / didn't) have residue visible.
##   - Per A7 (ACoA pattern): if the cancellation succeeds, the critic
##     still responds. Don't soften it.
##
## Scene-id tag: requires_recognition:cancel_the_call.
## Caller (dispatcher) is responsible for routing players here only
## when gate is approved.

label a3_cancel_the_call:
    scene black
    show screen tooltip_overlay

    e "Wednesday again. The calendar says seven PM. Your mother's name."

    e "You have not cancelled a call with your mother in fifteen years."

    e "You have said you had to go partway through; once, twice, five times. You have not cancelled one."

    pause 1.0

    e "Your phone is on the table. The call is in ninety minutes."

    ## The attempt — as a gated menu. The "send the cancellation"
    ## option is visibly-unavailable-ish depending on fawn_active.
    call screen a3_cancel_the_call_menu

    if _return == "send_now":
        jump a3_cancel_the_call_sent
    elif _return == "send_now_refused":
        ## refuse_on_block path — the fawn part speaks, cancellation
        ## doesn't happen.
        caretaker_voice "Not now. Not over a text. She'll think something is wrong."
        e "You set the phone down. The call is in eighty-seven minutes now."
        jump a3_cancel_the_call_not_sent
    elif _return == "draft":
        jump a3_cancel_the_call_draft
    else:
        jump a3_cancel_the_call_not_sent


screen a3_cancel_the_call_menu():
    tag menu
    $ c_send = cc_eval(
        "send_now",
        "send the text: 'mom, i can't tonight. i'll call you wednesday.'",
        guard_keys=("not_fawn_active",),
        npc="mother",
        refuse_on_block=True,
    )
    $ c_draft = cc_eval(
        "draft",
        "write the text; don't send it yet; think about it",
        guard_keys=(),
    )
    $ c_nothing = cc_eval(
        "nothing",
        "do nothing. the call will happen. it always does.",
        guard_keys=(),
    )

    frame:
        xalign 0.5
        yalign 0.5
        xpadding 28
        ypadding 28
        xmaximum 780

        vbox:
            spacing 10
            text "What do you do?" size 22
            use gated_choice_row(c_send, Return("send_now"))
            use gated_choice_row(c_draft, Return("draft"))
            use gated_choice_row(c_nothing, Return("nothing"))
            use tooltip_footer


label a3_cancel_the_call_sent:
    scene black
    with fade
    e "You press send. The message sits in the chat in that particular way a message sits when you are the one who just sent it."

    e "Your mother is typing."

    pause 1.0

    e "Your mother has stopped typing."

    pause 1.0

    e "Your mother is typing again."

    pause 1.0

    mother "ok. wednesday."

    e "That is all she writes."

    ## State effects: the boundary attempt succeeds. Per A7, the critic
    ## still responds — don't soften.
    $ rr_delta("self_trust", +8)
    $ rr_delta("permission", +4)
    $ rr_npc_delta("mother", -3, safe=False)

    critic_voice "You are going to pay for this on Wednesday."

    $ rr_delta("critic_volume", +6)

    e "The Critic is saying something that may or may not turn out to be true. You notice it is saying it."

    ## Credit Recognition — a structural change attempted AND landed.
    $ reco_credit("reflection_completed", "a3_cancel_the_call_succeeded")

    flame "you cancelled a call with your mother. that is a specific thing that has now happened."

    $ act3_outcomes["cancel_the_call"] ="sent"
    $ renpy.fix_rollback()
    jump a3_cancel_the_call_close


label a3_cancel_the_call_draft:
    scene black
    e "You write the text. You read it three times. You do not press send."

    e "It sits in the message composer for forty minutes."

    e "At six PM you delete the draft, unsent."

    $ rr_delta("self_trust", -3)
    $ rr_delta("critic_volume", +4)
    $ rr_delta("presence", +3)   # noticing is its own thing

    critic_voice "You never send them. You always draft and delete."

    e "The Critic is not wrong. The noticing of this is new, even if the drafting-and-deleting is old."

    ## Recognition credit is for the noticing, not the action.
    $ reco_credit("part_register_identified", "a3_cancel_draft_and_delete_pattern")

    $ act3_outcomes["cancel_the_call"] ="drafted"
    $ renpy.fix_rollback()
    jump a3_cancel_the_call_not_sent


label a3_cancel_the_call_not_sent:
    scene black
    with fade
    e "The call happens at seven. It lasts thirty-eight minutes. You do not remember most of it."

    $ rr_delta("presence", -8)
    $ rr_delta("flashback_pressure", +6)
    $ rr_delta("regulation", -4)

    e "After, you put the phone face-down. You sit for a while."

    flame "you did not cancel this week. that is information, not a verdict."

    if act3_outcomes.get("cancel_the_call") != "drafted":
        $ act3_outcomes["cancel_the_call"] ="not_sent"
        $ renpy.fix_rollback()
    jump a3_cancel_the_call_close


label a3_cancel_the_call_close:
    scene black
    with fade
    e "The phone goes back on the counter. The week continues."
    return
