## scenes/act2/chapter6_nim.rpy — movement practice (NIM variant).
##
## Mirrors the structural arc of CEN `chapter6.rpy` and MI
## `chapter6_mi.rpy` (one instructor NPC, three opener
## choices, mid-class noticing) but lands on an NIM-specific
## texture: the threat-scanner Caretaker reads the studio's
## people first, the body second. The studio is gentle but
## *socially-public*; seven people in a room is seven points
## of possible discussion. The threat-scanner does an
## inventory of who's there and who's near the door before
## the protagonist's body gets to be a body. Then, slowly,
## under the instructor's voice, the inventory loses
## interest.
##
## Where MI's a2c6 is about the *absence* of scanning (the
## stretch-watcher off-shift), NIM's is about the scanning
## *running* — and gradually quieting because the room
## doesn't reward it. The studio's contract — the instructor
## doesn't narrate, the class doesn't comment, no one watches
## anyone else — actively starves the threat-scanner.
##
## Per chapter6 craft discipline:
##   - No new flashbacks.
##   - No "healing" language.
##   - Specific body sensations.
##   - The class is "movement practice."
##   - No parts activation in the foreground (the threat-
##     scanner is *referenced as gradually quieting*, not
##     given the floor).
##
## State effects mirror CEN line-for-line; the simulator
## applies BRANCH_BIAS[NIM] (CRITIC_VOLUME ×1.3 worse,
## SOCIAL_BATTERY ×1.2 worse) on top.

label a2c6_nim_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c6_nim", False):
        centered "Chapter Nine — Act II (continued, NIM branch)\n\nA short movement-practice class scene. No sensitive content."
        $ chapter_notice_shown["a2c6_nim"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c6_nim_skipped

    scene black
    with dissolve

    e "Tuesday evening. The studio is above a cafe, up a flight of stairs that turns twice."

    e "You are here because someone you vaguely know said it was worth trying. You have been here five times. This is the sixth."

    e "The floor is wood. The windows are open. It is not quite warm yet."

    ## NIM-specific opening register: the threat-scanner does
    ## its room-inventory before the body gets to be a body.
    ## Per the craft discipline, the part is referenced (as
    ## starting to quiet), not given the floor.
    e "Seven other people in the room. You count them on the way in without deciding to. Two are older than you, four are roughly your age, one is younger. None of them is looking at you. The instructor is at the corner where the wood floor changes direction; she has not yet looked over."

    e "The part of you that scans rooms is doing what it does. It has been doing this since you were eleven, in a dining room, with six adults laughing, and Tamara at the table. The part of you that scans rooms does not know yet that this is a different kind of room."

    instructor "Let's start on the floor tonight. Wherever you want to be."

    e "You find a place near a wall. You do not need to be near a wall anymore, but it is habit."

    menu:
        "lie down on your back":
            jump a2c6_nim_supine
        "sit crossed-legged":
            jump a2c6_nim_cross_legged
        "stand; not ready for the floor":
            jump a2c6_nim_standing


label a2c6_nim_supine:
    scene black
    e "You lie down. The floor is warmer than the air."

    instructor "Let your weight be weight. Nothing to hold up."

    pause 1.0

    ## NIM-flavoured noticing — the scan is running but
    ## starting to lose interest. Specific to NIM: the
    ## absence of a verbal social register is what the
    ## scanner doesn't know how to handle. There's no one
    ## to be cutting toward. The scanner's job has no
    ## inputs.
    e "Your left shoulder is half a centimetre higher than your right. You do not know how you know this. Or — you know how. The scanning has, over years, learned where the body holds itself ready for being-spoken-of."

    e "Nobody in this room is going to speak of you. The scanning has run its inventory and is, for the first ten minutes, finding nothing. It will start to quiet. It does not know it is starting to quiet."

    $ rr_delta("presence", +6)
    $ rr_delta("interoception", +8)
    $ rr_delta("regulation", +5)

    jump a2c6_nim_middle


label a2c6_nim_cross_legged:
    scene black
    e "You sit. Your knees are higher than you remember knees being."

    instructor "See if there's a place the breath goes that isn't the chest tonight."

    pause 1.0

    ## NIM-flavoured noticing on cross-legged.
    e "The breath goes to a specific spot under your left rib that you were not aware you had a specific spot under. The spot has been holding for a long time. It holds against being said-something-about. There is no one in this room who is about to say something about you. The spot does not know what to do with that."

    $ rr_delta("presence", +5)
    $ rr_delta("interoception", +7)
    $ rr_delta("regulation", +4)

    jump a2c6_nim_middle


label a2c6_nim_standing:
    scene black
    e "You stand by the wall. The wall is cool. The back of your head rests against it."

    instructor "Standing is also available."

    e "You appreciate the instructor for not making standing a thing."

    ## NIM-flavoured noticing on standing.
    e "The wall is at your back. The room is in front of you. The scanning still has its inventory in front of it — seven people, the door, the hour — but the inventory is, this hour, shorter than usual. None of the seven is the kind of person Mother knows. The aunt is not here. Tamara is not here. The room has nothing to hand back to her."

    $ rr_delta("presence", +4)
    $ rr_delta("interoception", +5)
    $ rr_delta("regulation", +3)

    jump a2c6_nim_middle


label a2c6_nim_middle:
    scene black
    with fade

    e "The class moves slowly. The instructor does not narrate much. You move with the class or don't, as the instructor has said you can."

    instructor "Find one place in the body that was tight when you came in, and that isn't, now. Or find one that was tight when you came in, and still is. Either is fine."

    pause 1.0

    menu:
        "find one that has let go":
            ## NIM-flavour: the jaw is the held-against-being-
            ## quoted apparatus. The scanner has been holding
            ## it tight to be ready for the next-cutting-thing.
            ## In a room where nothing is about to cut, the jaw
            ## briefly forgets.
            e "You find one. The back of your jaw. The jaw has been ready, for a long time, to hold its shape against the next quotable thing. Tonight nothing is going to be quoted. The jaw briefly forgets to be ready."
            $ rr_delta("self_trust", +2)
            $ reco_credit("reflection_completed", "a2c6_nim_noticed_release")
            jump a2c6_nim_close

        "find one that is still tight":
            ## NIM-flavour: the sternum-tight holds against
            ## anticipated discussability. It is on tonight.
            e "You find one. The place at the base of your sternum. You have felt this particular tight for a long time. The tight is the part of you that is always almost-being-talked-about. The scan said the talking isn't here tonight; the tight has not yet believed the scan."
            $ rr_delta("presence", +3)
            $ reco_credit("part_register_identified", "a2c6_nim_noticed_holding")
            jump a2c6_nim_close

        "don't find one; just lie here":
            e "You just lie there. The instructor does not mind. The class does not mind. The hour is a specific hour. It is the hour where nobody in the room knows your mother. That is the hour."
            $ rr_delta("regulation", +3)
            jump a2c6_nim_close


label a2c6_nim_close:
    scene black
    with fade

    $ chapter_completed["a2c6_nim"] = True

    instructor "That's the hour. Stay as long as you want."

    e "You stay ten more minutes. You do not want to be the first one out the door."

    e "The stairs back down to the cafe are the same stairs. Your feet know them now."

    ## NIM-specific close: the scan will turn back on outside
    ## the studio when there are people who could be people-
    ## who-know-Mother. The hour was the hour.
    e "On the street the scan will start up again. Everybody in the world is, at some level, a person who could meet someone who knows your mother. The scan does not, for the most part, distinguish. But for the next twenty minutes — the walk home — the scan is gentle, and you can let it be gentle."

    $ rr_delta("self_trust", +2)

    flame "tuesdays have a smaller friction than the other days. you noticed that. it is an old noticing by now."

    menu:
        "continue to Chapter Ten (NIM)":
            jump a2c7_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c6_nim_skipped:
    scene black
    centered "Chapter Nine (NIM variant) was skipped."
    pause 1.5
    e "You went to the class. It was a class. You came home. Nobody in the room was a person who knows your mother. The scan eventually noticed."
    $ rr_delta("presence", +3)
    $ rr_delta("regulation", +3)

    menu:
        "continue to Chapter Ten (NIM)":
            jump a2c7_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
