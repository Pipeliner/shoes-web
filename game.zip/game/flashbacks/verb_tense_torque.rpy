# GEN-CHECKSUM: 25349d0a021235e2
## Flashback snippets — technique: verb_tense_torque
## Present tense intrudes into past-tense narration; or the reverse.
##
## Generated from verb_tense_torque.yaml. Hand-edit below the
## GEN-CHECKSUM line preserved by --force only.
##
## This file is a reference catalog, not live scene code.
## Scene authors grep for snippet IDs, then hand-adapt
## the prose into the target scene's voice. Do not
## import this file or reference its contents at runtime.

## --- snippet: hallway_telephone_table_eight ---
## age:
##   8
## sensory_anchor:
##   'the weight of the phone against the ear'
## lines:
##   narrative_past: 'You are holding the phone in the kitchen in the apartment that had the kitchen with the yellow wallpaper.'
##   intrusion_past: 'There is a stool you are sitting on. You do not remember pulling it over.'
##   age_line: 'You are thirteen and she is telling you about her back again.'
##   return_present: 'You are older. You are holding a phone. The wallpaper is white.'

## --- snippet: kitchen_floor_squares_seven ---
## age:
##   7
## sensory_anchor:
##   'kitchen floor tile pattern'
## lines:
##   intrusion: 'The kitchen floor has squares. The squares have lines. I am sitting on a square.'
##   age_marker: 'The squares are cold.'
##   return: 'You are in the kitchen now. You are thirty-four. You can see yourself, also, sitting on a cold square.'

## --- snippet: standup_screen_fingerprint ---
## age:
##   'present with dissociation-adjacent intrusion'
## sensory_anchor:
##   'fingerprint on a laptop screen'
## lines:
##   detail: 'The screen has a fingerprint on the lower-left quadrant. It is an index-finger print.'
##   shift: 'Her hand is on the mouse.'
##   continuation: 'Someone says her name.'
##   return_awareness: 'She says something. The face on the west coast nods.'

