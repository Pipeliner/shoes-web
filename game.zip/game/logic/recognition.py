"""Recognition meta-system (PRD §4.7).

Recognition is earned by *noticing*, not by winning. Four sources:
  1. Correctly naming an emotional flashback as it happens.
  2. Completing a chapter-end reflection prompt.
  3. Identifying a part by its characteristic register when first seen
     in a new context.
  4. Choosing to sit with an exile's content rather than skip past it.

Recognition gates:
  - Which epilogue arcs are available (four endings).
  - Certain Act III structural-change scenes ("I want to try telling R. no").

It does not unlock a 'good ending.' There is no good ending in that sense.
Per PRD §10 scope-cut order, Recognition's *Act III gating* is first to cut;
Recognition-as-tracked-state stays.

Pickle-safe. Pure dataclass + plain functions.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field, replace


class RecognitionSource(str, enum.Enum):
    NAMED_FLASHBACK = "named_flashback"
    REFLECTION_COMPLETED = "reflection_completed"
    PART_REGISTER_IDENTIFIED = "part_register_identified"
    SAT_WITH_EXILE = "sat_with_exile"


class Ending(str, enum.Enum):
    CYCLE_REPEATING = "cycle_repeating"
    CYCLE_SHIFTING = "cycle_shifting"
    CYCLE_PAUSED = "cycle_paused"
    CYCLE_WITNESSED = "cycle_witnessed"


# Point values per source. Rewards noticing, not winning — the ceiling is
# deliberately low so marathon players don't farm Recognition.
SOURCE_POINTS: dict[RecognitionSource, int] = {
    RecognitionSource.NAMED_FLASHBACK: 3,
    RecognitionSource.REFLECTION_COMPLETED: 2,
    RecognitionSource.PART_REGISTER_IDENTIFIED: 2,
    RecognitionSource.SAT_WITH_EXILE: 4,
}

# Thresholds for ending availability. CYCLE_REPEATING is always available
# (PRD §4.9); CYCLE_WITNESSED requires the highest Recognition.
ENDING_THRESHOLDS: dict[Ending, int] = {
    Ending.CYCLE_REPEATING: 0,
    Ending.CYCLE_PAUSED: 10,
    Ending.CYCLE_SHIFTING: 18,
    Ending.CYCLE_WITNESSED: 28,
}


# Act III structural-change scenes gated by Recognition. Keys are scene ids,
# values are the point threshold. PRD §10 notes this gating is the first
# thing to cut if scope forces it — we can flip `ACT_III_GATING_ENABLED` off.
ACT_III_GATING_ENABLED = True

ACT_III_STRUCTURAL_GATES: dict[str, int] = {
    "tell_r_no": 14,
    "cancel_the_call": 8,
    "mention_the_childhood_thing": 20,
}


@dataclass(frozen=True)
class RecognitionLedger:
    """Tracks Recognition points and which sources have been hit.

    Pickle-safe: frozen dataclass of primitives and a frozen source record.
    We track which specific events have been logged to avoid double-counting
    (e.g., a player can only earn points for naming a given flashback once).
    """

    points: int = 0
    # Set of opaque event ids that have already been credited. Stored as a
    # frozenset for hashability; rebuild on update.
    seen: frozenset[str] = field(default_factory=frozenset)

    def credit(
        self, source: RecognitionSource, event_id: str
    ) -> "RecognitionLedger":
        """Credit Recognition for an event. No-op if event_id already seen."""
        if event_id in self.seen:
            return self
        return replace(
            self,
            points=self.points + SOURCE_POINTS[source],
            seen=self.seen | {event_id},
        )

    def available_endings(self) -> tuple[Ending, ...]:
        """Which endings are unlocked right now."""
        return tuple(
            e
            for e, threshold in ENDING_THRESHOLDS.items()
            if self.points >= threshold
        )

    def can_attempt(self, scene_id: str) -> bool:
        """Can the protagonist attempt this Act III structural-change scene?

        If ACT_III_GATING_ENABLED is False (the scope-cut lever), all gates
        pass. Recognition is still tracked.
        """
        if not ACT_III_GATING_ENABLED:
            return True
        threshold = ACT_III_STRUCTURAL_GATES.get(scene_id)
        if threshold is None:
            # Unknown scene id is not a gated scene; allow it.
            return True
        return self.points >= threshold


__all__ = [
    "ACT_III_GATING_ENABLED",
    "ACT_III_STRUCTURAL_GATES",
    "ENDING_THRESHOLDS",
    "Ending",
    "RecognitionLedger",
    "RecognitionSource",
    "SOURCE_POINTS",
]
