## scenes/act2/chapter2.rpy — the exile approach.
##
## The thesis chapter. No shipped game has mechanized IFS with
## negotiation-not-defeat and protector-gated exile access. This is
## what the project is for.
##
## Per PRD §4.6 + amendment A1:
##   - Exile approach requires `permission >= PERMISSION_MIN_EXILE`
##     (currently 65; lowered from 70 in 0.1.x per the simulator
##     trace documented in docs/prd-amendments.md §A1; the AI
##     sensitivity-reader pass 0.1.18-7 caught the stale "70" in
##     this comment).
##   - Both a Manager AND a Firefighter have consented in a prior scene
##   - If conditions aren't met, we show the gate and why. We do not
##     force contact. We do not substitute. We wait, or we earn it.
##
## Per PRD §7.1 exile craft:
##   - Present tense.
##   - Small, specific sensory detail.
##   - Child-age vocabulary.
##   - Short sentences.
##   - Does not monologue trauma. Shows a small moment.
##
## This scene refuses catharsis. The exile appears; nothing resolves;
## the protagonist does not "reclaim" anything. Residue stays visible.

label a2c2_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c2", False):
        centered "Chapter Five\n\nThis chapter contains a brief contact with a childhood part of the protagonist. It is written in present tense, with small sensory detail, and is short.\n\nIt is skippable at the scene level."
        $ chapter_notice_shown["a2c2"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c2_skipped

    ## First: evaluate the exile gate and tell the player what it sees.
    $ gate = pp_exile_gate()

    if gate.approved:
        jump a2c2_approved
    else:
        jump a2c2_gated


label a2c2_gated:
    ## The gate is the feature. We show the player what has not yet been
    ## earned. No shame frame — this is information, not a judgment.
    scene black
    e "There is a part of you in the next room, so to speak."
    e "Smaller. Quieter. You can feel that there is a next room."

    if gate.missing_manager_consent and gate.missing_firefighter_consent:
        caretaker_voice "I haven't agreed to this yet."
        firefighter_voice "Neither have I."
        ## Per playthrough-clinical reader 0.1.18-32 H-3: avoid
        ## "two parts of you" roster-shape that flickers toward
        ## iatrogenic-fragmentation surface. The function-not-
        ## roster register at :64 and :67 below is the established
        ## pattern; mirror it here for the both-pending case.
        e "Standing in front of the door: the one that has kept you safe by taking care of others first, and the one that takes you out of rooms you cannot stay in. Neither hostile. Neither saying yes yet."
    elif gate.missing_manager_consent:
        caretaker_voice "I haven't agreed to this yet."
        e "The one that has kept you safe by taking care of others first is standing in front of the door. Not to stop you. To be sure."
    elif gate.missing_firefighter_consent:
        firefighter_voice "I haven't agreed to this yet."
        e "The one that takes you out of rooms you cannot stay in is standing in front of the door. Not to stop you. To be sure."

    if gate.permission_too_low:
        e "Something else is also not yet in place. A kind of internal permission. It is not something you can decide from the outside."
        e "It grows when the parts in front of the door feel heard."

    e "The next room will still be there, later."

    ## Offer a negotiation pass. This is the earned-access loop.
    menu:
        "sit with a part of you now — the one not yet ready":
            if gate.missing_manager_consent:
                $ which = "caretaker"
                caretaker_voice "Thank you for waiting. I do not, yet, know how this will go."
            elif gate.missing_firefighter_consent:
                $ which = "numb-out"
                firefighter_voice "Thank you for not pushing."
            else:
                $ which = "caretaker"
            $ intervention = renpy.call_screen(
                "negotiate",
                part_name=which,
                opening_line="I am not yet ready for you to go further. Ask me what I am trying to do for you.",
            )
            if intervention is None:
                $ intervention = ("ask", which)
            $ response_key = pp_intervene(intervention[0], intervention[1])
            e "A part of you breathes differently after that."
            jump a2c2_after_negotiate

        "leave it for today":
            e "You leave it for today. The next room will still be there."
            jump a2c2_after_negotiate


label a2c2_after_negotiate:
    ## Re-check the gate. If we're now approved, offer to continue.
    ## If not, close the chapter with dignity.
    $ gate = pp_exile_gate()
    if gate.approved:
        e "Something has shifted. The door is no longer held."
        menu:
            "go in, for a moment":
                jump a2c2_approved
            "another day":
                jump a2c2_close
    else:
        jump a2c2_close


label a2c2_approved:
    ## The exile-approach scene. Present tense. Short. Sensory. No
    ## monologue. Not a trauma dump. The scene is the shape of showing
    ## up, not the shape of resolution.
    scene black
    with slowdissolve

    e "You step through."

    ## Narrator voice lowers. Exile voice takes over. Child-age vocab.
    ## Present tense. Small detail.
    ## Flashback uses formal_differentiation.exile_voice_in_act2_ch2
    ## and verb_tense_torque.kitchen_floor_squares_seven
    exile_voice "The kitchen floor has squares. The squares have lines. I am sitting on a square."

    exile_voice "The squares are cold."

    exile_voice "Mama's slippers are in the doorway, but she is not in them."

    pause 1.5

    exile_voice "I am waiting."

    exile_voice "I do not know for what. I know for how long, which is 'a while.'"

    pause 1.5

    ## The adult protagonist is present. Not speaking over. Not fixing.
    ## Sitting with.
    e "You are in the kitchen. You are thirty-four. You can see yourself, also, sitting on a cold square."

    e "You do not reach for the child. Something has told you, without words, that reaching would be too much."

    e "You sit on a square adjacent."

    exile_voice "Hi."

    e "You say hi."

    exile_voice "I am cold."

    e "You say 'I know.'"

    pause 2.0

    ## Credit Recognition — this is the "sat_with_exile" source.
    $ reco_credit("sat_with_exile", "a2c2_exile_contact_1")

    e "Nothing else happens. Nothing 'unlocks.' There is no reveal."

    e "After a while — a while you do not time — you stand up."

    exile_voice "Will you come back?"

    e "You do not promise. You say 'I think so.'"

    pause 1.0

    e "Then you are back. The laptop is closed. The apartment is the apartment."

    e "You are cold."

    ## Resources: presence rises slightly (being in the room with a
    ## child-part is a form of presence); permission drops slightly
    ## because exile-contact is expensive; regulation holds.
    $ rr_delta("presence", +6)
    $ rr_delta("permission", -4)
    $ rr_delta("self_trust", +5)
    $ rr_delta("critic_volume", -6)
    $ rr_delta("flashback_pressure", +8)

    ## After-contact reflection. A gentle one.
    flame "there is no resolution to that. you sat next to a part of yourself."

    jump a2c2_close


label a2c2_close:
    scene black
    with fade
    flame "nothing is fixed. you also did not make anything worse by being here. both of those are true."

    ## Chapter-end reflection, Recognition source.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c2_feeling")

    e "What follows builds on what you have just sat with. Some endings only become visible to a person who has done that sitting; this was the doing."

    menu:
        "continue to Chapter Six":
            jump a2c3_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c2_skipped:
    scene black
    centered "Chapter Five was skipped."
    pause 1.5
    e "There is a room, and a door, and you did not walk through it today."
    e "You did not also not walk through it. The chapter was elided."
    e "Some of the endings require having sat with that child-part of you, and so they will not appear on this run. The other endings remain."

    menu:
        "continue to Chapter Six":
            jump a2c3_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
