## scenes/act2/chapter6.rpy — movement practice.
##
## Scene type: Ordinary-week with somatic-practice subtype
## (amendment A10, PRD profile inventory). A movement-practice
## class scene. Group setting; one instructor NPC; the protagonist
## participates with body and attention. No parts-activation in the
## foreground — this is a rest chapter by design.
##
## State contract (per §interior-work subtype convention):
##   +presence, +interoception, +regulation, small +self_trust.
##   No critic spike. One Recognition credit for noticing a body
##   signal. Cast: instructor only.
##
## Craft discipline:
##   - Short. The scene is a breath, not a plot beat.
##   - Specific body sensations, not generic "relaxation."
##   - Do not name the practice as therapy, yoga, or CPTSD
##     somatic work. It is "movement practice." The class is the class.
##   - No "healing" language (PRD §10). Allowed: specific verbs
##     like "settle," "arrive," "notice."
##
## Flashback/formal-differentiation note: this scene uses the
## instructor Character as a present-tense somatic-layer
## differentiator (not a flashback). See
## flashbacks/formal_differentiation.yaml::instructor_voice_as_differentiator.

label a2c6_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c6", False):
        centered "Chapter Nine — Act II (continued)\n\nA short movement-practice class scene. No sensitive content."
        $ chapter_notice_shown["a2c6"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c6_skipped

    scene black
    with dissolve

    e "Tuesday evening. The studio is above a cafe, up a flight of stairs that turns twice."

    e "You are here because someone you vaguely know said it was worth trying. You have been here five times. This is the sixth."

    e "The floor is wood. The windows are open. It is not quite warm yet."

    instructor "Let's start on the floor tonight. Wherever you want to be."

    e "You find a place near a wall. You do not need to be near a wall anymore, but it is habit."

    menu:
        "lie down on your back":
            jump a2c6_supine
        "sit crossed-legged":
            jump a2c6_cross_legged
        "stand; not ready for the floor":
            jump a2c6_standing


label a2c6_supine:
    scene black
    e "You lie down. The floor is warmer than the air."

    instructor "Let your weight be weight. Nothing to hold up."

    pause 1.0

    e "Your left shoulder is half a centimetre higher than your right. You do not know how you know this."

    $ rr_delta("presence", +6)
    $ rr_delta("interoception", +8)
    $ rr_delta("regulation", +5)

    jump a2c6_middle


label a2c6_cross_legged:
    scene black
    e "You sit. Your knees are higher than you remember knees being."

    instructor "See if there's a place the breath goes that isn't the chest tonight."

    pause 1.0

    e "The breath goes to a specific spot under your left rib that you were not aware you had a specific spot under."

    $ rr_delta("presence", +5)
    $ rr_delta("interoception", +7)
    $ rr_delta("regulation", +4)

    jump a2c6_middle


label a2c6_standing:
    scene black
    e "You stand by the wall. The wall is cool. The back of your head rests against it."

    instructor "Standing is also available."

    e "You appreciate the instructor for not making standing a thing."

    $ rr_delta("presence", +4)
    $ rr_delta("interoception", +5)
    $ rr_delta("regulation", +3)

    jump a2c6_middle


label a2c6_middle:
    scene black
    with fade

    e "The class moves slowly. The instructor does not narrate much. You move with the class or don't, as the instructor has said you can."

    instructor "Find one place in the body that was tight when you came in, and that isn't, now. Or find one that was tight when you came in, and still is. Either is fine."

    pause 1.0

    menu:
        "find one that has let go":
            e "You find one. The back of your jaw. You did not know your jaw was tight when you came in. You know it now, by the not."
            $ rr_delta("self_trust", +2)
            $ reco_credit("reflection_completed", "a2c6_noticed_release")
            jump a2c6_close

        "find one that is still tight":
            e "You find one. The place at the base of your sternum. You have felt this particular tight for a long time."
            $ rr_delta("presence", +3)
            $ reco_credit("part_register_identified", "a2c6_noticed_holding")
            jump a2c6_close

        "don't find one; just lie here":
            e "You just lie there. The instructor does not mind. The class does not mind. The hour is a specific hour."
            $ rr_delta("regulation", +3)
            jump a2c6_close


label a2c6_close:
    scene black
    with fade

    instructor "That's the hour. Stay as long as you want."

    e "You stay ten more minutes. You do not want to be the first one out the door."

    e "The stairs back down to the cafe are the same stairs. Your feet know them now."

    $ rr_delta("self_trust", +2)

    flame "tuesdays have a smaller friction than the other days. you noticed that. it is an old noticing by now."

    menu:
        "continue to Chapter Ten":
            jump a2c7_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c6_skipped:
    scene black
    centered "Chapter Nine was skipped."
    pause 1.5
    e "You went to the class. It was a class. You came home."
    # Equivalent modest gain so downstream chapters don't arrive in
    # an inconsistent state.
    $ rr_delta("presence", +3)
    $ rr_delta("regulation", +3)

    menu:
        "continue to Chapter Ten":
            jump a2c7_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
