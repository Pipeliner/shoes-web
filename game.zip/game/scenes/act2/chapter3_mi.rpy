## scenes/act2/chapter3_mi.rpy — Act II Ch 3 MI-branch variant.
##
## Mirrors the structural arc of `game/scenes/act2/chapter3.rpy`
## (the CEN therapist session) in the MI register. Same eight-beat
## shape: chapter notice + skip menu; opening on the rug; therapist's
## email-prompt with three response options; opened branch; deflect
## branch; silence branch; mid-session *Both are true* moment with a
## cross-temporal anchor; close + between-session task; out + Flame.
##
## MI-bias amplifications per PRD §4.3 BRANCH_BIAS[MI]:
##   - FLASHBACK_PRESSURE ×1.2 worse
##   - INTEROCEPTION ×1.2 worse / 0.8 better
##   - PRESENCE ×1.3 worse / 0.8 better
## Authored deltas mirror the CEN scene; the simulator applies the
## bias multipliers. Do not pre-bias here.
##
## Cross-temporal anchor pivot (the highest-risk decision per
## docs/mi-act2-ch3-4-plan-0.1.18-31.md §7). CEN's mid-session beat
## pivots on the kitchen with the yellow wallpaper at age 13. The
## MI variant pivots on the **hallway with the telephone table
## outside her bedroom door at age eight** (per
## docs/continuity.md:458-462). The therapist references a wallpaper-
## adjacent earlier session as the way the topic surfaced, but the
## texture the protagonist drifts into is the hallway, not a kitchen.
##
## Craft discipline (per chapter3.rpy header):
##   - Therapist asks more than she tells.
##   - No diagnosis names; no modality labels; no outcome promises.
##   - The therapist does not articulate the protagonist's parts for
##     her (per docs/continuity.md:760-768).
##   - The protagonist's register is allowed to drift into the exile
##     register for one paragraph at most, mid-session, via verb-
##     tense torque.
##
## State effects match the interior_work_therapist_session beat
## family in tests/e2e/beats.py.

label a2c3_mi_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c3_mi", False):
        centered "Chapter Six — Act II (continued, MI branch)\n\nThis chapter contains a depicted therapy session. The game is not therapy; this scene is fiction. The therapist is trauma-informed. The session opens on the aunt's email about Mother."
        $ chapter_notice_shown["a2c3_mi"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c3_mi_skipped

    scene black
    with dissolve

    e "It is Wednesday. The room has a rug that is older than you are. The rug has a coffee-stain on it that you have not once asked about."

    e "You take your shoes off on the rug. You have been doing that for fourteen months. The rug is the reason."

    e "You sit in the chair you always sit in. Not the couch. The chair."

    therapist "We left off last time with the email from your aunt. Have you opened it?"

    menu:
        "say yes, and what happened after":
            jump a2c3_mi_opened
        "say you opened it and you are trying not to think about it":
            jump a2c3_mi_deflect
        "say nothing for a moment":
            jump a2c3_mi_silence


label a2c3_mi_opened:
    e "You say yes. You say you opened it, and then you were somewhere mostly-not-here for a while, and you do not know how long the while was."

    therapist "Where did you go?"

    e "You say: not far. Just not in the room with the laptop."

    therapist "The part of you that took you out of the room — was it trying to protect something?"

    menu:
        "say: I think it was":
            firefighter_voice "It was."
            ## The dissociative firefighter answers in its own voice
            ## (established in a2c1_mi.rpy:98-103). The narrator names
            ## the noticing-of-the-answering as its own beat — same
            ## pattern as chapter3.rpy:72.
            e "You can feel which part of you turned to face the question. You say what you noticed: that something inside you stepped in when the email opened, and the stepping-in was old, and it was not unkind."
            $ rr_delta("permission", +6)
            $ rr_delta("self_trust", +5)
            $ rr_delta("critic_volume", -4)
            therapist "That noticing is the work. Not the answer. The noticing."
            $ reco_credit("part_register_identified", "a2c3_mi_dissociative_part_named")
            jump a2c3_mi_midsession

        "say: I don't know":
            e "You say you don't know."
            therapist "That is also a real answer."
            $ rr_delta("self_trust", +2)
            jump a2c3_mi_midsession


label a2c3_mi_deflect:
    e "You say you are trying not to think about it."

    therapist "Mm."

    e "The therapist does not pursue. This is the thing she does. She leaves the silence unfilled."

    $ rr_delta("regulation", +2)

    menu:
        "let the silence hold":
            e "You let it. The silence is long and specific. The hypervigilant part of you is still running its inventory under the silence; you can feel it doing that."
            $ rr_delta("presence", +4)
            $ rr_delta("interoception", +3)
            jump a2c3_mi_midsession
        "break the silence, anything":
            e "You fill the silence with a story about nothing. The inventory keeps running underneath."
            $ rr_delta("critic_volume", +3)
            jump a2c3_mi_midsession


label a2c3_mi_silence:
    e "You say nothing for a moment. The therapist does not hurry."
    pause 1.0
    e "The moment is long enough that you notice what you are not saying."

    $ rr_delta("presence", +5)
    $ rr_delta("interoception", +4)
    $ rr_delta("regulation", +4)
    $ rr_delta("permission", +3)

    therapist "What's here, right now?"

    menu:
        "say: something small, in the chest":
            e "You say: something small, in the chest."
            therapist "Can it stay there for a moment, while we talk?"
            $ rr_delta("presence", +3)
            jump a2c3_mi_midsession
        "say: I don't know":
            e "You say you don't know."
            therapist "Then we don't have to know. Yet."
            $ rr_delta("self_trust", +3)
            jump a2c3_mi_midsession


label a2c3_mi_midsession:
    ## The mid-session moment — a permitted exile-register paragraph,
    ## via verb-tense torque. No full flashback; no library entry;
    ## no visual effect. The pivot is the hallway-with-telephone-
    ## table at age eight (per docs/continuity.md:458-462), NOT the
    ## yellow wallpaper at thirteen (the CEN signature).
    ##
    ## The therapist's referencing line keeps the office's wallpaper
    ## as the prior-session bridge (docs/continuity.md:710-719) — the
    ## protagonist mentioned, last week, that her childhood had a
    ## wallpaper she remembered. This session, the therapist comes
    ## back to a different specific from the same childhood: the
    ## hallway outside Mother's bedroom door, where the protagonist
    ## stood as a child.
    scene black
    with fade

    therapist "You said last week that the hallway in your childhood had a telephone table outside her door. I want to come back to that, if it's ok."

    e "The hallway has a telephone table in it."

    e "The door is the door to her bedroom. You are deciding whether to knock. You are counting."

    e "You are in the chair. In the office. The rug is older than you are."

    therapist "Where are you right now?"

    e "You say: in the chair."

    therapist "And also?"

    e "You say: sometimes in the hallway."

    therapist "Both are true."

    ## The therapist's signature move: permitting both, not forcing
    ## a return. State effects match the CEN authored deltas; bias
    ## is applied by the simulator.
    ##
    ## No Recognition credit at this beat — CEN's equivalent at
    ## chapter3.rpy:155-164 also does not credit Recognition here.
    ## The plan's `structural_change_attempted_or_completed` source
    ## key is not a member of `RecognitionSource` (only four are
    ## defined: named_flashback, reflection_completed,
    ## part_register_identified, sat_with_exile). The mid-session
    ## moment's value is the state weight, not a Recognition tick;
    ## the close-path task earns the reflection_completed credit on
    ## the same beat schedule as CEN.
    $ rr_delta("permission", +8)
    $ rr_delta("regulation", +8)
    $ rr_delta("critic_volume", -6)
    $ rr_delta("self_trust", +4)
    $ rr_delta("presence", +4)

    jump a2c3_mi_close


label a2c3_mi_close:
    scene black
    with fade

    therapist "We're near the end of the hour. How do you want to leave?"

    menu:
        "with a small task to try this week":
            therapist "Okay. Something small. What feels small enough?"
            ## The between-session task names the dissociative
            ## firefighter in the same noticing register the scene has
            ## been using — *the part that takes you out of the room*
            ## (per a2c1_mi.rpy:99 + 132). The therapist does not
            ## articulate it as a "part" diagnostically; she uses the
            ## protagonist's words back.
            e "You say: noticing when the part that takes you out of the room shows up."
            therapist "That's a good one. You don't have to do anything with it. Just notice."
            $ rr_delta("permission", +2)
            $ reco_credit("reflection_completed", "a2c3_mi_between_session_task")
            jump a2c3_mi_out

        "with nothing; I don't want homework":
            therapist "Okay. We'll talk Wednesday."
            $ rr_delta("self_trust", +3)
            jump a2c3_mi_out

        "with the silence from the middle":
            therapist "Let's leave it there."
            e "The silence sits down again between you."
            $ rr_delta("presence", +3)
            $ rr_delta("regulation", +3)
            jump a2c3_mi_out


label a2c3_mi_out:
    scene black
    $ chapter_completed["a2c3_mi"] = True
    e "You put your shoes back on. You did not realize you had taken them off. The rug is the reason. You always take them off on the rug."

    ## Prior-week task callback. In MI it was *noticing the inventory's
    ## working* — the hypervigilant manager from a1c2_mi.rpy:47 (the
    ## part that counts rings and reads pitch). Same shape as the CEN
    ## prior-week task (noticing what you take your shoes off for) but
    ## tracked on the MI signature.
    e "Last week's task was noticing when the inventory in your head was running. The phone rings. The kitchen at half-past six. Anything that has the texture of being scanned. You have not yet said out loud what the noticing has been finding."

    e "You pay the co-pay at the desk."

    e "The afternoon is the afternoon."

    flame "wednesdays are the days with less friction, she said. that sounds right."

    ## Reflection prompt as chapter-end. Recognition source.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c3_mi_feeling")

    menu:
        "continue to Chapter Seven (MI)":
            jump a2c4_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c3_mi_skipped:
    scene black
    centered "Chapter Six (MI variant) was skipped."
    pause 1.5
    e "You had a session. Something happened in it. The next chapter continues."
    ## Modest between-session gain so the skipped chapter doesn't
    ## penalise committed players who skip for content reasons. Does
    ## NOT set chapter_completed — that's reserved for the close path.
    $ rr_delta("regulation", +3)
    $ rr_delta("permission", +3)

    menu:
        "continue to Chapter Seven (MI)":
            jump a2c4_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
