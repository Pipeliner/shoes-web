## scenes/act3/tell_r_no.rpy — Act III structural-change scene.
##
## Scene id "tell_r_no" — Recognition threshold 14 (mid tier).
## The protagonist tries to tell Sam, the partner, "no" on a planned
## thing. Success: boundary declines, critic still spikes (A7). Fawn
## activation is the failure mode.
##
## Subject matter (kept deliberately mundane): Sam suggested brunch
## Sunday with some of Sam's friends the protagonist doesn't know well.
## The protagonist said yes earlier in the week. They want to take it
## back.

label a3_tell_r_no:
    scene black
    show screen tooltip_overlay

    e "It is Thursday evening. You are at Sam's. Sam is on the couch with the book that has been on the couch for a week."

    e "Sunday brunch was your yes. You said it on Tuesday, without thinking. Sam's friends are Sam's friends; they are fine. You do not know them."

    e "You do not want to go."

    e "A part of you knew on Tuesday that you did not want to go. You said yes anyway. That is the whole shape of this for you."

    pause 1.0

    e "Sam has not looked up from the book. The kettle in Sam's kitchen is cooling on the counter."

    ## Flashback uses sensory_pivot.kettle_pitch
    e "The kettle clicks off."
    e "The kettle in your mother's kitchen clicked off the same way. She was at the counter. She did not turn around."
    e "You remember hearing her breath."
    e "You are in Sam's kitchen. The book is the book. The kettle is cooling."

    call screen a3_tell_r_no_menu

    if _return == "say_it":
        jump a3_tell_r_no_said
    elif _return == "say_it_refused":
        ## Flashback uses non_flashback.the_sentence_you_almost_said
        e "There is a sentence you almost say."
        e "You can feel the shape of it in the lower part of your throat. You know its first word and its last word."
        e "You do not say it."
        firefighter_voice "No. Not now. Not over a book."
        e "You stay on the chair. The kettle is the kettle. The book is the book."
        jump a3_tell_r_no_not_said
    elif _return == "wait":
        jump a3_tell_r_no_waited
    else:
        jump a3_tell_r_no_not_said


screen a3_tell_r_no_menu():
    tag menu
    $ c_say_it = cc_eval(
        "say_it",
        "say it now: 'i was thinking about sunday — can i take back the yes?'",
        guard_keys=("not_fawn_active",),
        npc="sam",
        refuse_on_block=True,
    )
    $ c_wait = cc_eval(
        "wait",
        "wait for the right moment. the moment you will know when you see it.",
        guard_keys=(),
    )
    $ c_nothing = cc_eval(
        "nothing",
        "go to sunday. it's only an hour. it's fine.",
        guard_keys=(),
    )

    frame:
        xalign 0.5
        yalign 0.5
        xpadding 28
        ypadding 28
        xmaximum 780

        vbox:
            spacing 10
            text "What do you do?" size 22
            use gated_choice_row(c_say_it, Return("say_it"))
            use gated_choice_row(c_wait, Return("wait"))
            use gated_choice_row(c_nothing, Return("nothing"))
            use tooltip_footer


label a3_tell_r_no_said:
    scene black
    with fade
    e "You say it. The sentence comes out shorter than you planned."

    e "\"I was thinking about Sunday. Can I take back the yes?\""

    pause 1.0

    e "Sam looks up. Sam's thumb stays on the page. This is not hostile. This is Sam finishing the sentence Sam was reading."

    sam "Yeah. Want me to still go?"

    menu:
        "say: yes, go":
            e "You say: yes. Go."
            $ rr_npc_delta("sam", +4, safe=True)
        "say: i'd rather we stayed in":
            e "You say: i'd rather we stayed in."
            $ rr_npc_delta("sam", +6, safe=True)
            sam "Okay."
        "say: i don't know yet":
            e "You say: i don't know yet."
            sam "Okay. Let me know."
            $ rr_npc_delta("sam", +3, safe=True)

    ## Base effects of the successful boundary.
    $ rr_delta("self_trust", +8)
    $ rr_delta("permission", +4)

    ## Per A7: the critic still spikes. The successful boundary does
    ## not neutralise the ACoA pattern.
    critic_voice "You always do this. You said yes. You said yes. You knew you didn't want to. You said yes."

    $ rr_delta("critic_volume", +7)

    e "The Critic's line is about Tuesday, not about now. You notice the distinction."

    $ reco_credit("reflection_completed", "a3_tell_r_no_succeeded")
    $ reco_credit("part_register_identified", "a3_tell_r_no_critic_timing")

    flame "you took back a yes. that is a specific thing. the critic's timing on it was information about where you have lived for a long time."

    $ act3_outcomes["tell_r_no"] = "said"
    $ renpy.fix_rollback()
    jump a3_tell_r_no_close


label a3_tell_r_no_waited:
    scene black
    e "You wait for the right moment. The right moment does not come."

    e "Sam closes the book at ten, makes tea, goes to bed."

    e "You stay on the chair. Sunday is still happening."

    $ rr_delta("self_trust", -3)
    $ rr_delta("critic_volume", +5)
    $ rr_delta("presence", +3)  # noticing the waiting

    critic_voice "The right moment was always right now. You know that."

    $ reco_credit("part_register_identified", "a3_tell_r_no_waited_pattern")

    $ act3_outcomes["tell_r_no"] = "waited"
    $ renpy.fix_rollback()
    jump a3_tell_r_no_not_said


label a3_tell_r_no_not_said:
    scene black
    with fade
    e "Sunday happens. The brunch is fine. The brunch is an hour and forty minutes."

    e "You say the things people say at brunch. You laugh at the things people laugh at."

    $ rr_delta("social_battery", -12)
    $ rr_delta("presence", -6)

    e "Monday you are tired in the way that means a specific tired."

    flame "you did not take back the yes this time. that is also information."

    if act3_outcomes.get("tell_r_no") != "waited":
        $ act3_outcomes["tell_r_no"] = "not_said"
        $ renpy.fix_rollback()
    jump a3_tell_r_no_close


label a3_tell_r_no_close:
    scene black
    with fade
    e "The Thursday closes. The week continues."
    return
