## scenes/act3/dispatcher.rpy — Act III entry point.
##
## Per PRD §4.7: Recognition gates which epilogue arcs are available,
## and gates certain Act III structural-change scenes.
##
## The dispatcher presents the three structural-change scenes as a
## gated menu. Each is gated on Recognition via the
## `recognition_for_scene` guard (amendment A9). Locked scenes
## surface via the standard visibly-unavailable mechanism with the
## RECOGNITION_TOO_LOW tooltip.
##
## After each attempt, the dispatcher returns here. The player can
## attempt multiple scenes or proceed to the ending_dispatch.

label act3_dispatcher:
    scene black
    show screen tooltip_overlay
    with fade

    e "Act III. The week continues. You have some space to try specific things."

    e "Below is a list of small attempts. Some are available; some are not yet."

    e "The ones that are not available will tell you why. They will stay visible."

    ## Per U2 (0.1.18-46): a single per-branch line orienting the
    ## Caretaker into Act III. Mirrors the S4 + U1 per-branch
    ## Caretaker pattern from the endings. CEN gets no addition
    ## (the general Caretaker register fits the existing prose).
    if resource_snapshot.branch == res.Branch.MI:
        e "The stretch-watcher is here, on the couch with you. It has been on for so long that it does not, mostly, know what it would be doing if it were not on. The list below is, in part, the list of things that ask the stretch-watcher to consider being briefly off."
    elif resource_snapshot.branch == res.Branch.NIM:
        e "The threat-scanner is here, on the couch with you. It has been mapping yields for so long that it does not, mostly, know what it would be doing if it were not mapping. The list below is, in part, the list of things that ask the threat-scanner to consider being briefly off."

    jump act3_menu_loop


label act3_menu_loop:
    call screen act3_structural_menu

    if _return == "cancel_the_call":
        ## S1 (0.1.18-46): Act III branch-aware routing for
        ## cancel_the_call. CEN/MI/NIM each have a distinct
        ## variant; route by current branch. tell_r_no and
        ## mention_the_childhood_thing remain branch-shared
        ## for now — separate per-branch variants are
        ## planned in follow-up turns.
        if resource_snapshot.branch == res.Branch.MI:
            call a3_cancel_the_call_mi
        elif resource_snapshot.branch == res.Branch.NIM:
            call a3_cancel_the_call_nim
        else:
            call a3_cancel_the_call
        jump act3_menu_loop
    elif _return == "tell_r_no":
        ## S2 (0.1.18-46): branch-aware routing.
        if resource_snapshot.branch == res.Branch.MI:
            call a3_tell_r_no_mi
        elif resource_snapshot.branch == res.Branch.NIM:
            call a3_tell_r_no_nim
        else:
            call a3_tell_r_no
        jump act3_menu_loop
    elif _return == "mention_the_childhood_thing":
        ## S3 (0.1.18-46): branch-aware routing.
        if resource_snapshot.branch == res.Branch.MI:
            call a3_mention_the_childhood_thing_mi
        elif resource_snapshot.branch == res.Branch.NIM:
            call a3_mention_the_childhood_thing_nim
        else:
            call a3_mention_the_childhood_thing
        jump act3_menu_loop
    elif _return == "proceed_to_ending":
        jump ending_dispatch
    else:
        jump act3_menu_loop


screen act3_structural_menu():
    tag menu

    ## Evaluate each structural-change scene as a Choice with the
    ## recognition_for_scene guard plus a matching tag. Tag value is
    ## the scene id.
    $ c_cancel = cc_eval(
        "cancel_the_call",
        "try cancelling a call with your mother",
        guard_keys=("not_already_attempted", "recognition_for_scene"),
        tags=("requires_recognition:cancel_the_call",),
    )
    $ c_tell_r = cc_eval(
        "tell_r_no",
        "try telling Sam no on a plan you already said yes to",
        guard_keys=("not_already_attempted", "recognition_for_scene"),
        tags=("requires_recognition:tell_r_no",),
    )
    $ c_mention = cc_eval(
        "mention_the_childhood_thing",
        "try mentioning the childhood thing to Ben, at two in the morning",
        guard_keys=("not_already_attempted", "recognition_for_scene"),
        tags=("requires_recognition:mention_the_childhood_thing",),
    )

    frame:
        xalign 0.5
        yalign 0.5
        xpadding 28
        ypadding 28
        xmaximum 820

        vbox:
            spacing 12
            text "Which, today?" size 22

            use gated_choice_row(c_cancel, Return("cancel_the_call"))
            use gated_choice_row(c_tell_r, Return("tell_r_no"))
            use gated_choice_row(c_mention, Return("mention_the_childhood_thing"))

            null height 10
            textbutton "proceed to the ending":
                action Return("proceed_to_ending")

            use tooltip_footer
