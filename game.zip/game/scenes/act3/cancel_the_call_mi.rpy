## scenes/act3/cancel_the_call_mi.rpy — Act III structural-change scene
## (MI variant).
##
## Per PRD §4.7 + S1 design reversal (0.1.18-46): Act III now
## supports per-branch variants. CEN equivalent:
## scenes/act3/cancel_the_call.rpy. Same gated-menu shape
## (send_now / draft / nothing) and same Recognition gate
## threshold (8 in ACT_III_STRUCTURAL_GATES) — but the
## prose lands on MI-specific texture.
##
## Branch differences vs. CEN:
##   - The Wednesday call is welfare-verification dressed as a
##     daughter-call (per docs/continuity.md:517-527 MI-Mother
##     subtype: "welfare verification with a daughter-disguise").
##     The Caretaker scans the first ten seconds of every call
##     for stretch-state. Cancelling means cancelling the
##     stretch-check too.
##   - Mother's reply is a stretch-signaling text — flat,
##     low-energy, possibly typed badly. The Caretaker reads
##     the cadence even of a text.
##   - The Critic on landed-cancellation activates the stretch-
##     watcher's worst-case: she'll be in a stretch by
##     Wednesday because of this.
##   - The not_sent path's 38-minute call is welfare-check
##     texture: scanning for stretch-cues, listening for
##     things-not-said.
##
## Reuses the gated-choice screen `a3_cancel_the_call_menu`
## from cancel_the_call.rpy (branch-agnostic UI).
##
## Caller (dispatcher) is responsible for routing players here
## only when gate is approved AND branch is MI.

label a3_cancel_the_call_mi:
    scene black
    show screen tooltip_overlay

    e "Wednesday again. The calendar says seven PM. Your mother's name."

    ## MI-specific opening: welfare-check framing.
    e "You have not cancelled a call with your mother in fifteen years. The Caretaker has not let you. Cancelling means missing a stretch-check. Cancelling means the next aunt-email could come and you would not have your usual ten-seconds-of-stretch-data from this week."

    e "You have said you had to go partway through; once, twice, five times — usually after the first ten seconds gave you a green-stretch read. You have not cancelled one."

    pause 1.0

    e "Your phone is on the table. The call is in ninety minutes."

    ## The attempt — gated menu, reuses the CEN screen.
    call screen a3_cancel_the_call_menu

    if _return == "send_now":
        jump a3_cancel_the_call_mi_sent
    elif _return == "send_now_refused":
        ## refuse_on_block path — the fawn part speaks.
        ## MI-specific: the Caretaker frames the refusal as
        ## stretch-data-loss.
        caretaker_voice "Not now. Not over a text. We need the ten seconds. We need to know."
        e "You set the phone down. The call is in eighty-seven minutes now."
        jump a3_cancel_the_call_mi_not_sent
    elif _return == "draft":
        jump a3_cancel_the_call_mi_draft
    else:
        jump a3_cancel_the_call_mi_not_sent


label a3_cancel_the_call_mi_sent:
    scene black
    with fade
    e "You press send. The message sits in the chat in that particular way a message sits when you are the one who just sent it."

    e "Your mother is typing."

    pause 1.0

    e "Your mother has stopped typing."

    pause 1.0

    e "Your mother is typing again."

    pause 1.0

    ## MI-specific reply: a stretch-signaling text.
    ## Lowercase, no punctuation effort, a small mistype she
    ## doesn't fix. The Caretaker reads it the way it reads
    ## the third step on the stairs.
    mother "ok wedneday"

    e "That is all she writes. The Caretaker reads the cadence in the seventeen-character span: lowercase, no period, a typo she did not fix. The cadence says she is starting a stretch, or already in one."

    ## State effects mirror CEN.
    $ rr_delta("self_trust", +8)
    $ rr_delta("permission", +4)
    $ rr_npc_delta("mother", -3, safe=False)

    ## MI-specific Critic activation.
    critic_voice "She is going to be in a stretch by Wednesday and you will know it was because of this."

    $ rr_delta("critic_volume", +6)

    e "The Critic is saying something the Caretaker is partially agreeing with. Both of them are working from the cadence in the text. Neither of them has the data to know."

    ## Credit Recognition — same as CEN.
    $ reco_credit("reflection_completed", "a3_cancel_the_call_mi_succeeded")

    flame "you cancelled a call with your mother. that is a specific thing that has now happened. the cadence in the reply is a separate thing."

    $ act3_outcomes["cancel_the_call"] = "sent"
    $ renpy.fix_rollback()
    jump a3_cancel_the_call_mi_close


label a3_cancel_the_call_mi_draft:
    scene black
    e "You write the text. You read it three times. You do not press send."

    e "It sits in the message composer for forty minutes. The Caretaker is, the whole forty minutes, running its forecast of what stretch-state Mother is in based on the not-sending."

    e "At six PM you delete the draft, unsent."

    $ rr_delta("self_trust", -3)
    $ rr_delta("critic_volume", +4)
    $ rr_delta("presence", +3)

    critic_voice "You never send them. You always draft and delete. You always need the ten-second check more than you need the not-cancelling."

    e "The Critic is not wrong. The noticing of this is new, even if the drafting-and-deleting is old."

    $ reco_credit("part_register_identified", "a3_cancel_draft_and_delete_pattern_mi")

    $ act3_outcomes["cancel_the_call"] = "drafted"
    $ renpy.fix_rollback()
    jump a3_cancel_the_call_mi_not_sent


label a3_cancel_the_call_mi_not_sent:
    scene black
    with fade

    ## MI-specific not_sent: welfare-check texture for the
    ## 38-minute call.
    e "The call happens at seven. It lasts thirty-eight minutes. The Caretaker is on the call too — listening for the third-step creak in her voice, the ring-count of how long it took her to start talking, the meal she did or did not have today. You are not really on the call. The Caretaker is."

    $ rr_delta("presence", -8)
    $ rr_delta("flashback_pressure", +6)
    $ rr_delta("regulation", -4)

    e "After, you put the phone face-down. You sit for a while. The Caretaker delivers its summary: probably-stretched, probably-eating-tomorrow, probably-call-the-aunt-on-Friday-if-it-doesn't-shift."

    flame "you did not cancel this week. that is information, not a verdict. the caretaker has been on for thirty-eight minutes and is, briefly, off."

    if act3_outcomes.get("cancel_the_call") != "drafted":
        $ act3_outcomes["cancel_the_call"] = "not_sent"
        $ renpy.fix_rollback()
    jump a3_cancel_the_call_mi_close


label a3_cancel_the_call_mi_close:
    scene black
    with fade
    e "The phone goes back on the counter. The week continues. The Caretaker's summary is the part of you that keeps the schedule for next week now."
    return
