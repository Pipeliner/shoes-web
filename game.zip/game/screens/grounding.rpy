## screens/grounding.rpy — one-keypress exit screen.
##
## Per PRD §4.10: "A single keypress opens a grounding screen (breathing
## count, five-senses prompt, 'close the game' button) from any scene."
## Crisis resources appear in the pause menu, localized by detected locale.
##
## Key binding is set below (G). The screen is pop-up-modal; dismissing
## returns to the scene.

init python:
    def _grounding_resources_for_locale():
        """Return a list of (name, contact) strings for the detected locale.
        Copy is clinician-reviewable (PRD §10 budget). This stub lists
        US / Russia / UK defaults; real localization lands later.

        Defensive against Ren'Py API drift: `renpy.preferences.language`
        does not exist in Ren'Py 8.5 (it did in earlier versions). Per
        playtest 2026-04-26 the original line crashed the grounding
        UI with an AttributeError, rendering the G keypress useless.
        Now we try multiple access paths and fall back to "en" on any
        failure — the grounding flow is a SAFETY surface and must never
        raise.
        """
        locale = "en"
        try:
            # Ren'Py 8.5+: _preferences is the global Preferences instance.
            locale = getattr(_preferences, "language", None) or locale
        except Exception:
            pass
        try:
            # Older API path; harmless to attempt.
            locale = getattr(renpy.preferences, "language", None) or locale
        except Exception:
            pass
        if locale in ("ru", "ru_RU"):
            return [
                ("Россия, Эмоциональная поддержка", "8-800-2000-122"),
                ("Международная: Samaritans", "116 123"),
            ]
        if locale in ("en_GB",):
            return [
                ("UK Samaritans", "116 123"),
                ("UK NHS 111", "111"),
            ]
        return [
            ("US/Canada 988 Suicide & Crisis Lifeline", "988"),
            ("US Crisis Text Line", "Text HOME to 741741"),
            ("International: Samaritans", "116 123"),
        ]


screen grounding():
    modal True
    zorder 200
    ## 1280×720 design space (gui.init in game/gui.rpy). No viewport
    ## wrapper: every viewport variant tested 2026-04-30 painted empty
    ## on web (see .claude/rules/renpy-screens.md § Viewport). Content
    ## fits the interior comfortably at the gui.scale defaults. Per
    ## clarity.md rule 7 — the player's safety surface must never clip
    ## critical text — if a future locale's crisis-resource list grows
    ## past the interior, split this screen rather than re-introducing
    ## a viewport.
    frame:
        xalign 0.5
        yalign 0.5
        xpadding gui.scale(40)
        ypadding gui.scale(36)
        xmaximum gui.scale(900)
        ymaximum gui.scale(640)
        background gui.modal_frame_background

        has vbox:
            spacing gui.scale(10)

        text _("Breathing") size gui.scale(28) color gui.accent_color
        text _("In for 4. Hold for 4. Out for 6. Again.") size gui.scale(18) italic True

        null height gui.scale(6)

        text _("Five senses") size gui.scale(22) color gui.accent_color
        text _("Name five things you can see.") size gui.scale(16)
        text _("Four you can touch.") size gui.scale(16)
        text _("Three you can hear.") size gui.scale(16)
        text _("Two you can smell.") size gui.scale(16)
        text _("One you can taste.") size gui.scale(16)

        null height gui.scale(6)

        ## Crisis resources surfaced FIRST per playthrough-clinical
        ## audit 0.1.18-32: a distressed reader may not scroll past
        ## the Quit button if it's visually higher. The safety
        ## surface's load-bearing function is the resource-list;
        ## the Quit option is a fallback and stays available.
        text _("Crisis resources") size gui.scale(20) color gui.accent_color
        for name, contact in _grounding_resources_for_locale():
            text "[name] — [contact]" size gui.scale(15)

        null height gui.scale(8)

        text _("If you want to stop playing") size gui.scale(18) color gui.accent_color
        textbutton _("Close the game"):
            action Quit(confirm=False)
            text_size gui.scale(18)

        null height gui.scale(6)

        textbutton _("back to the scene"):
            action Hide("grounding")
            text_size gui.scale(18)


## Key binding. G opens grounding from any scene.
##
## Per playtest 2026-04-26: declaring `config.keymap["grounding"]` is
## necessary but not sufficient. Ren'Py's keymap aliases only fire if
## SOMEWHERE a screen carries `key "<alias>" action ...`. Without
## that handler the alias declaration is a no-op and pressing G does
## nothing. The PRD §4.10 promise — "a single keypress opens a
## grounding screen from any scene" — therefore needs both halves:
##
##   1. The keymap alias declared (below).
##   2. An overlay screen with the `key` block bound to it
##      (`grounding_keybind` below).
##   3. The overlay screen registered as always-shown so its `key`
##      handler is live during scene playback (overlay_screens append).
##
## The `Show("grounding")` action displays the modal grounding
## screen — same effect as the (legacy, now-unused) _grounding_show
## label.
init python:
    config.keymap["grounding"] = ["K_g", "g"]

screen grounding_keybind():
    ## Always-on overlay whose only job is to listen for the
    ## `grounding` keymap alias. No visible UI; just the binding.
    key "grounding" action Show("grounding")

init python:
    config.overlay_screens.append("grounding_keybind")
