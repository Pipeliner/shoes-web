## scenes/act2/chapter4_nim.rpy — NIM-bias variant of the Flame / journal.
##
## CEN equivalent: scenes/act2/chapter4.rpy. MI equivalent:
## scenes/act2/chapter4_mi.rpy. This file mirrors the same five-
## beat structural arc (notice + opening; first-prompt menu with
## five options including the dog beat; second-prompt menu with
## three options; close; skipped). Flame's voice is identical
## across branches: lowercase, journal-companion, addresses the
## protagonist as "you" and may use "I" for its own asides.
##
## The only mechanical change vs. CEN/MI is Option 1 of the
## first-prompt menu. CEN's Option 1 names the dissociative
## firefighter as "the part of you that closed the laptop"; MI's
## as "the part of you that took you out of the room"
## (dissociation — mental departure). NIM's is the angry-
## protector firefighter: "the part of you that got you out of
## the room" — a physical departure, the body up before the
## thought is. Phrasing is anchored in chapter1_nim.rpy:131-134
## ("Get up. Get out. Now." — "You are out of the chair before
## you decided to be out of the chair") and reused in
## chapter3_nim.rpy:91 ("the part of you that got you out of
## the room" — the between-session task).
##
## Options 2-5 are branch-agnostic in copy. The NIM player's
## mental model of "a younger you" (second-prompt Option B) is
## the eleven-year-old in the dining room by the bible's branch
## coding; the prompt itself stays age-agnostic per the
## 0.1.18-14 fix at chapter4.rpy:111-113.
##
## State effects mirror chapter4.rpy: small +permission,
## +self_trust, +presence, +interoception; -critic_volume on the
## Critic-verbatim prompt.

label a2c4_nim_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c4_nim", False):
        centered "Chapter Seven — Act II (continued, NIM branch)\n\nThis chapter is a between-scene reflection. No sensitive content."
        $ chapter_notice_shown["a2c4_nim"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c4_nim_skipped

    scene black
    with dissolve

    e "It is Friday. You are at the kitchen table. The light at this hour makes the wood look warm in the way wood does not usually look warm."

    e "You open the journal. The cursor blinks the way cursors blink."

    flame "a few questions, if you want them. pick one, or skip."

    menu:
        "what did the part of you that got you out of the room need today?":
            ## The NIM angry-protector firefighter — the one that,
            ## when a room is about to contain a Mother-shape (or
            ## a Mother-cadenced critic, or a humiliation-shaped
            ## moment), gets the body up and out before the
            ## thought catches up. A physical leaving, distinct
            ## from MI's mental departure. See a2c1_nim.rpy:131
            ## ("Get up. Get out. Now.") and a2c1_nim.rpy:177
            ## ("I get you out of rooms she is in. Rooms she
            ## could be in. Rooms she has been in.").
            flame "the one that gets the body up before you decide. let it answer."
            e "You write for a while. Your knees are still. The chair is still. The writing is the only part of you that is moving."

            $ rr_delta("permission", +4)
            $ rr_delta("self_trust", +3)
            $ rr_delta("presence", +3)
            $ rr_delta("interoception", +3)
            $ reco_credit("reflection_completed", "a2c4_nim_caretaker_needs")

            flame "that was not a small thing you just did."
            jump a2c4_nim_second_prompt

        "what did a smaller voice inside you say, that you did not write down?":
            flame "you can leave this one unwritten."
            e "You do. You notice the not-writing."

            $ rr_delta("presence", +5)
            $ rr_delta("interoception", +5)
            $ reco_credit("part_register_identified", "a2c4_nim_exile_unwritten")

            flame "noticing without writing is a kind of writing. a different one."
            jump a2c4_nim_second_prompt

        "what did the critic say this week — word for word, not the gist?":
            ## The NIM Critic borrows Mother's specific cadences
            ## (per docs/continuity.md:556-559: "New Critic lines
            ## on NIM should reuse Mother's specific cadences,
            ## not generic critic register"). Lines like *"You
            ## could have handled it. You are not a child."*
            ## (a1c2_nim:214) and *"You archive. You always
            ## archive. You will archive your mother."*
            ## (a2c1_nim:219) are the verbatim shapes the
            ## protagonist would write down here. The flame
            ## intro names the borrowing-from-mother register
            ## without naming Mother diagnostically.
            flame "verbatim is useful. the gist smooths things. the cadence she borrows is part of the verbatim."
            e "You write the verbatim. The words land on the page differently than they land in the head. You can hear whose phrasing they are wearing."

            $ rr_delta("critic_volume", -6)
            $ rr_delta("self_trust", +4)
            $ rr_delta("permission", +3)
            $ reco_credit("reflection_completed", "a2c4_nim_critic_verbatim")

            flame "on the page, that one is smaller than it is in your head."
            jump a2c4_nim_second_prompt

        "just sit with it; no question today":
            flame "ok."
            e "The cursor blinks. The light stays warm on the wood."
            pause 1.0
            $ rr_delta("presence", +4)
            $ rr_delta("regulation", +4)
            jump a2c4_nim_close

        "what about the small one who waited for the dog who did not come back?":
            ## Branch-neutral childhood-attachment-loss prompt.
            ## Per docs/continuity.md "Childhood pet (Mishka,
            ## given away)": age 7, branch-neutral abandonment-
            ## template anchor that does not collide with the
            ## three branch childhood signatures (CEN
            ## yellow-wallpaper kitchen at 13, MI hallway-with-
            ## telephone-table at 8, NIM dining-room-with-six-
            ## adults at 11). The figure who took the dog is
            ## unnamed; the abandonment-template is the
            ## figure-and-the-going, not who-did-it. Exile-voice
            ## register per parts-language.md.
            flame "the small one who watched the door for a long time. let her answer."

            exile_voice "Mishka has a leash. The leash hangs on a hook by the door."

            exile_voice "I am seven. I am in the chair near the door because the chair near the door is where you wait."

            exile_voice "My shoes are still on. You don't take your shoes off when you're waiting."

            exile_voice "On Saturday someone takes Mishka somewhere. Someone comes back. Mishka does not come back."

            exile_voice "The hook is empty. The hook stays empty. I look at it for a long time."

            e "You are at the kitchen table. The light is still warm on the wood. You write, slowly, what the small one in the chair would not have known how to write."

            $ rr_delta("permission", +4)
            $ rr_delta("interoception", +4)
            $ rr_delta("self_trust", +3)
            $ reco_credit("part_register_identified", "a2c4_nim_dog_given_away")

            flame "you sat in the chair with her for a minute. that is what the page was for."
            jump a2c4_nim_second_prompt


label a2c4_nim_second_prompt:
    ## Optional second prompt. Recognition source; cheaper than
    ## the first — avoiding grinding.
    flame "one more, if you want it."

    menu:
        "say what you would have said to lena this week, and didn't":
            e "You write what you would have said. It is not elegant. It is not the point."
            $ rr_delta("permission", +3)
            $ rr_delta("self_trust", +3)
            $ reco_credit("reflection_completed", "a2c4_nim_unsaid_to_lena")
            flame "it does not need to be elegant. it needs to exist."
            jump a2c4_nim_close

        "say what you would have said to a younger you":
            ## Age-agnostic on purpose, per the 0.1.18-14 fix at
            ## chapter4.rpy:111-113. The NIM player's mental
            ## model is the eleven-year-old in the dining room
            ## with six adults; the prompt does not name the
            ## age.
            e "You write a short sentence. Five words. You cross them out. You write them again."
            $ rr_delta("permission", +4)
            $ rr_delta("self_trust", +4)
            $ rr_delta("critic_volume", -3)
            $ reco_credit("part_register_identified", "a2c4_nim_younger_self_letter")
            flame "you will not always have the words. you wrote them this time."
            jump a2c4_nim_close

        "close the journal":
            flame "ok. another friday."
            jump a2c4_nim_close


label a2c4_nim_close:
    scene black
    with fade

    ## Owner of `chapter_completed["a2c4_nim"]` per
    ## docs/state-ownership.md: set FIRST after `scene black`,
    ## before any prose. The skipped label does NOT set this
    ## flag — that is the point.
    $ chapter_completed["a2c4_nim"] = True

    flame "the friday pages are for noticing, not fixing."
    flame "you noticed. that is the whole assignment."

    e "You close the laptop. The afternoon is the afternoon. Your feet are not cold today."

    menu:
        "continue to Chapter Eight (NIM)":
            jump a2c5_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c4_nim_skipped:
    scene black
    centered "Chapter Seven (NIM variant) was skipped."
    pause 1.5
    e "Friday was Friday. You did not write."
    e "There is no penalty for not writing. The journal is still there, next week."

    menu:
        "continue to Chapter Eight (NIM)":
            jump a2c5_nim_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
