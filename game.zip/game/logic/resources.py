"""Resource system.

Ten primary resources + two hidden sub-resources (Lisa Feldman Barrett framing).
Five reactive pairs. Three threshold bands with delta multipliers.
Branch bias (CEN / MI / NIM) alters decay rates and trigger thresholds.

Every resource is an int in [0, 100]. Everything here is plain Python and
pickle-safe. No lambdas as instance fields. No closures on instances.

Design notes (per PRD §4.5):
- "window_of_tolerance" renamed to `regulation` in the UI; we keep the
  legacy key internally for backward compat on saved games.
- "dissociation" inverted to `presence` (high = present). The UI shows
  presence rising, not dissociation accumulating.
- The psychiatric-adjacent keys (CRITIC_VOLUME, PRESENCE, etc.) are
  internal keys. The UI surfaces descriptive, relational nouns.
- `body_budget` never surfaces as a number in the UI.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field, replace
from typing import Mapping


# ---------------------------------------------------------------------------
# Resource identity
# ---------------------------------------------------------------------------


class Resource(str, enum.Enum):
    """The ten primary resources + two hidden sub-resources.

    Using str-valued enum so the values pickle cleanly and serialise to
    JSON without a custom encoder.
    """

    # Structural
    ENERGY = "energy"
    SOCIAL_BATTERY = "social_battery"
    REGULATION = "regulation"  # was window_of_tolerance

    # State-adjacent
    FLASHBACK_PRESSURE = "flashback_pressure"  # was emotional_flashback
    PRESENCE = "presence"  # was dissociation, inverted so high = present
    THREAT_SCAN = "threat_scan"  # was hypervigilance

    # Parts-facing
    CRITIC_VOLUME = "critic_volume"  # was inner_critic

    # Relational
    SELF_TRUST = "self_trust"
    CONNECTION = "connection"  # was attachment_safety; per-NPC avg feeds global
    PERMISSION = "permission"  # was internal_permission; gates exile access

    # Hidden sub-resources (Barrett framing)
    INTEROCEPTION = "interoception"  # ability to read internal signals
    BODY_BUDGET = "body_budget"  # metabolic accounting; slow-moving


PRIMARY_RESOURCES: tuple[Resource, ...] = (
    Resource.ENERGY,
    Resource.SOCIAL_BATTERY,
    Resource.REGULATION,
    Resource.FLASHBACK_PRESSURE,
    Resource.PRESENCE,
    Resource.THREAT_SCAN,
    Resource.CRITIC_VOLUME,
    Resource.SELF_TRUST,
    Resource.CONNECTION,
    Resource.PERMISSION,
)

HIDDEN_RESOURCES: tuple[Resource, ...] = (
    Resource.INTEROCEPTION,
    Resource.BODY_BUDGET,
)

# Resources where "higher is worse" (we want low values).
INVERTED_RESOURCES: frozenset[Resource] = frozenset({
    Resource.FLASHBACK_PRESSURE,
    Resource.THREAT_SCAN,
    Resource.CRITIC_VOLUME,
})


# ---------------------------------------------------------------------------
# Threshold bands
# ---------------------------------------------------------------------------


class Band(str, enum.Enum):
    RESOURCED = "resourced"
    STRETCHED = "stretched"
    DEPLETED = "depleted"


# For "higher is better" resources, resourced >= 60, stretched 30-59, depleted < 30.
# For "higher is worse" resources (inverted), the bands flip:
#   resourced <= 30, stretched 31-59, depleted >= 60.
RESOURCED_THRESHOLD = 60
STRETCHED_THRESHOLD = 30

# Band-specific delta multipliers from PRD §4.5 "Threshold regimes".
#   Resourced: ×1.0 both directions, option set widest, parts quiet.
#   Stretched: ×1.3 toward worse, option set narrows, parts speak more often.
#   Depleted: ×1.6 toward worse, ×0.7 toward better, sharp restriction.
BAND_MULTIPLIERS: Mapping[Band, tuple[float, float]] = {
    # (worse_multiplier, better_multiplier)
    Band.RESOURCED: (1.0, 1.0),
    Band.STRETCHED: (1.3, 1.0),
    Band.DEPLETED: (1.6, 0.7),
}


def band_for(resource: Resource, value: int) -> Band:
    """Compute the threshold band for a resource at its current value."""
    inverted = resource in INVERTED_RESOURCES
    if inverted:
        if value <= STRETCHED_THRESHOLD:
            return Band.RESOURCED
        if value < RESOURCED_THRESHOLD:
            return Band.STRETCHED
        return Band.DEPLETED
    if value >= RESOURCED_THRESHOLD:
        return Band.RESOURCED
    if value >= STRETCHED_THRESHOLD:
        return Band.STRETCHED
    return Band.DEPLETED


# ---------------------------------------------------------------------------
# Parental branch biases (CEN / MI / NIM)
# ---------------------------------------------------------------------------


class Branch(str, enum.Enum):
    CEN = "cen"  # childhood emotional neglect; fawn-biased
    MI = "mi"    # mentally ill parent; freeze/dissociation-biased
    NIM = "nim"  # narcissistic/immature parent; fight/flight, critic spikes


# Per PRD §4.5 "4F fawn-pull per parental branch":
#   - CEN biases fawn_active as default stress response (slower CONNECTION decay
#     in safe scenes, faster CRITIC_VOLUME when a relationship is threatened).
#   - MI biases dissociative_spell (faster PRESENCE loss under stress; slower
#     INTEROCEPTION regeneration).
#   - NIM biases CRITIC_VOLUME spikes and fight/flight (faster THREAT_SCAN gain).
# Bias is expressed as multiplicative modifiers on incoming deltas, not
# as locked behaviours. A CEN protagonist can still freeze, just less often
# by default.
BRANCH_BIAS: Mapping[Branch, Mapping[Resource, tuple[float, float]]] = {
    Branch.CEN: {
        # (worse_mult, better_mult)
        Resource.CRITIC_VOLUME: (1.2, 0.9),
        Resource.SELF_TRUST: (1.15, 0.85),
        Resource.CONNECTION: (0.9, 1.1),
    },
    Branch.MI: {
        Resource.PRESENCE: (1.3, 0.8),
        Resource.INTEROCEPTION: (1.2, 0.8),
        Resource.FLASHBACK_PRESSURE: (1.2, 1.0),
    },
    Branch.NIM: {
        Resource.THREAT_SCAN: (1.3, 0.85),
        Resource.CRITIC_VOLUME: (1.3, 0.85),
        Resource.REGULATION: (1.2, 0.9),
        # PRD amendment A14, audit P-3 option (a) closure
        # (0.1.18-46): NIM permission-bias counters the
        # CRITIC_VOLUME ×1.3 amplification's downstream effect
        # on permission via the critic_volume↔permission inverse
        # reactive pair. Layered on top of A13's depleted-band
        # ASK bonus (which fires only in depleted band; this
        # bias also helps in stretched). Tuning rationale: 0.7
        # worse_mult mirrors the depleted-band better_multiplier
        # (×0.7); 1.3 better_mult mirrors NIM's existing
        # CRITIC_VOLUME worse_multiplier in shape. Branch-blind
        # CRITIC_VOLUME (1.3, 0.85) preserved per P-9 typology
        # closure — only PERMISSION is biased here.
        Resource.PERMISSION: (0.5, 1.5),
    },
}


# ---------------------------------------------------------------------------
# Reactive pairs
# ---------------------------------------------------------------------------


# Five reactive pairs. Movement in one drives opposing or amplifying movement
# in the other. See PRD §4.5 "Reactive pairs".
#
# Each pair is a tuple:
#   (source, target, mode, coefficient)
# where:
#   mode="inverse"  -> delta to source of +X causes target delta of -X*coef
#   mode="amplify"  -> delta to source of +X causes target delta of +X*coef
#   mode="context"  -> handled by scene code (positive-sum / negative-sum
#                      depends on who the other character is). Listed here
#                      for completeness; not auto-applied.
@dataclass(frozen=True)
class ReactivePair:
    source: Resource
    target: Resource
    mode: str  # "inverse", "amplify", "context"
    coefficient: float

    def apply(self, delta_to_source: int) -> int:
        """Return the delta to apply to the target for this source delta."""
        if self.mode == "inverse":
            return int(round(-delta_to_source * self.coefficient))
        if self.mode == "amplify":
            return int(round(delta_to_source * self.coefficient))
        # "context" is not auto-applied; scene code handles it.
        return 0


REACTIVE_PAIRS: tuple[ReactivePair, ...] = (
    # 1. critic_volume ↔ self_trust — inverse; critic spikes suppress trust.
    ReactivePair(Resource.CRITIC_VOLUME, Resource.SELF_TRUST, "inverse", 0.5),
    # 2. threat_scan ↔ presence — inverse; hypervigilance reduces presence.
    ReactivePair(Resource.THREAT_SCAN, Resource.PRESENCE, "inverse", 0.5),
    # 3. social_battery ↔ connection — context-sensitive; scene code handles.
    ReactivePair(Resource.SOCIAL_BATTERY, Resource.CONNECTION, "context", 0.0),
    # 4. flashback_pressure ↔ regulation — inverse; regulation buffers pressure.
    ReactivePair(Resource.FLASHBACK_PRESSURE, Resource.REGULATION, "inverse", 0.5),
    # 5. permission ↔ critic_volume — inverse; critic gates permission.
    ReactivePair(Resource.CRITIC_VOLUME, Resource.PERMISSION, "inverse", 0.5),
)


# ---------------------------------------------------------------------------
# Snapshot dataclass — the saveable state object
# ---------------------------------------------------------------------------


def _default_values() -> dict[Resource, int]:
    """Starting values. Protagonist begins stretched, not depleted, not resourced."""
    return {
        Resource.ENERGY: 45,
        Resource.SOCIAL_BATTERY: 50,
        Resource.REGULATION: 50,
        Resource.FLASHBACK_PRESSURE: 20,
        Resource.PRESENCE: 55,
        Resource.THREAT_SCAN: 35,
        Resource.CRITIC_VOLUME: 55,
        Resource.SELF_TRUST: 35,
        Resource.CONNECTION: 45,
        Resource.PERMISSION: 30,
        Resource.INTEROCEPTION: 40,
        Resource.BODY_BUDGET: 50,
    }


@dataclass
class ResourceSnapshot:
    """Pickle-safe snapshot of resource state.

    Fields are a plain dict and a string branch key. No lambdas, no closures,
    no inner functions. Use `replace(snapshot, ...)` or
    `snapshot.with_delta(...)` to produce new snapshots.

    The `connection_per_npc` dict stores per-NPC Connection values. The global
    `Resource.CONNECTION` value is the average of per-NPC values when any
    exist, else the standalone value in `values`.
    """

    values: dict[Resource, int] = field(default_factory=_default_values)
    connection_per_npc: dict[str, int] = field(default_factory=dict)
    branch: Branch = Branch.CEN

    def __post_init__(self) -> None:
        # Fill in any missing resources with defaults. This handles migrating
        # old saves that pre-date a newly-added resource.
        defaults = _default_values()
        for r in defaults:
            self.values.setdefault(r, defaults[r])
        # Clamp anything out of range (pickled saves may be stale).
        for r, v in list(self.values.items()):
            self.values[r] = _clamp(v)

    def get(self, resource: Resource) -> int:
        """Read a resource. For CONNECTION with per-NPC entries, returns avg."""
        if resource is Resource.CONNECTION and self.connection_per_npc:
            vals = list(self.connection_per_npc.values())
            return int(round(sum(vals) / len(vals)))
        return self.values[resource]

    def band(self, resource: Resource) -> Band:
        return band_for(resource, self.get(resource))

    def connection_with(self, npc: str) -> int:
        """Per-NPC Connection. Defaults to 30 for a new acquaintance."""
        return self.connection_per_npc.get(npc, 30)

    def with_delta(self, resource: Resource, delta: int) -> "ResourceSnapshot":
        """Return a new snapshot with delta applied (including band & branch bias
        amplification and reactive-pair propagation).

        This is the function to use in scenes. It composes:
          1. Branch-bias multiplier on the incoming delta.
          2. Band-of-current-value multiplier on the (now-biased) delta.
          3. Apply to the primary resource, clamping to [0, 100].
          4. Propagate to reactive-pair targets (using the *pre-propagation*
             source delta, not the chained deltas — we don't want
             oscillations).
        """
        biased = _apply_branch_bias(self.branch, resource, delta)
        current = self.get(resource)
        band = band_for(resource, current)
        amplified = _apply_band_multiplier(resource, band, biased)
        new_values = dict(self.values)
        new_values[resource] = _clamp(current + amplified)
        # Reactive-pair propagation — use the biased-but-not-band-amplified
        # delta so pair coefficients remain predictable.
        for pair in REACTIVE_PAIRS:
            if pair.source is resource and pair.mode != "context":
                target_delta = pair.apply(biased)
                if target_delta != 0:
                    target_current = new_values.get(
                        pair.target, _default_values()[pair.target]
                    )
                    target_band = band_for(pair.target, target_current)
                    target_amplified = _apply_band_multiplier(
                        pair.target, target_band, target_delta
                    )
                    new_values[pair.target] = _clamp(target_current + target_amplified)
        return replace(self, values=new_values)

    def with_npc_connection_delta(
        self, npc: str, delta: int, safe: bool
    ) -> "ResourceSnapshot":
        """Apply a delta to a specific NPC's Connection.

        The social_battery<->connection pair is context-sensitive: positive-sum
        in safe scenes, negative-sum in unsafe scenes. We model that here.
        """
        current = self.connection_with(npc)
        # Branch bias applies to CONNECTION generally.
        biased = _apply_branch_bias(self.branch, Resource.CONNECTION, delta)
        band = band_for(Resource.CONNECTION, current)
        amplified = _apply_band_multiplier(Resource.CONNECTION, band, biased)
        new_npc = dict(self.connection_per_npc)
        new_npc[npc] = _clamp(current + amplified)
        # Social-battery consumption: safe scenes reduce it less, unsafe more.
        sb_cost = -3 if safe else -7
        new_values = dict(self.values)
        sb_current = new_values[Resource.SOCIAL_BATTERY]
        sb_band = band_for(Resource.SOCIAL_BATTERY, sb_current)
        sb_amplified = _apply_band_multiplier(
            Resource.SOCIAL_BATTERY, sb_band, sb_cost
        )
        new_values[Resource.SOCIAL_BATTERY] = _clamp(sb_current + sb_amplified)
        return replace(
            self, values=new_values, connection_per_npc=new_npc
        )


# ---------------------------------------------------------------------------
# Internal helpers (module-level, pickle-friendly)
# ---------------------------------------------------------------------------


def _clamp(v: int) -> int:
    if v < 0:
        return 0
    if v > 100:
        return 100
    return v


def _is_worse(resource: Resource, delta: int) -> bool:
    """A delta is 'worse' if it moves the resource in the bad direction.

    For inverted resources (FLASHBACK_PRESSURE, THREAT_SCAN, CRITIC_VOLUME),
    'worse' = positive delta. For others, 'worse' = negative delta.
    """
    if resource in INVERTED_RESOURCES:
        return delta > 0
    return delta < 0


def _apply_band_multiplier(resource: Resource, band: Band, delta: int) -> int:
    worse_mult, better_mult = BAND_MULTIPLIERS[band]
    mult = worse_mult if _is_worse(resource, delta) else better_mult
    return int(round(delta * mult))


def _apply_branch_bias(branch: Branch, resource: Resource, delta: int) -> int:
    bias_map = BRANCH_BIAS.get(branch, {})
    if resource not in bias_map:
        return delta
    worse_mult, better_mult = bias_map[resource]
    mult = worse_mult if _is_worse(resource, delta) else better_mult
    return int(round(delta * mult))


__all__ = [
    "Band",
    "Branch",
    "BRANCH_BIAS",
    "BAND_MULTIPLIERS",
    "HIDDEN_RESOURCES",
    "INVERTED_RESOURCES",
    "PRIMARY_RESOURCES",
    "REACTIVE_PAIRS",
    "ReactivePair",
    "Resource",
    "ResourceSnapshot",
    "band_for",
]
