# GEN-CHECKSUM: debd95e0e04cb9e7
## Flashback snippets — technique: sensory_pivot
## A specific sensory particular pivots the narration into the past.
##
## Generated from sensory_pivot.yaml. Hand-edit below the
## GEN-CHECKSUM line preserved by --force only.
##
## This file is a reference catalog, not live scene code.
## Scene authors grep for snippet IDs, then hand-adapt
## the prose into the target scene's voice. Do not
## import this file or reference its contents at runtime.

## --- snippet: kettle_pitch ---
## anchor_type:
##   'sound'
## anchor:
##   'the pitch of the kettle at the specific boil-stop moment'
## target_era:
##   "childhood: mother's kitchen on weekday mornings"
## pivot:
##   'The kettle clicks off.'
## past_lines:
##   - "The kettle in your mother's kitchen clicked off the same way, eight years ago. She was at the counter. She did not turn around."
##   - 'You remember hearing her breath.'
## return:
##   'You pour the water. The tea bag darkens. You are thirty-four and you have a kettle in your own apartment.'

## --- snippet: wallpaper_yellow ---
## anchor_type:
##   'sight'
## anchor:
##   'a wallpaper pattern in a periphery you were not looking at'
## target_era:
##   'childhood: the apartment with the yellow wallpaper'
## pivot:
##   'You are looking at the wall.'
## past_lines:
##   - 'The apartment had yellow wallpaper.'
##   - 'The wallpaper had a pattern that was not quite a pattern.'
## return:
##   'You look away. The wall you are looking at is white.'

## --- snippet: laundry_detergent ---
## anchor_type:
##   'smell'
## anchor:
##   'a specific laundry detergent at a specific dilution'
## target_era:
##   "childhood: after school, folding someone else's clothes"
## pivot:
##   'The shirt smells the way it smells.'
## past_lines:
##   - 'You folded laundry at the kitchen table on Thursdays.'
##   - 'You folded it the way you were taught to fold it, which was not wrong.'
## return:
##   'You put the shirt back on the shelf. You are in your own bedroom.'

