## scenes/act2/chapter1_mi.rpy — Act II Ch 1 MI-branch variant.
##
## CEN Act II Ch 1 uses the numb-out firefighter that seizes when
## flashback pressure crosses threshold. MI branch uses the
## *dissociative* firefighter established in a1c3_mi. Both achieve
## the same PRD §4.6 Firefighter Turn mechanic (the next player
## choice is replaced with a part-authored action) but with
## different prose texture:
##   - CEN numb-out: "Close the laptop. You close the laptop."
##   - MI dissociative: "you are somewhere mostly-not-here now."
##
## The scene structurally mirrors a2c1 (opening the aunt's email,
## firefighter turn, negotiation) so the Act III dispatcher +
## endings continue to work on either path.

label a2c1_mi_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c1_mi", False):
        centered "Chapter Four — Act II begins (MI branch)\n\nThis chapter opens on an email from the protagonist's aunt reporting that Mother is currently in the hospital after a fall, and is stable. The chapter contains a brief childhood flashback written as intrusive partials (no visual effect). The MI-branch firefighter activates as dissociation rather than numbing. Nothing graphic."
        $ chapter_notice_shown["a2c1_mi"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c1_mi_skipped

    scene black
    with dissolve

    e "The email has been unopened for a day and a part of a day."

    e "Your aunt's name in your inbox is a particular kind of silence."

    e "Your aunt has been sending these for as long as you have had an inbox to receive them. Before that, on paper. She is the person in the family who, when nobody is going to say the obvious thing, sends a sentence that at least notes it."

    ## Pre-raise firefighter intensity so the seize fires when the
    ## email opens. Mirrors the CEN Ch 1 preseed — same threshold,
    ## different part texture.
    python:
        from logic.parts import Part, PartKind
        _numb = parts_state.get("numb-out")
        parts_state = parts_state.with_part(Part(
            name=_numb.name, kind=_numb.kind, introduced=True,
            trust_in_self=_numb.trust_in_self,
            consented_for_exile=_numb.consented_for_exile,
            intensity=70,  # approaching seize threshold (75)
        ))

    menu:
        "open the email":
            jump a2c1_mi_open
        "mark it read and archive it without opening":
            jump a2c1_mi_archive
        "delete it":
            jump a2c1_mi_delete


label a2c1_mi_open:
    scene black
    e "You click. The subject line is 'Your mother.'"
    e "The body is short."
    e "She writes that your mother had a fall. She writes that your mother is in the hospital. She writes that your mother is stable."
    e "She writes that she thought you should know."

    e "She closes the way she always closes — {i}she thought you should know{/i} — and the way she always closes is also the way she always declines to advise."

    $ rr_delta("flashback_pressure", +18)
    $ rr_delta("threat_scan", +12)
    $ rr_delta("regulation", -10)
    $ rr_delta("energy", -6)

    ## Intrusive partial per flashbacks/intrusive_partial.yaml —
    ## the MI-specific memory. Two sentences mid-paragraph.
    ## Flashback uses intrusive_partial.closed_door_ninety_seconds
    e "You read the word 'stable' three times in a row."

    e "You stood outside her door for ninety seconds before you knocked. You had counted to ninety before knocking. You had chosen ninety because it was the longest you had ever managed."

    e "You are not eight. You are reading an email. Your hand is on the mouse."

    ## Bump firefighter to seize threshold — same as CEN variant.
    python:
        _numb = parts_state.get("numb-out")
        parts_state = parts_state.with_part(Part(
            name=_numb.name, kind=_numb.kind, introduced=True,
            trust_in_self=_numb.trust_in_self,
            consented_for_exile=_numb.consented_for_exile,
            intensity=85,
        ))

    if pp_firefighter_seizing():
        ## MI-flavour firefighter turn: dissociation, not closing
        ## the laptop.
        firefighter_voice "I am taking you out for a little while."
        e "You are somewhere mostly-not-here for maybe a minute. Maybe four minutes. The kitchen clock, when you look up, says the same thing it said before, or else it says something you did not see a minute ago."
        e "The laptop is still open. The email is still up. Your hand has not moved."
        $ rr_delta("presence", -14)
        $ rr_delta("flashback_pressure", -3)
        jump a2c1_mi_after_firefighter
    else:
        jump a2c1_mi_after_open


label a2c1_mi_after_firefighter:
    scene black
    e "It is later. Not by much. By enough."

    e "The kitchen has gotten a little darker. The laptop screen has dimmed itself twice. You stand up. You close the laptop."

    e "You stand in the kitchen for a minute with your hands on the countertop. The countertop is a countertop."

    $ rr_delta("presence", +3)
    $ rr_delta("interoception", +4)

    firefighter_voice "Sorry. That's what I do."

    ## Negotiation with the dissociative-firefighter variant.
    $ intervention = renpy.call_screen(
        "negotiate",
        part_name="numb-out",
        opening_line="Sorry. That's what I do.",
    )
    if intervention is None:
        $ intervention = ("defer", "numb-out")
    $ response_key = pp_intervene(intervention[0], intervention[1])

    if response_key == "numb-out_asked_intent":
        firefighter_voice "I take you out of the room when you cannot stay in the room. I have been doing this since you were very small and you could not leave a room you could not stay in."
        e "The Firefighter does not apologise a second time. It does not need to."
    elif response_key == "numb-out_listened_to":
        firefighter_voice "Okay. I'm here."
        e "The Firefighter settles a little. Not away; here."
    elif response_key == "numb-out_deferred_to":
        firefighter_voice "Thank you."
    elif response_key == "numb-out_overridden":
        firefighter_voice "..."
        e "You re-open the laptop. The email is still there. You read it twice more. The Firefighter does not speak for a while after."

    jump a2c1_mi_reflection


label a2c1_mi_after_open:
    scene black
    e "You stay with the email. You do not reply yet. You do not have to reply yet."
    jump a2c1_mi_reflection


label a2c1_mi_archive:
    scene black
    e "You archive the email without opening it."
    $ rr_delta("critic_volume", +12)
    $ rr_delta("self_trust", -8)
    critic_voice "You always archive. You always archive and you always forget, and then the forgetting becomes the next thing you have to not think about."
    e "You do not know, in that moment, whether the Critic is right or wrong. You know only that it is loud and in a specific register."
    jump a2c1_mi_reflection


label a2c1_mi_delete:
    scene black
    e "You delete the email."
    e "Deleted emails are not really deleted. You know this. A part of you knows this too."

    $ rr_delta("critic_volume", +8)
    $ rr_delta("flashback_pressure", +10)

    e "It is, for a few hours, as if the email was never sent."
    e "Your aunt knows it was. Your mother, in a hospital, knows it was."
    e "A part of you knows it was."

    jump a2c1_mi_reflection


label a2c1_mi_reflection:
    scene black
    with fade

    flame "the dissociative part of you has worked since you were very small. today it worked. noticing the working — when it happens and what it takes you out of — is the work of the rest of the chapters."

    ## Feeling wheel for Act II entry.
    $ feeling = renpy.call_screen("reflection_feeling_wheel", event_id="a2c1_mi_feeling")
    e "The next scene — the one with the child — is held closed for now. It will only open if, in the scenes between, both the part of you that takes care of others first and the part of you that takes you out of rooms have, separately, said yes."

    menu:
        "continue to Chapter Five (MI)":
            jump a2c2_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c1_mi_skipped:
    scene black
    centered "Chapter Four (MI variant) was skipped."
    pause 1.5
    e "The email was there. Time passed. You read it later, or you did not."

    menu:
        "continue to Chapter Five (MI)":
            jump a2c2_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
