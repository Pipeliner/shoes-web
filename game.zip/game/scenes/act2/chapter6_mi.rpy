## scenes/act2/chapter6_mi.rpy — movement practice (MI variant).
##
## Mirrors the structural arc of CEN `chapter6.rpy` (one
## instructor NPC, three opener choices, mid-class noticing,
## stay-after-class) but the prose lands on an MI-specific
## texture: the stretch-watcher Caretaker reads the studio's
## quiet differently than the apartment's quiet. At home,
## quiet can *mean* a stretch — Mother not picking up, the
## third step on the stairs not having creaked. On the studio
## floor, quiet is just quiet. There is no pitch to read. The
## stretch-watcher does not have its job here, and the body
## notices the not-scanning before it notices anything else.
##
## Per chapter6 craft discipline:
##   - No new flashbacks.
##   - No "healing" language.
##   - Specific body sensations.
##   - The class is "movement practice" — not yoga, not
##     therapy, not somatic work.
##   - No parts activation in the foreground (the stretch-
##     watcher is *referenced as quiet*, not given the floor).
##
## State effects mirror CEN line-for-line; the simulator
## applies BRANCH_BIAS[MI] (INTEROCEPTION ×0.8 better,
## PRESENCE ×0.8 better) on top. Authored deltas unchanged
## from chapter6.rpy.

label a2c6_mi_start:
    scene black
    show screen tooltip_overlay

    if not chapter_notice_shown.get("a2c6_mi", False):
        centered "Chapter Nine — Act II (continued, MI branch)\n\nA short movement-practice class scene. No sensitive content."
        $ chapter_notice_shown["a2c6_mi"] = True
        pause 2.0

    menu:
        "continue":
            pass
        "skip this chapter":
            jump a2c6_mi_skipped

    scene black
    with dissolve

    e "Tuesday evening. The studio is above a cafe, up a flight of stairs that turns twice."

    e "You are here because someone you vaguely know said it was worth trying. You have been here five times. This is the sixth."

    e "The floor is wood. The windows are open. It is not quite warm yet."

    ## MI-specific opening register: the stretch-watcher's
    ## absence-of-job. The Caretaker has been on for years; on
    ## the studio floor it has nothing to scan for, and the
    ## protagonist notices the not-scanning before she notices
    ## anything else. Per the craft discipline, the part is
    ## referenced (as quiet), not given the floor.
    e "There are seven other people in the room and you have not, on the way in, run a count of how many of them are in arms-reach of you. You notice the not-counting on the second step away from the door."

    e "The part of you that has been running room-inventories since you were eight is, in this room, on Tuesday evenings, off-shift. It is the only hour in the week that is reliably true."

    instructor "Let's start on the floor tonight. Wherever you want to be."

    e "You find a place near a wall. You do not need to be near a wall anymore, but it is habit."

    menu:
        "lie down on your back":
            jump a2c6_mi_supine
        "sit crossed-legged":
            jump a2c6_mi_cross_legged
        "stand; not ready for the floor":
            jump a2c6_mi_standing


label a2c6_mi_supine:
    scene black
    e "You lie down. The floor is warmer than the air."

    instructor "Let your weight be weight. Nothing to hold up."

    pause 1.0

    ## MI-flavoured noticing — the stretch-watcher is
    ## off-shift, so the body gets to be the body without the
    ## inventory running underneath. Specific to MI: the
    ## *quiet* itself is the notable sensation, not the
    ## sensation it usually masks.
    e "Your left shoulder is half a centimetre higher than your right. You do not know how you know this."

    e "The shoulder has been doing something — bracing, scanning, listening for the third step on the stairs at your mother's house from twenty-three years ago. It is, briefly, not doing that. The not-doing is what your shoulder feels like when your shoulder is allowed to feel like a shoulder."

    $ rr_delta("presence", +6)
    $ rr_delta("interoception", +8)
    $ rr_delta("regulation", +5)

    jump a2c6_mi_middle


label a2c6_mi_cross_legged:
    scene black
    e "You sit. Your knees are higher than you remember knees being."

    instructor "See if there's a place the breath goes that isn't the chest tonight."

    pause 1.0

    ## MI-flavoured noticing on the cross-legged path.
    e "The breath goes to a specific spot under your left rib that you were not aware you had a specific spot under."

    e "The spot has been carrying something. It is, briefly, not. The breath finds it because the breath has not been finding it, in the apartment, with the phone face-down on the kitchen table."

    $ rr_delta("presence", +5)
    $ rr_delta("interoception", +7)
    $ rr_delta("regulation", +4)

    jump a2c6_mi_middle


label a2c6_mi_standing:
    scene black
    e "You stand by the wall. The wall is cool. The back of your head rests against it."

    instructor "Standing is also available."

    e "You appreciate the instructor for not making standing a thing."

    ## MI-flavoured noticing on standing.
    e "The wall behind your head is doing the work the listening usually does. The listening is not running. The wall is. Your head agrees with the wall, briefly, in a way it does not agree with much."

    $ rr_delta("presence", +4)
    $ rr_delta("interoception", +5)
    $ rr_delta("regulation", +3)

    jump a2c6_mi_middle


label a2c6_mi_middle:
    scene black
    with fade

    e "The class moves slowly. The instructor does not narrate much. You move with the class or don't, as the instructor has said you can."

    instructor "Find one place in the body that was tight when you came in, and that isn't, now. Or find one that was tight when you came in, and still is. Either is fine."

    pause 1.0

    menu:
        "find one that has let go":
            ## MI-flavour: the jaw IS the listening apparatus.
            ## The MI Caretaker reads pitch through a phone
            ## via the same muscles that hold a jaw closed
            ## while listening. When the listening is off, the
            ## jaw discovers it has been doing something.
            e "You find one. The back of your jaw. The jaw has been listening for a long time. Listening is a thing the jaw does without your permission. Tonight, briefly, it does not have to."
            $ rr_delta("self_trust", +2)
            $ reco_credit("reflection_completed", "a2c6_mi_noticed_release")
            jump a2c6_mi_close

        "find one that is still tight":
            ## MI-flavour: the sternum-tight is the
            ## listening's seat. It is on tonight too.
            e "You find one. The place at the base of your sternum. You have felt this particular tight for a long time. The listening lives there. The listening did not get the memo about Tuesday evenings."
            $ rr_delta("presence", +3)
            $ reco_credit("part_register_identified", "a2c6_mi_noticed_holding")
            jump a2c6_mi_close

        "don't find one; just lie here":
            e "You just lie there. The instructor does not mind. The class does not mind. The hour is a specific hour. It is the hour the inventory is not running. That is the hour."
            $ rr_delta("regulation", +3)
            jump a2c6_mi_close


label a2c6_mi_close:
    scene black
    with fade

    $ chapter_completed["a2c6_mi"] = True

    instructor "That's the hour. Stay as long as you want."

    e "You stay ten more minutes. You do not want to be the first one out the door."

    e "The stairs back down to the cafe are the same stairs. Your feet know them now."

    ## MI-specific close: the listening will turn back on
    ## somewhere on the walk home. The hour was the hour.
    e "The inventory will be back. Probably by the time you reach your front door. Probably by the kettle. The inventory has been with you since before you had words for it; it is not, mostly, going anywhere."

    e "But you got an hour. You always get the hour. The Tuesday-evening hour."

    $ rr_delta("self_trust", +2)

    flame "tuesdays have a smaller friction than the other days. you noticed that. it is an old noticing by now."

    menu:
        "continue to Chapter Ten (MI)":
            jump a2c7_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return


label a2c6_mi_skipped:
    scene black
    centered "Chapter Nine (MI variant) was skipped."
    pause 1.5
    e "You went to the class. It was a class. You came home. The inventory took the hour off and started up again somewhere on the walk."
    $ rr_delta("presence", +3)
    $ rr_delta("regulation", +3)

    menu:
        "continue to Chapter Ten (MI)":
            jump a2c7_mi_start
        "stop here for now — auto-save and return to title":
            $ renpy.force_autosave()
            return
