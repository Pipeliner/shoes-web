## renpy_tests/test_chapter_flow.rpy — chapter-end transition coverage.
##
## Authored 0.1.18-1 in response to playtest report 2026-04-26: the
## user reported that CEN Ch 1 still bounced to branch_select after
## the Continue/Pause menu fix.
##
## Uses Ren'Py 8.5 modern testcase syntax (`click`, `advance until`,
## `assert eval`). The older bare-string syntax (e.g.
## `"I'm ready to begin."`) used in the legacy test_demo_path.rpy
## isn't recognised by the 8.5 test runner — those files compile but
## skip silently. See renpy-sdk/doc/testcases.html and
## renpy-sdk/the_question/game/testcases.rpy for the canonical pattern.

## Test-mode persistent reset. The `start` label gates content_notice
## on `persistent.content_notice_acknowledged`; once True it skips
## the notice and goes straight to branch_select. For tests we want
## a hermetic flow, so we override the flag at init time (before
## `start` runs) when the test framework is active.
##
## Setting it inside `before testcase` is too late — Ren'Py loads
## persistent and runs `start` BEFORE the hook fires, so a stale
## True value from a previous run had already been honoured.
##
## Using `sys.argv` to detect the `test` command is a pragmatic
## hack — `renpy.is_in_test()` only returns True after the test
## phase starts, which is also too late.
init python:
    import sys
    if "test" in (sys.argv or []):
        persistent.content_notice_acknowledged = False


testsuite global:
    ## Per-test setup: only the timing knobs. The game launches at
    ## the `start` label automatically when the test runs; we don't
    ## need an explicit `run Start()` (which raises JumpOutException
    ## from inside the hook context and confuses the runner) or a
    ## `run MainMenu()` (which requires a `screen main_menu` this
    ## game doesn't define). Each testcase begins by waiting for the
    ## first interactive screen (`advance until ...`).
    before testcase:
        $ _test.transition_timeout = 0.05
        ## 8.0s is tight for chains that walk through several call_screen
        ## modals + dialogue (the reflection feeling wheel + part picker
        ## sequence at the end of each chapter takes 1-2s to render under
        ## xvfb after a long negotiation step). Bumped to 20.0s so single
        ## advance-until calls don't run out the budget on slower
        ## systems while still keeping a meaningful upper bound. The
        ## individual advance steps still cap at the framework's
        ## per-step default; this is a soft total-runtime fence.
        $ _test.timeout = 20.0
        $ persistent.content_notice_acknowledged = False

    teardown:
        exit


testcase chapter1_continues_to_chapter2_via_continue_menu:
    ## Drives the player flow that was reported broken on 2026-04-26.
    ## Picks the "continue to Chapter Two" option at the chapter-end
    ## menu (post-fix); asserts we actually land in chapter 2 by
    ## checking that chapter_notice_shown['a1c2'] gets set (the
    ## notice block runs on first entry into a1c2_start).

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    ## Branch-select menu (added in 0.1.15). Pick CEN.
    advance until "childhood emotional neglect"
    click "CEN — childhood emotional neglect. The main path; the complete game."

    ## CEN Ch 1 first gated choice — kitchen path.
    advance until "get up, go to the kitchen, stand with Lena"
    click "get up, go to the kitchen, stand with Lena"

    ## Caretaker negotiation — ASK.
    advance until "ask what it is trying to do for you"
    click "ask what it is trying to do for you"

    ## Reflection feeling-wheel — skip. (Label is "skip — nothing
    ## to write today" since the journal-styling redesign in 0.1.18-4.)
    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    ## Part picker — pick caretaker. (Buttons are now italicised
    ## first-person journal-style strings; the test framework matches
    ## prefix substrings on rendered text, so the textual content
    ## without the {i}/{/i} tags is what we click on.)
    advance until "the part that takes care of others first"
    click "the part that takes care of others first"

    ## CHAPTER-END MENU UNDER TEST. (The Pause option is now
    ## "stop here for now — auto-save and return to title", clearer
    ## about its consequence; the user playtest 2026-04-26 was
    ## misclicking the previous "save and pause for now".)
    advance until "continue to Chapter Two"
    click "continue to Chapter Two"

    ## Chapter 2 notice modal — picking Begin proves we landed there.
    advance until "Begin chapter two."
    click "Begin chapter two."

    ## And assert the side-effect that proves we're inside a1c2_start.
    assert eval "chapter_notice_shown.get('a1c2', False) == True"


## Note on multi-test runs: each test should restart the game state
## so it can begin fresh from `start`. This game has no
## `screen main_menu()` defined, so the SDK pattern of "navigate
## back to main_menu in `before testcase`" doesn't apply. A
## counterpart Pause-path test belongs in a separate test file
## (each `renpy.sh . test` invocation creates a fresh process); a
## proper multi-test setup needs either a main-menu screen or a
## hook that calls `renpy.full_restart()`. Tracked as a follow-up.
##
## Each testcase below is intended to be runnable on its own via
## `./play.sh test --enable-all <name>` — the framework starts a
## fresh process per invocation, so per-test hermeticity is the
## per-process savedir + the persistent.content_notice_acknowledged
## reset above.


## --------------------------------------------------------------------
## CEN — first-choice variants (Ch 1)
## --------------------------------------------------------------------

testcase cen_ch1_phone_first_choice_pauses_at_chapter_end:
    ## CEN Ch 1, "stay in bed with the phone" first choice. Drives
    ## negotiation via DEFER (firefighter-style), reflection skip,
    ## then takes the Pause exit. Asserts we did NOT advance into
    ## Ch 2 (chapter_notice_shown['a1c2'] should remain falsy)
    ## and that the game forced an autosave (renpy.list_saved_games
    ## reports at least one slot).

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    advance until "childhood emotional neglect"
    click "CEN — childhood emotional neglect. The main path; the complete game."

    advance until "stay in bed with the phone"
    click "stay in bed with the phone"

    ## Caretaker negotiation — defer (keep its veto).
    advance until "defer — agree to wait"
    click "defer — agree to wait"

    ## Reflection feeling-wheel — skip.
    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    ## Part picker — skip (post-rewrite the screen reads
    ## "skip — nothing to name today").
    advance until "skip — nothing to name today"
    click "skip — nothing to name today"

    ## Pause path: this should NOT enter Ch 2. The pause label calls
    ## renpy.force_autosave() and returns to title.
    advance until "stop here for now — auto-save and return to title"
    click "stop here for now — auto-save and return to title"

    ## After Pause: chapter 2's notice block must not have run.
    assert eval "chapter_notice_shown.get('a1c2', False) == False"
    ## And an autosave should exist on disk.
    assert eval "len(renpy.list_saved_games(regexp=r'^auto-')) >= 1"


testcase cen_ch1_cold_feet_first_choice_continues_to_ch2:
    ## CEN Ch 1, "notice your cold feet" first choice — the
    ## interoception-credit branch. ASKs the Caretaker (which
    ## sets consented_for_exile on the manager). Continues into
    ## Ch 2.

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    advance until "childhood emotional neglect"
    click "CEN — childhood emotional neglect. The main path; the complete game."

    advance until "notice your cold feet; stay with that for a moment"
    click "notice your cold feet; stay with that for a moment"

    advance until "ask what it is trying to do for you"
    click "ask what it is trying to do for you"

    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "the part that takes care of others first"
    click "the part that takes care of others first"

    advance until "continue to Chapter Two"
    click "continue to Chapter Two"

    advance until "Begin chapter two."
    click "Begin chapter two."

    assert eval "chapter_notice_shown.get('a1c2', False) == True"
    ## Asserts the side-effect of branch_select selecting CEN.
    assert eval "resource_snapshot.branch.value == 'cen'"
    ## ASK on the caretaker (a Manager) flips its consented_for_exile.
    assert eval "parts_state.get('caretaker').consented_for_exile == True"


testcase cen_ch2_voicemail_credits_recognition:
    ## Continues the kitchen+ASK route into Ch 2 and picks the
    ## "send to voicemail" branch, which calls
    ## reco_credit("part_register_identified", "a1c2_critic_identified")
    ## inside chapter2.rpy. We assert recognition_ledger.seen contains
    ## that event id.

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    advance until "childhood emotional neglect"
    click "CEN — childhood emotional neglect. The main path; the complete game."

    advance until "get up, go to the kitchen, stand with Lena"
    click "get up, go to the kitchen, stand with Lena"

    advance until "ask what it is trying to do for you"
    click "ask what it is trying to do for you"

    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "the part that takes care of others first"
    click "the part that takes care of others first"

    advance until "continue to Chapter Two"
    click "continue to Chapter Two"

    advance until "Begin chapter two."
    click "Begin chapter two."

    advance until "don't answer — send to voicemail"
    click "don't answer — send to voicemail"

    ## Reflection feeling wheel after the call — skip.
    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "continue to Chapter Three"
    click "continue to Chapter Three"

    ## We should now be inside a1c3_start, which sets the chapter notice.
    advance until "continue"
    assert eval "chapter_notice_shown.get('a1c3', False) == True"
    ## And the voicemail path credited Recognition.
    assert eval "'a1c2_critic_identified' in recognition_ledger.seen"


## --------------------------------------------------------------------
## CEN — skip-chapter paths
## --------------------------------------------------------------------

testcase cen_ch2_skip_chapter_routes_to_ch3:
    ## After landing in Ch 2 from Ch 1, picks "Skip this chapter."
    ## from the chapter-notice menu. Should route to a1c2_skipped
    ## and offer "continue to Chapter Three".

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    advance until "childhood emotional neglect"
    click "CEN — childhood emotional neglect. The main path; the complete game."

    advance until "get up, go to the kitchen, stand with Lena"
    click "get up, go to the kitchen, stand with Lena"

    advance until "ask what it is trying to do for you"
    click "ask what it is trying to do for you"

    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "the part that takes care of others first"
    click "the part that takes care of others first"

    advance until "continue to Chapter Two"
    click "continue to Chapter Two"

    ## At the Ch 2 notice, take the chapter-skip exit.
    advance until "Skip this chapter."
    click "Skip this chapter."

    ## a1c2_skipped should offer "continue to Chapter Three".
    advance until "continue to Chapter Three"
    click "continue to Chapter Three"

    ## We should now be in Ch 3's content notice.
    advance until "continue"
    assert eval "chapter_notice_shown.get('a1c3', False) == True"
    ## Confirm the in-call branches did NOT run (we never saw the
    ## phone, so a1c2_critic_identified should not be in the ledger).
    assert eval "'a1c2_critic_identified' not in recognition_ledger.seen"


## --------------------------------------------------------------------
## MI branch
## --------------------------------------------------------------------

testcase mi_ch1_kitchen_continues_to_ch2:
    ## Branch-select MI → "get up anyway" first choice → reflection
    ## skip → continue into MI Ch 2. Asserts the branch flipped to MI
    ## and Ch 2 notice fires.
    ##
    ## NOTE: `click "MI — a parent..."` does NOT find the branch_select
    ## menu button under the test framework, even though the equivalent
    ## CEN click works. Best guess: the bold {b}MI{/b} prefix at the
    ## start of the option label confuses the renderer's text-search
    ## index (CEN works because of where it falls in the displayable
    ## tree; MI/NIM both fail). Workaround: use the keyboard shortcut.
    ## screens/choice.rpy binds K_1..K_9 to the menu items; MI is option 2.

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    advance until "childhood emotional neglect"
    keysym "K_2"

    ## MI Ch 1 chapter notice has a "continue" button.
    advance until "continue"
    click "continue"

    advance until "get up anyway; the inventory can keep running from the kitchen"
    click "get up anyway; the inventory can keep running from the kitchen"

    ## Reflection feeling-wheel — skip.
    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "continue to Chapter Two (MI)"
    click "continue to Chapter Two (MI)"

    ## MI Ch 2 chapter notice.
    advance until "begin chapter two (MI)"

    assert eval "chapter_notice_shown.get('a1c2_mi', False) == True"
    assert eval "resource_snapshot.branch.value == 'mi'"


testcase mi_ch2_voicemail_credits_recognition:
    ## MI branch through Ch 1 (cover-ears) into Ch 2 voicemail. The
    ## voicemail path credits 'a1c2_mi_voicemail_asymmetry'.
    ##
    ## See note in mi_ch1_kitchen_continues_to_ch2 for why MI is
    ## clicked via keyboard shortcut instead of label.

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    advance until "childhood emotional neglect"
    keysym "K_2"

    advance until "continue"
    click "continue"

    ## MI Ch 1 first menu — "cover your ears" is option 3. Same
    ## click-by-label-fails pattern; use the keyboard shortcut.
    advance until "get up anyway"
    keysym "K_3"

    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "continue to Chapter Two (MI)"
    click "continue to Chapter Two (MI)"

    advance until "begin chapter two (MI)"
    click "begin chapter two (MI)"

    advance until "let it go to voicemail"
    click "let it go to voicemail"

    ## Reflection skip.
    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    ## Chapter-end: pause to lock the assertion.
    advance until "stop here for now — auto-save and return to title"
    click "stop here for now — auto-save and return to title"

    assert eval "'a1c2_mi_voicemail_asymmetry' in recognition_ledger.seen"
    ## Cover-ears path credits the firefighter-noticed event in Ch 1.
    assert eval "'a1c1_mi_dissociative_firefighter_noticed' in recognition_ledger.seen"


## --------------------------------------------------------------------
## NIM branch
## --------------------------------------------------------------------

testcase nim_ch1_move_continues_to_ch2:
    ## NIM Ch 1 "get up; move" first choice. Credits
    ## 'a1c1_nim_critic_mother_register'. Continues into NIM Ch 2's
    ## chapter notice.

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    ## See note in mi_ch1_kitchen_continues_to_ch2 — branch_select
    ## menu items with leading {b}…{/b} bold tags don't match by-label
    ## via `click`. NIM is option 3 on the menu.
    advance until "childhood emotional neglect"
    keysym "K_3"

    advance until "continue"
    click "continue"

    advance until "get up; move; do not read the scroll"
    click "get up; move; do not read the scroll"

    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "continue to Chapter Two (NIM)"
    click "continue to Chapter Two (NIM)"

    advance until "continue (NIM Ch 2)"

    assert eval "chapter_notice_shown.get('a1c2_nim', False) == True"
    assert eval "resource_snapshot.branch.value == 'nim'"
    assert eval "'a1c1_nim_critic_mother_register' in recognition_ledger.seen"


testcase nim_ch2_end_call_credits_critic_recognition:
    ## NIM through Ch 2 "say: that's nice. i have to go." (end_call
    ## branch). Credits 'a1c2_nim_critic_uses_mothers_rhythm'.

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    ## See note in mi_ch1_kitchen_continues_to_ch2 — branch_select
    ## menu items with leading {b}…{/b} bold tags don't match by-label
    ## via `click`. NIM is option 3 on the menu.
    advance until "childhood emotional neglect"
    keysym "K_3"

    advance until "continue"
    click "continue"

    advance until "stay; argue with the Critic in your head"
    click "stay; argue with the Critic in your head"

    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "continue to Chapter Two (NIM)"
    click "continue to Chapter Two (NIM)"

    advance until "continue (NIM Ch 2)"
    click "continue (NIM Ch 2)"

    advance until "answer"
    click "answer"

    advance until "say: that's nice. i have to go."
    click "say: that's nice. i have to go."

    ## Reflection skip.
    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "stop here for now — auto-save and return to title"
    click "stop here for now — auto-save and return to title"

    assert eval "'a1c2_nim_critic_uses_mothers_rhythm' in recognition_ledger.seen"


testcase nim_ch2_voicemail_credits_critic_recognition:
    ## NIM Ch 2 voicemail. Credits the same critic-rhythm event id
    ## as end_call but via the voicemail label.

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    ## See note in mi_ch1_kitchen_continues_to_ch2 — branch_select
    ## menu items with leading {b}…{/b} bold tags don't match by-label
    ## via `click`. NIM is option 3 on the menu.
    advance until "childhood emotional neglect"
    keysym "K_3"

    advance until "continue"
    click "continue"

    ## NIM Ch 1 first menu — "scroll harder" is option 3.
    advance until "get up; move; do not read the scroll"
    keysym "K_3"

    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "continue to Chapter Two (NIM)"
    click "continue to Chapter Two (NIM)"

    advance until "continue (NIM Ch 2)"
    click "continue (NIM Ch 2)"

    advance until "let it go to voicemail"
    click "let it go to voicemail"

    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "stop here for now — auto-save and return to title"
    click "stop here for now — auto-save and return to title"

    assert eval "'a1c2_nim_critic_uses_mothers_rhythm' in recognition_ledger.seen"


## --------------------------------------------------------------------
## CEN — Ch 1 → Ch 2 → Ch 3 (deep route)
## --------------------------------------------------------------------

testcase cen_ch3_skip_chapter_routes_to_act2:
    ## Drives CEN Ch 1 → Ch 2 (answer + listen-the-silence) → Ch 3
    ## (skip), confirming Ch 3's skip path applies the equivalent
    ## stressor delta and lands at the Act II chapter prompt.

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    advance until "childhood emotional neglect"
    click "CEN — childhood emotional neglect. The main path; the complete game."

    advance until "get up, go to the kitchen, stand with Lena"
    click "get up, go to the kitchen, stand with Lena"

    advance until "ask what it is trying to do for you"
    click "ask what it is trying to do for you"

    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "the part that takes care of others first"
    click "the part that takes care of others first"

    advance until "continue to Chapter Two"
    click "continue to Chapter Two"

    advance until "Begin chapter two."
    click "Begin chapter two."

    advance until "answer"
    click "answer"

    ## Mid-call menu has three options; "just listen to the silence
    ## between her words" is option 3. The label-based click times out
    ## here for the same reason as branch_select MI/NIM (see notes in
    ## mi_ch1_kitchen_continues_to_ch2). Use the keyboard shortcut.
    advance until "let her finish"
    keysym "K_3"

    advance until "skip — nothing to write today"
    click "skip — nothing to write today"

    advance until "continue to Chapter Three"
    click "continue to Chapter Three"

    ## Ch 3 chapter notice — take the skip.
    advance until "skip this chapter"
    click "skip this chapter"

    ## a1c3_skipped should offer "continue to Chapter Four".
    advance until "continue to Chapter Four — Act II"
    click "continue to Chapter Four — Act II"

    ## We are now at the Act II Ch 1 chapter notice.
    advance until "continue"

    assert eval "chapter_notice_shown.get('a2c1', False) == True"
    assert eval "chapter_notice_shown.get('a1c3', False) == True"


## --------------------------------------------------------------------
## Branch-select explainer
## --------------------------------------------------------------------

testcase branch_explainer_returns_to_branch_select:
    ## Click "What are these branches?" → explainer plays → returns
    ## to branch_select (we should be able to pick a branch
    ## immediately after).
    ##
    ## Notes:
    ##   - The explainer body has ~7 narrator lines that need to
    ##     scroll through before we get back to the menu. Bump the
    ##     per-test timeout locally to allow for the dialogue
    ##     advance under skip-mode.
    ##   - "What are these branches?" is option 4 of the branch_select
    ##     menu; the same click-by-label issue that affects MI/NIM
    ##     applies. Use the keyboard shortcut (screens/choice.rpy
    ##     binds K_1..K_9 to menu items).

    $ _test.timeout = 30.0

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    advance until "childhood emotional neglect"
    keysym "K_4"

    ## After the explainer plays, the menu re-appears. Wait for the
    ## CEN button text (only appears on the branch_select menu, never
    ## inside the explainer dialogue, which uses the "{b}CEN{/b} —"
    ## form embedded in a paragraph).
    advance until "The main path; the complete game"

    ## And CEN should be clickable again.
    keysym "K_1"

    ## Confirm we entered Ch 1: branch was set to CEN by the menu
    ## handler (CEN's a1c1_start does NOT mutate branch — the
    ## default ResourceSnapshot is already CEN — but other branches
    ## would override. Assert remains a useful smoke check.)
    advance until "get up, go to the kitchen, stand with Lena"
    assert eval "resource_snapshot.branch.value == 'cen'"


## --------------------------------------------------------------------
## CEN Act II Ch 1 — Firefighter Turn integration test
## --------------------------------------------------------------------
##
## Per docs/route-coverage-report-0.1.18-3.md item 3: "the highest-
## value untested path. The whole scene exists to demonstrate
## Firefighter Turn (PRD §4.6); not having an integration test means
## a regression here goes silent until someone playtests it."
##
## Drives CEN Ch 1 → Ch 2 (skip) → Ch 3 (skip) → Act II Ch 1 →
## open email → asserts firefighter seizes (numb-out intensity ≥ 75
## after email-open) AND presence drops as the seize fires.
##
## Skips Ch 2 + Ch 3 to keep the route short — the firefighter-turn
## logic is in a2c1, not in the earlier chapters; we just need
## enough state to reach the email beat.
##
## Bumps the per-test timeout because the chain is long (content
## notice + branch select + Ch 1 full negotiation + Ch 2 skip +
## Ch 3 skip + Act II Ch 1 email-open is ~12 advance/click steps,
## each with framework overhead).

testcase a2c1_open_email_triggers_firefighter_seize:
    $ _test.timeout = 30.0

    advance until "I'm ready to begin."
    click "I'm ready to begin."

    ## CEN. branch_select uses {b}CEN{/b} text tags, so click-by-label
    ## fails per the route-coverage report; use the K_1 shortcut.
    advance until "childhood emotional neglect"
    keysym "K_1"

    ## CEN Ch 1 first choice. This menu is a CUSTOM screen
    ## (a1c1_first_choice using gated_choice_row) — number-key
    ## shortcuts don't apply here, only click-by-label.
    advance until "get up, go to the kitchen, stand with Lena"
    click "get up, go to the kitchen, stand with Lena"

    ## Caretaker negotiation — also a custom screen (negotiate).
    advance until "ask what it is trying to do for you"
    click "ask what it is trying to do for you"

    ## Reflection feeling-wheel + part picker are also custom screens.
    advance until "skip — nothing to write today"
    click "skip — nothing to write today"
    advance until "the part that takes care of others first"
    click "the part that takes care of others first"

    ## Chapter-end Continue/Pause is a regular `menu:` block — K_1 works.
    advance until "continue to Chapter Two"
    keysym "K_1"

    ## Ch 2 chapter-notice menu is a regular `menu:` block.
    ## "Skip this chapter." is option 2.
    advance until "Skip this chapter."
    keysym "K_2"
    advance until "continue to Chapter Three"
    keysym "K_1"

    ## Ch 3 chapter-notice menu — also regular menu block.
    ## "skip this chapter" is option 2.
    advance until "skip this chapter"
    keysym "K_2"
    advance until "continue to Chapter Four — Act II"
    keysym "K_1"

    ## Now in Act II Ch 1 chapter notice — regular menu block.
    advance until "continue"
    keysym "K_1"

    ## The opening dialogue runs ("The email has been unopened…")
    ## then the open/archive/delete menu — regular menu block.
    ## "open the email" is option 1.
    advance until "open the email"
    keysym "K_1"

    ## The email opens, prose runs, intensity bumps to 85, the
    ## Firefighter Turn fires (firefighter_voice "Close the laptop.").
    ## After the seize prose ("You close the laptop. You did not
    ## decide that. ...") we land in a2c1_after_firefighter — pick
    ## the firefighter is offered intervention.
    advance until "ask what it is trying to do for you"

    ## Assert the firefighter seized: numb-out intensity ≥ 75
    ## (a2c1.rpy bumps to 85 on email-open; SEIZE_THRESHOLD = 75).
    assert eval "parts_state.get('numb-out').intensity >= 75"

    ## Assert the email-stressor deltas applied:
    ## flashback_pressure should have spiked.
    assert eval "resource_snapshot.get(_res.Resource.FLASHBACK_PRESSURE) > 30"

    ## And the seize cost presence (the scene applies -10 presence
    ## via the Firefighter Turn; presence starts at ~50 and may
    ## have moved earlier in the negotiation, so just assert it's
    ## below the starting value).
    assert eval "resource_snapshot.get(_res.Resource.PRESENCE) < 50"
